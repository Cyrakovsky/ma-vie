@echo off
setlocal
chcp 65001 >nul
title Ma Vie - commencer ici
cd /d "%~dp0"

if not exist "%~dp0server\AIDE-VIE-NE-SE-FERME-PAS.cmd" (
  echo ERREUR : le paquet Ma Vie est incomplet.
  echo Extrayez completement ma-vie.zip dans un dossier normal.
  echo.
  pause
  exit /b 1
)

call "%~dp0server\AIDE-VIE-NE-SE-FERME-PAS.cmd"
echo.
echo Le menu d'aide a ete ferme.
pause
endlocal
exit /b 0
