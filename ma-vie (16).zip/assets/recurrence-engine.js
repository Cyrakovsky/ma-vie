(() => {
  "use strict";

  const ENGINE_VERSION = "1.1.0";
  const DAY_MS = 86400000;
  const COMMITMENTS = Object.freeze(["REQUIRED", "OPTIONAL"]);
  const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));
  const isoDate = value => /^\d{4}-\d{2}-\d{2}$/.test(String(value || "")) ? String(value) : "";
  const normalizeCommitment = value => value === "REQUIRED" ? "REQUIRED" : "OPTIONAL";
  const localDate = (timeZone = "Africa/Libreville", instant = new Date()) => { try { const parts=Object.fromEntries(new Intl.DateTimeFormat("en-CA",{timeZone,year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(instant).filter(item=>item.type!=="literal").map(item=>[item.type,item.value]));return`${parts.year}-${parts.month}-${parts.day}` } catch (_) { return instant.toISOString().slice(0,10) } };
  const deepFreeze = value => {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.values(value).forEach(deepFreeze);
    return Object.freeze(value);
  };
  const dateFromISO = value => {
    const normalized = isoDate(value);
    if (!normalized) return null;
    const date = new Date(`${normalized}T12:00:00Z`);
    return Number.isNaN(date.getTime()) ? null : date;
  };
  const formatISO = date => date instanceof Date && !Number.isNaN(date.getTime()) ? date.toISOString().slice(0, 10) : "";
  const addDays = (value, days) => {
    const date = dateFromISO(value);
    if (!date) return "";
    date.setUTCDate(date.getUTCDate() + Number(days || 0));
    return formatISO(date);
  };
  const addMonths = (value, months) => {
    const date = dateFromISO(value);
    if (!date) return "";
    const originalDay = date.getUTCDate();
    date.setUTCDate(1);
    date.setUTCMonth(date.getUTCMonth() + Number(months || 0));
    const lastDay = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0, 12)).getUTCDate();
    date.setUTCDate(Math.min(originalDay, lastDay));
    return formatISO(date);
  };
  const addInterval = (value, amount, unit) => {
    const count = Math.max(1, Number(amount || 1));
    if (unit === "WEEK") return addDays(value, count * 7);
    if (unit === "MONTH") return addMonths(value, count);
    if (unit === "YEAR") return addMonths(value, count * 12);
    return addDays(value, count);
  };
  const weekday = value => dateFromISO(value)?.getUTCDay() ?? -1;
  const isoWeekKey = value => {
    const date = dateFromISO(value);
    if (!date) return "";
    const working = new Date(date);
    const day = working.getUTCDay() || 7;
    working.setUTCDate(working.getUTCDate() + 4 - day);
    const yearStart = new Date(Date.UTC(working.getUTCFullYear(), 0, 1, 12));
    const week = Math.ceil((((working - yearStart) / DAY_MS) + 1) / 7);
    return `${working.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
  };
  const monthKey = value => isoDate(value).slice(0, 7);
  const periodKeyFor = (date, schedule = {}) => schedule.period === "CALENDAR_MONTH" ? monthKey(date) : schedule.period === "DAY" ? date : isoWeekKey(date);
  const occurrenceKey = ({ ruleId, revision, date, slotId = "interval" }) => `${ruleId}:r${Math.max(1, Number(revision || 1))}:${date}:${slotId}`;
  const normalizeTime = value => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(value || "")) ? String(value) : "09:00";
  const normalizeSlot = (slot = {}, index = 0) => ({
    id: String(slot.id || `slot-${index + 1}`),
    weekday: Number.isInteger(Number(slot.weekday)) ? clamp(slot.weekday, 0, 6) : null,
    dayOfMonth: Number.isInteger(Number(slot.dayOfMonth)) ? clamp(slot.dayOfMonth, 1, 31) : null,
    time: normalizeTime(slot.time),
    moment: String(slot.moment || "DAY")
  });
  const executionFor = (executions, key) => executions.filter(item => item.occurrenceKey === key).sort((a, b) => String(b.occurredAt || "").localeCompare(String(a.occurredAt || "")))[0] || null;
  const stateFor = (date, referenceDate, execution) => {
    if (execution?.outcome === "DONE") return "DONE";
    if (execution?.outcome === "SKIPPED") return "SKIPPED";
    if (execution?.outcome === "CANCELLED") return "CANCELLED";
    return date < referenceDate ? "MISSED" : "PLANNED";
  };
  const makeOccurrence = ({ rule, binding, date, slot, executions, referenceDate }) => {
    const key = occurrenceKey({ ruleId: rule.id, revision: rule.revision, date, slotId: slot?.id || "interval" });
    const execution = executionFor(executions, key);
    return {
      key,
      ruleId: rule.id,
      ruleRevision: Math.max(1, Number(rule.revision || 1)),
      bindingId: binding.id,
      sourceRef: { ...(binding.sourceRef || {}) },
      date,
      time: normalizeTime(slot?.time || binding.occurrenceTemplate?.preferredTime),
      moment: String(slot?.moment || binding.occurrenceTemplate?.preferredMoment || "DAY"),
      slotId: slot?.id || "interval",
      periodKey: periodKeyFor(date, rule.schedule),
      timezone: rule.timezone?.zone || rule.timezone?.fallbackZone || "Africa/Libreville",
      status: stateFor(date, referenceDate, execution),
      executionId: execution?.id || "",
      outcome: execution?.outcome || "",
      estimatedResources: {
        timeMinutes: Math.max(0, Number(binding.occurrenceTemplate?.durationMinutes || 0)),
        money: Math.max(0, Number(binding.occurrenceTemplate?.estimatedMoney || 0)),
        currency: String(binding.occurrenceTemplate?.currency || "FCFA")
      },
      commitment: normalizeCommitment(rule.commitment),
      anchorPolicy: rule.anchorPolicy || "FIXED_CALENDAR"
    };
  };
  const inEffectiveWindow = (rule, date) => (!rule.effectiveFrom || date >= rule.effectiveFrom) && (!rule.effectiveUntil || date <= rule.effectiveUntil);
  function calendarOccurrences(rule, binding, executions, from, to, referenceDate) {
    const slots = (rule.schedule?.slots || []).map(normalizeSlot);
    const items = [];
    let cursor = from;
    for (let guard = 0; cursor && cursor <= to && guard < 3700; guard++, cursor = addDays(cursor, 1)) {
      if (!inEffectiveWindow(rule, cursor)) continue;
      const currentWeekday = weekday(cursor), dayOfMonth = Number(cursor.slice(8, 10));
      slots.forEach(slot => {
        const weekdayMatch = slot.weekday === null || slot.weekday === currentWeekday;
        const monthDayMatch = slot.dayOfMonth === null || slot.dayOfMonth === dayOfMonth;
        if (weekdayMatch && monthDayMatch) items.push(makeOccurrence({ rule, binding, date: cursor, slot, executions, referenceDate }));
      });
    }
    return items;
  }
  function rollingOccurrences(rule, binding, executions, from, to, referenceDate) {
    const schedule = rule.schedule || {}, amount = Math.max(1, Number(schedule.every || 1)), unit = schedule.unit || "DAY", anchor = isoDate(binding.anchorDate || schedule.anchorDate);
    if (!anchor) return [];
    let date = addInterval(anchor, amount, unit), guard = 0;
    while (date && date < from && guard++ < 5000) date = addInterval(date, amount, unit);
    const items = [];
    while (date && date <= to && guard++ < 5000) {
      if (inEffectiveWindow(rule, date)) items.push(makeOccurrence({ rule, binding, date, slot: { id: "interval", time: binding.occurrenceTemplate?.preferredTime || "09:00", moment: binding.occurrenceTemplate?.preferredMoment || "DAY" }, executions, referenceDate }));
      date = addInterval(date, amount, unit);
    }
    return items;
  }
  function explicitOccurrences(rule, binding, executions, from, to, referenceDate) {
    return [...new Set(rule.schedule?.dates || [])].filter(date => isoDate(date) && date >= from && date <= to && inEffectiveWindow(rule, date)).sort().map((date, index) => makeOccurrence({ rule, binding, date, slot: { id: `explicit-${index + 1}`, time: binding.occurrenceTemplate?.preferredTime || "09:00", moment: binding.occurrenceTemplate?.preferredMoment || "DAY" }, executions, referenceDate }));
  }
  function generate({ rules = [], bindings = [], executions = [] } = {}, { from, to, referenceDate, timezone = "Africa/Libreville" } = {}) {
    const ref = isoDate(referenceDate) || localDate(timezone), start = isoDate(from) || ref, end = isoDate(to) || addDays(start, 30), ruleMap = new Map(rules.map(rule => [rule.id, rule])), items = [];
    bindings.filter(binding => binding.active !== false).forEach(binding => {
      const rule = ruleMap.get(binding.ruleId);
      if (!rule || rule.status !== "ACTIVE") return;
      const type = rule.schedule?.type;
      if (type === "CALENDAR_SLOTS") items.push(...calendarOccurrences(rule, binding, executions, start, end, ref));
      else if (type === "ROLLING_INTERVAL") items.push(...rollingOccurrences(rule, binding, executions, start, end, ref));
      else if (type === "EXPLICIT_DATES") items.push(...explicitOccurrences(rule, binding, executions, start, end, ref));
    });
    const projectedKeys = new Set(items.map(item => item.key)), bindingMap = new Map(bindings.map(binding => [binding.id, binding]));
    executions.forEach(execution => {
      if (projectedKeys.has(execution.occurrenceKey)) return;
      const match = String(execution.occurrenceKey || "").match(/^(.*):r(\d+):(\d{4}-\d{2}-\d{2}):(.+)$/);
      if (!match) return;
      const [, ruleId, revision, date, slotId] = match;
      if (date < start || date > end) return;
      const binding = bindingMap.get(execution.bindingId) || bindings.find(item => item.ruleId === ruleId), currentRule = ruleMap.get(ruleId);
      if (!binding) return;
      const slot = (currentRule?.schedule?.slots || []).map(normalizeSlot).find(item => item.id === slotId) || { id: slotId, time: binding.occurrenceTemplate?.preferredTime || "09:00", moment: binding.occurrenceTemplate?.preferredMoment || "DAY" };
      const historicalRule = { ...(currentRule || {}), id: ruleId, revision: Number(revision || 1), commitment: normalizeCommitment(currentRule?.commitment), anchorPolicy: currentRule?.anchorPolicy || "FIXED_CALENDAR", timezone: currentRule?.timezone || { zone: "Africa/Libreville" }, schedule: currentRule?.schedule || { type: "EXPLICIT_DATES", period: "ISO_WEEK" } };
      items.push(makeOccurrence({ rule: historicalRule, binding, date, slot, executions, referenceDate: ref }));
    });
    const unique = [...new Map(items.map(item => [item.key, item])).values()].sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time) || (a.commitment === b.commitment ? 0 : a.commitment === "REQUIRED" ? -1 : 1) || a.key.localeCompare(b.key));
    return deepFreeze(unique);
  }
  const emptyCommitmentSummary = () => ({ total: 0, done: 0, planned: 0, missed: 0, skipped: 0, cancelled: 0, remaining: 0 });
  function summarize(occurrences = []) {
    const groups = {};
    occurrences.forEach(item => {
      const group = groups[item.periodKey] ||= { periodKey: item.periodKey, total: 0, done: 0, planned: 0, missed: 0, skipped: 0, cancelled: 0, remaining: 0, needsReplan: 0, required: emptyCommitmentSummary(), optional: emptyCommitmentSummary() };
      const commitmentGroup = item.commitment === "REQUIRED" ? group.required : group.optional;
      group.total++;
      commitmentGroup.total++;
      if (item.status === "DONE") { group.done++; commitmentGroup.done++; }
      else if (item.status === "PLANNED") { group.planned++; commitmentGroup.planned++; }
      else if (item.status === "MISSED") { group.missed++; commitmentGroup.missed++; }
      else if (item.status === "SKIPPED") { group.skipped++; commitmentGroup.skipped++; }
      else if (item.status === "CANCELLED") { group.cancelled++; commitmentGroup.cancelled++; }
    });
    Object.values(groups).forEach(group => {
      group.remaining = Math.max(0, group.total - group.done - group.skipped - group.cancelled);
      group.required.remaining = Math.max(0, group.required.total - group.required.done - group.required.skipped - group.required.cancelled);
      group.optional.remaining = Math.max(0, group.optional.total - group.optional.done - group.optional.skipped - group.optional.cancelled);
      group.needsReplan = group.missed;
      group.progressMeta = { value: group.total ? Math.round(group.done / group.total * 100) : 0, method: "occurrence-execution-ratio", numerator: group.done, denominator: group.total, period: group.periodKey, automatic: true, engineVersion: ENGINE_VERSION };
      group.required.progressMeta = { value: group.required.total ? Math.round(group.required.done / group.required.total * 100) : 0, method: "required-occurrence-execution-ratio", numerator: group.required.done, denominator: group.required.total, period: group.periodKey, automatic: true, engineVersion: ENGINE_VERSION };
      group.optional.progressMeta = { value: group.optional.total ? Math.round(group.optional.done / group.optional.total * 100) : 0, method: "optional-occurrence-execution-ratio", numerator: group.optional.done, denominator: group.optional.total, period: group.periodKey, automatic: true, engineVersion: ENGINE_VERSION };
    });
    return deepFreeze(Object.values(groups).sort((a, b) => a.periodKey.localeCompare(b.periodKey)));
  }
  function validate({ rules = [], bindings = [], executions = [] } = {}, options = {}) {
    const errors = [], warnings = [], duplicateIds = (items, label) => {
      const seen = new Set();
      items.forEach(item => { if (!item?.id) errors.push(`${label} sans identifiant`); else if (seen.has(item.id)) errors.push(`${label} dupliqué : ${item.id}`); else seen.add(item.id); });
    };
    duplicateIds(rules, "Règle"); duplicateIds(bindings, "Binding"); duplicateIds(executions, "Exécution");
    const ruleIds = new Set(rules.map(item => item.id)), rulesById = new Map(rules.map(item=>[item.id,item]));
    bindings.forEach(binding => { const rule=rulesById.get(binding.ruleId);if (!ruleIds.has(binding.ruleId)) errors.push(`Binding ${binding.id} sans règle ${binding.ruleId}`); if (!binding.sourceRef?.entityId) errors.push(`Binding ${binding.id} sans source métier`);if(binding.active!==false&&rule?.schedule?.type==="ROLLING_INTERVAL"&&!isoDate(binding.anchorDate||rule.schedule.anchorDate))warnings.push(`Binding ${binding.id} en attente d’un événement d’ancrage`); });
    rules.forEach(rule => {
      if (!["DRAFT", "ACTIVE", "PAUSED", "ARCHIVED"].includes(rule.status)) errors.push(`Statut invalide pour ${rule.id}`);
      if (rule.commitment !== undefined && !COMMITMENTS.includes(rule.commitment)) errors.push(`Engagement invalide pour ${rule.id} : ${rule.commitment}`);
      if (rule.schedule?.type === "CALENDAR_SLOTS") {
        const slots = rule.schedule.slots || [];
        if (rule.status === "ACTIVE" && !slots.length) errors.push(`Règle active sans créneau : ${rule.id}`);
        const slotIds = new Set(); slots.forEach((slot, index) => { const normalized = normalizeSlot(slot, index); if (slotIds.has(normalized.id)) errors.push(`Créneau dupliqué dans ${rule.id} : ${normalized.id}`); slotIds.add(normalized.id); });
      } else if (rule.schedule?.type === "ROLLING_INTERVAL") {
        if (Number(rule.schedule.every) <= 0) errors.push(`Intervalle invalide : ${rule.id}`);
      } else if (rule.schedule?.type !== "EXPLICIT_DATES") errors.push(`Type de fréquence inconnu : ${rule.id}`);
    });
    const horizonFrom = isoDate(options.from), horizonTo = isoDate(options.to);
    if (horizonFrom && horizonTo) {
      const occurrences = generate({ rules, bindings, executions }, { from: horizonFrom, to: horizonTo, referenceDate: options.referenceDate || horizonFrom });
      if (new Set(occurrences.map(item => item.key)).size !== occurrences.length) errors.push("Clés d’occurrence dupliquées");
    }
    const executedKeys = new Set();executions.forEach(execution => { if (!execution.occurrenceKey) errors.push(`Exécution ${execution.id} sans occurrence`); else if(executedKeys.has(execution.occurrenceKey))errors.push(`Exécutions dupliquées pour ${execution.occurrenceKey}`);else executedKeys.add(execution.occurrenceKey);if (!["DONE", "SKIPPED", "CANCELLED"].includes(execution.outcome)) warnings.push(`Résultat non reconnu : ${execution.id}`); });
    return deepFreeze({ ok: errors.length === 0, errors, warnings, engineVersion: ENGINE_VERSION });
  }

  const api = Object.freeze({ version: ENGINE_VERSION, commitments: COMMITMENTS, generate, summarize, validate, occurrenceKey, isoWeekKey, localDate, addDays, addInterval });
  (typeof window !== "undefined" ? window : globalThis).VieRecurrenceEngine = api;
})();
