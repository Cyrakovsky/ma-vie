# Ma Vie — Assistant personnel VIE

**Ma Vie** est une application web et mobile de productivité, de développement personnel et de gestion globale de la vie.

Elle aide l’utilisateur à répondre à trois questions :

1. Où suis-je actuellement ?
2. Où est-ce que je veux aller ?
3. Quelles actions dois-je réaliser pour y arriver ?

## Lancer l’application

VIE propose deux modes complémentaires, avec un ordre clair : le serveur HTTPS local est le **mode principal recommandé** et l’ouverture directe reste un **mode autonome de secours**.

### Mode principal — serveur local HTTPS et SQLite

Sous Windows, ouvrez le dossier `server` puis lancez `INSTALLER-VIE.bat`. L’installateur crée un dossier indépendant `C:\VIE`, génère un certificat local, installe explicitement son autorité dans le magasin de confiance Windows, protège la clé privée, installe le service Windows et ouvre :

```text
https://localhost:8080/vie/
```

Le serveur écoute exclusivement sur `127.0.0.1`, sert l’application sous `/vie/`, protège le transport par TLS 1.2 minimum, utilise un cookie de session `Secure` et une protection CSRF, conserve les enveloppes déjà chiffrées dans `C:\VIE\data\vie.db` et gère les pièces jointes et sauvegardes cohérentes. Aucun XAMPP, PHP, MySQL ou accès Internet n’est nécessaire.

### Mode autonome de secours

Ouvrez directement `index.html` dans un navigateur moderne. L’adresse utilise alors `file://`, sans HTTP ni HTTPS. Les données restent chiffrées dans le navigateur et peuvent être exportées dans une archive `.vie`, mais le service SQLite, les sauvegardes cohérentes et le transport HTTPS ne sont pas disponibles. Ce mode est conservé pour l’usage hors service, la portabilité et la récupération.

L’application occupe toute la fenêtre du navigateur dans les deux modes. La topbar reste fixe et seul le contenu central défile.

## Modules intégrés

1. Centre de Vie
2. Pilotage stratégique
3. Conseil de Vie
4. Centre de Cohérence
5. Cycles de vie
6. Coach VIE
7. Système personnel
8. Outils système
9. Profil personnel et vision de vie
10. Objectifs et projets
11. Habitudes, engagements et discipline
12. Rappels intelligents
13. Finances et patrimoine
14. Construction et immobilier
15. Business et entrepreneuriat
16. Carrière et apprentissage
17. Santé et bien-être
18. Relations et famille
19. Enfants et transmission
20. Apparence, vêtements et entretien
21. Journal personnel
22. Rapports et analyses
23. Espace VIE, sauvegardes et portabilité

## Module Objectifs & Projets

Le cœur stratégique de l’application comprend désormais :

- une vue générale du portefeuille d’objectifs ;
- des indicateurs d’objectifs actifs, de progression, de réalisations et de retards ;
- une liste filtrable par statut, priorité et catégorie ;
- un formulaire intelligent avec motivation obligatoire ;
- un calcul automatique du budget restant et de la progression financière ;
- plusieurs sources de financement ;
- une analyse du temps disponible et investi ;
- une gestion détaillée du matériel avec quantité, prix, priorité et statut ;
- des compétences avec niveau actuel, niveau cible, formation et ressources ;
- des étapes avec budget, date, progression et statut ;
- un plan d’action quotidien ;
- un bloc d’obstacles et de solutions ;
- des conseils automatiques selon les domaines faibles ;
- un journal complet des événements ;
- des rapports hebdomadaires et mensuels exportables.

## Module Habitudes & Discipline

Le moteur d’exécution quotidien comprend maintenant :

- un tableau de discipline et un score global pondéré ;
- une répartition par organisation, finance, santé, travail et relations ;
- des habitudes avec catégorie, motivation, fréquence, durée, horaire, engagement `REQUIRED | OPTIONAL` et objectif lié ;
- les séries actuelles, records et taux de réussite ;
- un suivi quotidien limité aux créneaux réellement prévus avec les états `PLANNED`, `DONE`, `MISSED` et `SKIPPED` ;
- un suivi hebdomadaire par routine, obligatoire ou optionnelle ;
- un formulaire d’analyse des causes d’échec conservé dans l’historique ;
- des adaptations explicites de fréquence, d’heure et de difficulté ;
- des engagements suivis par période ;
- des routines du matin, de la journée et du soir ;
- un score intelligent combinant habitudes, engagements, régularité et organisation ;
- une analyse comportementale positive et négative ;
- un historique mensuel détaillé et exportable ;
- des défis personnels avec progression quotidienne ;
- des conseils personnalisés pour améliorer la constance.

## Mémoire réflexive dans le Journal

Le Journal distingue désormais les pensées déclarées, les réflexions développées, les principes adoptés explicitement, les thèmes comptés et les conseils contextuels avec provenance. La carte des idées et le rapport de réflexion restent descriptifs : VIE n’invente aucune vérité et ne produit aucun diagnostic de personnalité.

## Module Apparence & Entretien

Ce département personnel comprend maintenant :

- le mannequin holographique fourni comme visuel central ;
- une reproduction fidèle de son ambiance numérique bleue ;
- une couche SVG superposée avec zones corporelles interactives ;
- des zones cliquables et accessibles au clavier ;
- un accès direct aux soins, vêtements et accessoires liés à chaque zone ;
- un suivi des mensurations et de leur historique ;
- un profil capillaire, des styles, produits et rendez-vous ;
- des routines pour la peau et le visage ;
- le suivi du brossage, des produits, rendez-vous et bijoux dentaires ;
- la gestion de l’hygiène, du parfum, des mains, des pieds et des ongles ;
- une garde-robe complète avec tailles, couleurs, état et utilisation ;
- un inventaire distinct pour les chaussures ;
- des bijoux et accessoires classés par partie du corps ;
- une identité visuelle avec styles et palettes de couleurs ;
- un créateur de tenues pour le travail, les cérémonies et le quotidien ;
- un planning automatique d’entretien ;
- un budget apparence avec dépenses par catégorie ;
- une chronologie de l’évolution personnelle.

## Module Santé & Bien-être

Le tableau de bord de prévention et d’organisation de la santé comprend :

- une synthèse de la santé globale, du sommeil, de l’activité, de l’hydratation et du mental ;
- un profil de santé personnel avec groupe sanguin, allergies et antécédents ;
- le suivi des mesures, de l’IMC, de la fréquence cardiaque et de la tension ;
- un journal nutritionnel et des objectifs alimentaires ;
- un suivi d’hydratation avec rappels et progression ;
- des programmes et séances d’activité physique ;
- un historique du sommeil et de sa qualité ;
- un journal du bien-être mental ;
- la gestion des médicaments, posologies et renouvellements ;
- un calendrier des rendez-vous médicaux ;
- le suivi bucco-dentaire ;
- le suivi de la vision et de l’audition ;
- un espace pour les examens médicaux ;
- un dossier médical personnel recherchable ;
- une carte d’urgence et les contacts importants ;
- des rappels santé ;
- des graphiques d’évolution ;
- des alertes informatives qui ne remplacent jamais un avis médical.

## Module Relations & Famille

Le gestionnaire de relations personnelles comprend maintenant :

- un tableau de bord des liens importants, événements et engagements ;
- des fiches détaillées pour chaque relation ;
- un arbre de vie familial interactif ;
- une page dédiée au couple, aux projets communs et aux dates importantes ;
- une connexion avec le module Enfants ;
- des espaces séparés pour les amis et le réseau professionnel ;
- un calendrier des événements et anniversaires ;
- une gestion des cadeaux, idées et budgets ;
- un historique des appels, rencontres, messages, repas et activités ;
- un suivi des engagements familiaux ;
- un album de souvenirs ;
- des notes privées ;
- un suivi des situations importantes de la vie ;
- une analyse relationnelle descriptive et sans jugement.

## Module Enfants & Transmission

Ce module dédié aux générations futures comprend :

- un tableau de bord de l’éducation, de la santé, de l’épargne et des événements ;
- une fiche complète pour chaque enfant ;
- un espace de préparation du projet parental ;
- le suivi des résultats, langues, lectures et compétences ;
- l’historique de santé, vaccinations, consultations et croissance ;
- les activités sportives, musicales et éducatives ;
- les objectifs d’épargne et les contributions ;
- l’organisation des biens et bénéficiaires souhaités ;
- des valeurs, conseils, traditions et enseignements familiaux ;
- un album de souvenirs par enfant ;
- la centralisation des documents importants et de leurs expirations ;
- les objectifs familiaux ;
- un calendrier scolaire, médical et familial ;
- des graphiques de suivi et d’évolution ;
- un coffre de transmission pour les lettres, messages, recettes, documents et souvenirs ;
- un avertissement précisant que l’organisation patrimoniale ne remplace pas un testament officiel.

## Module Finances & Patrimoine

Le centre financier de VIE comprend maintenant :

- un tableau d’allocation consolidant ressources, budget global, montants alloués et patrimoine net ;
- un `BudgetStore` mensuel et des allocations spécialisées par domaine ;
- la séparation entre réel, engagé, prévu et disponible après prévision ;
- le choix entre échéances d’achat et équivalent mensuel récurrent ;
- la gestion des revenus par source et fréquence ;
- l’ajout rapide des dépenses quotidiennes ;
- la comparaison des dépenses mensuelles ;
- des budgets par catégorie et sous-catégorie ;
- une taxonomie hiérarchique de 16 catégories principales et de toutes leurs sous-catégories ;
- un catalogue visuel multi-catégories séparé du panier et des achats réels ;
- un panier modifiable qui alimente uniquement le prévu des allocations ;
- un calendrier mensuel séparant prévu, réalisé et récurrent à venir ;
- des fiches produit avec marque, conditionnement et date prévue exacte ;
- des achats détaillés avec plusieurs articles et calcul automatique ;
- des dépenses récurrentes et leurs prochaines échéances ;
- des dépenses prévisionnelles ;
- des objectifs financiers avec contributions ;
- des objectifs d’épargne ;
- un portefeuille d’investissements et le calcul des rendements ;
- des comptes bancaires, espèces et mobile money ;
- des mouvements entre comptes ;
- le suivi des dettes, crédits et remboursements ;
- un inventaire du patrimoine ;
- des analyses factuelles et graphiques sur six mois, sans montants inventés ;
- un historique filtrable et exportable ;
- des paramètres et alertes financières ;
- des rappels automatiques pour les budgets, factures et échéances.

## Module Construction & Immobilier

Le gestionnaire de projets immobiliers comprend maintenant :

- un tableau de bord des projets, terrains, biens et budgets ;
- un inventaire des terrains avec superficie, cadastre, GPS et documents ;
- des fiches complètes pour chaque construction ou rénovation ;
- un inventaire des biens immobiliers et des revenus locatifs ;
- la gestion des plans et de leurs différentes versions ;
- seize phases de chantier avec responsables, budgets et progression ;
- un carnet d’entreprises et d’artisans ;
- un inventaire des matériaux prévus, achetés, utilisés et disponibles ;
- un budget par poste avec factures et calcul automatique ;
- un planning des tâches, visites, livraisons et paiements ;
- un dossier de documents liés aux projets ;
- un journal de chantier avec observations et progression ;
- un suivi des problèmes et réserves ;
- des rapports statistiques exportables ;
- des paramètres et alertes de chantier ;
- une timeline interactive regroupant toutes les étapes du projet.

## Module Business

Le centre entrepreneurial de VIE comprend maintenant :

- un centre de pilotage répondant quotidiennement aux questions de rentabilité, priorités, risques et opportunités ;
- la gestion de plusieurs entreprises ;
- un portefeuille d’idées et de projets entrepreneuriaux ;
- un business plan structuré ;
- des objectifs stratégiques et indicateurs ;
- un CRM clients ;
- un carnet de fournisseurs et partenaires ;
- un catalogue de produits et services avec calcul des marges ;
- la gestion des achats et approvisionnements ;
- le suivi du stock et des seuils minimums ;
- les devis, factures, paiements et impayés ;
- les revenus, dépenses et bénéfices par entreprise ;
- une comptabilité simplifiée ;
- le suivi des employés, contrats, présences et performances ;
- la gestion des campagnes marketing et de leur retour sur investissement ;
- un tableau de tâches et opérations ;
- un dossier de documents administratifs et commerciaux ;
- des rapports statistiques exportables ;
- des projets de croissance et d’expansion ;
- des paramètres et alertes business.

## Module Carrière & Apprentissage

Le département de développement professionnel comprend maintenant :

- un tableau de bord de carrière et d’apprentissage ;
- un profil professionnel complet ;
- un plan de carrière sur plusieurs années ;
- l’historique des emplois, missions et réalisations ;
- plusieurs versions de CV, lettres et portfolios ;
- un tableau Kanban de recherche d’emploi ;
- des objectifs professionnels et leurs étapes ;
- un catalogue de compétences techniques et humaines ;
- la gestion des formations, coûts, durées et certificats ;
- le suivi des études, diplômes, mémoires et stages ;
- des profils linguistiques détaillés ;
- l’historique des certifications ;
- une bibliothèque de livres, articles, vidéos et podcasts ;
- un espace de notes et de connaissances organisé par dossiers ;
- le suivi des mentors et des conseils reçus ;
- un planning hebdomadaire d’apprentissage ;
- des graphiques de progression ;
- un planificateur intelligent reliant objectif, compétences, formations, certifications, expériences, temps et budget.

## Module Journal personnel

La mémoire personnelle de VIE comprend maintenant :

- un tableau de bord des entrées, de la régularité, de l’humeur et des événements ;
- un éditeur complet avec date, heure, catégorie, lieu, humeur et mots-clés ;
- un journal quotidien structuré ;
- un espace de réflexions par domaine ;
- un suivi des humeurs et émotions ;
- un journal de gratitude ;
- un carnet d’idées transformables en objectif ou projet business ;
- un espace pour conserver les réussites ;
- un suivi des difficultés, solutions et leçons ;
- un album de souvenirs ;
- des bilans quotidiens, hebdomadaires, mensuels et annuels ;
- une recherche par mot-clé, émotion, catégorie, personne ou projet ;
- des statistiques d’écriture et d’humeur ;
- des archives organisées par collections ;
- des options de rappel, verrouillage, confidentialité, export et sauvegarde ;
- une ligne de vie interactive regroupant journal, objectifs, carrière, patrimoine, construction et événements familiaux.

## Pilotage stratégique

Le **Pilotage stratégique** transforme les objectifs primordiaux en stratégies contrôlables.

Structure intégrée :

- vue générale ;
- objectifs stratégiques ;
- feuilles de route ;
- ressources ;
- jalons ;
- scénarios ;
- Plans B ;
- risques ;
- décisions ;
- indicateurs avancés ;
- revues périodiques ;
- archives.

Chaque stratégie précise :

- la situation actuelle ;
- le résultat concret attendu ;
- pourquoi et pour qui l’objectif compte ;
- ce que sa réussite changera ;
- les sacrifices acceptables ;
- ce que l’utilisateur refuse de sacrifier.

### Conditions de réussite

Les ressources stratégiques sont suivies séparément : argent, temps, compétences, documents, mobilité, contacts et matériel. Chacune possède un niveau de préparation, une prochaine action, un responsable et une échéance.

### Jalons

Un jalon dispose d’une checklist et d’un indicateur de réussite. Son état est calculé automatiquement. Lorsqu’il est atteint :

- la progression stratégique est recalculée ;
- l’objectif source est mis à jour ;
- une preuve de progression est créée ;
- l’événement rejoint le journal transversal.

### Scénarios et basculement

- Plans A, B et C ;
- coût, durée, conditions, avantages, inconvénients et risques ;
- probabilité estimée uniquement par l’utilisateur ;
- conditions explicites de basculement ;
- aucune prédiction automatique de l’avenir.

### Risques et pré-mortem

Chaque risque possède une probabilité, un impact, une prévention, un plan de réponse et un état. Le pré-mortem demande d’imaginer les causes possibles d’échec puis de préparer les mesures préventives.

### Indicateurs avancés

VIE distingue progression, santé du projet, ressources, respect du calendrier et niveau de risque. Une progression isolée ne suffit plus à décrire la trajectoire.

### Circulation intelligente des informations

- une dépense peut être reliée à un objectif et consommer son budget stratégique ;
- une ressource modifie le niveau de préparation ;
- une échéance peut créer un rappel ;
- un risque élevé rejoint les alertes intelligentes ;
- un jalon terminé recalcule la progression ;
- les relations entre objectifs alimentent le graphe du Centre de Cohérence.

Une stratégie complète d’exemple est fournie pour le **Master en cybersécurité**, avec scénario à l’étranger, scénario local et alternative travail + certifications.

Le projet de mariage est présenté comme **Construire un foyer et préparer le mariage** : l’utilisateur définit lui-même valeurs, attentes, limites et choix du couple. Le projet capillaire est présenté comme une étude de traitement adaptée, sous responsabilité d’un professionnel de santé.

## Centre de Vie

Le **Centre de Vie** remplace le tableau de bord classique et devient la première page affichée à l’ouverture.

Il répond quotidiennement à la question :

> Que dois-je faire aujourd’hui pour avancer vers la vie que je veux construire ?

Il comprend :

- un mode « Aujourd’hui » concentré sur trois priorités seulement ;
- une sélection issue des actions, habitudes, rappels, objectifs, rendez-vous médicaux, finances, chantier, business, famille, enfants et maintenance ;
- la justification de chaque priorité, son « pourquoi » et son module source ;
- les actions du jour, les finances quotidiennes, les habitudes, les alertes et le Conseil de Vie dans le premier écran ;
- le coût réel mensuel de la vie et l’autonomie du fonds de sécurité ;
- une proposition de petite action concrète ;
- des actions pour terminer, ouvrir ou reporter explicitement une priorité ;
- neuf indicateurs indépendants : discipline, santé, finances, carrière, famille, business, patrimoine, apprentissage et bien-être ;
- des cadrans circulaires sobres pour les KPI, sans barres de progression colorées ;
- le cap principal du moment ;
- les accomplissements récents ;
- un assistant comportemental explicable ;
- un aperçu des liens entre modules ;
- les événements récents de la ligne de vie ;
- des accès directs au coffre, à la carte, aux connaissances, à l’inventaire et aux décisions.

## Usage quotidien et mémoire personnelle

VIE privilégie désormais l’utilité quotidienne plutôt que l’accumulation de modules :

- trois priorités maximum au lancement ;
- actions immédiatement réalisables ;
- finances et habitudes du jour ;
- premier signal nécessitant une attention ;
- résumé du Conseil de Vie ;
- rappel explicite que ralentir, se reposer ou abandonner un mauvais objectif peut être cohérent.

La **Mémoire personnelle** répond à des questions en recherchant uniquement les données enregistrées : objectifs financiers, budgets de construction, formations, documents, notes et autres éléments indexés. Elle n’invente aucune information.

## Revues et apprentissage de la planification

- revue hebdomadaire : objectifs avancés ou bloqués, dépenses, apprentissage, habitudes et événements à venir ;
- proposition de trois priorités pour la semaine suivante ;
- validation obligatoire par l’utilisateur avant leur ajout ;
- revue mensuelle comparant prévu et réalisé ;
- raisons d’écart : temps, argent, priorité changée, difficulté sous-estimée, oubli ou autre ;
- conservation de ces raisons pour mieux calibrer les plans futurs.

## Objectifs réalistes et conscients

Le module Objectifs comprend maintenant :

- un calcul de faisabilité financière avec effort mensuel requis, effort prévu et écart ;
- la possibilité d’ajuster budget, délai ou épargne mensuelle ;
- six dimensions de ressources : argent, temps, compétences, personnes, documents et matériel ;
- un état expliqué : en bonne voie, attention, bloqué, pas commencé, terminé ou abandonné consciemment ;
- des objectifs « Un jour, peut-être » sans échéance ;
- la conservation du « Pourquoi ? » lorsque l’objectif devient difficile ;
- des objectifs composés avec sous-objectifs, budgets, ressources, échéances et progression ;
- des preuves de progression : photo, facture, certificat, document, résultat ou note ;
- une suggestion de plus petite action réalisable ;
- l’arrêt conscient d’un objectif avec conservation de son histoire ;
- des boucles SI / ALORS / SINON accompagnées d’un Plan B ;
- un dossier documentaire avec état, autorité, date et échéance ;
- des objectifs primordiaux avec feuille de route et ressources nécessaires ;
- des comparaisons de parcours, de coûts, de salaires estimés, de diplômes et de durées.

Des objectifs complets sont fournis comme exemples structurés :

- préparation du mariage étape par étape ;
- étude prudente d’implants capillaires avec avis médical, financement, suivi et alternative non chirurgicale ;
- accès à un travail mieux rémunéré avec comparaison des métiers, parcours, diplômes, compétences et rémunérations estimées.

Les rémunérations, coûts médicaux et listes documentaires restent des hypothèses personnelles à confirmer auprès des employeurs, professionnels de santé et autorités compétentes.

La vue **Avant / Maintenant** compare uniquement l’utilisateur à ses propres instantanés passés.

## Système personnel

Le nouveau département transversal transforme VIE en système d’exploitation personnel.

### Liens entre les modules

- sélection d’un objectif central ;
- constellation interactive des modules associés ;
- rapprochement automatique des finances, projets, échéances, documents, photos, habitudes et actions ;
- liens manuels supplémentaires sans duplication des données.

### Accomplissements significatifs

- premier million épargné ;
- 365 jours de discipline ;
- premier bien immobilier ;
- première entreprise ;
- première certification ;
- 100 livres lus ;
- 1 000 heures d’apprentissage ;
- premier objectif majeur atteint ;
- intégration des réussites personnelles du journal.

Chaque jalon affiche une progression calculée à partir des données disponibles.

### Coffre numérique

- passeports, cartes d’identité, permis, diplômes, contrats, assurances, actes, garanties et factures importantes ;
- catégorie, référence, autorité, émission, expiration et confidentialité ;
- liaison à un bien, une personne, un projet ou un module ;
- pièces jointes conservées dans IndexedDB et copiées dans le dossier VIE lorsqu’il est connecté ;
- pièces jointes disponibles incluses dans l’archive ZIP portable et restaurées à l’import ;
- alertes d’expiration et export CSV du registre.

Le statut « confidentiel » organise l’accès dans l’interface, mais ne remplace pas le chiffrement du disque ou du dossier VIE. L’appareil et le support de stockage doivent rester protégés.

### Historique visuel

- projets photographiques pour construction, transformation physique, rénovation, jardin ou véhicule ;
- étapes datées avec phase, observation et image ;
- compression locale des photos avant enregistrement ;
- liaison au module et à l’élément d’origine.

### Carte personnelle

- carte hors ligne et responsive ;
- terrains, maisons, entreprises, écoles, établissements de santé et lieux importants ;
- coordonnées, adresse, importance, notes et module associé ;
- filtres et fiches interactives.

### Base de connaissances

- wiki personnel hiérarchique ;
- thèmes, sous-thèmes, contenus et mots-clés ;
- exemple structuré Cybersécurité → Cryptographie, Linux, Docker et SQL ;
- recherche et connexions aux projets ou formations.

### Inventaire et maintenance

- inventaire consolidé des vêtements, chaussures, bijoux, technologies, meubles, électroménager, outils, véhicules et biens ;
- prix, garantie, état, valeur estimée, localisation et numéro de série ;
- calendrier d’entretien pour véhicules, ordinateurs, climatiseurs, maison, toiture et jardin ;
- coûts, fréquences, prestataires, rappels et recalcul de la prochaine date après validation.

### Vision et décisions

- feuille de route pluriannuelle reliée aux modules ;
- jalons, statut, progression et raison personnelle ;
- fiches de décision comparant achat, assurance, entretien, carburant, autres charges, avantages et limites ;
- coût total sur trois ans et impact mensuel ;
- le score rassemble les données sans décider à la place de l’utilisateur.

### Assistant comportemental

L’assistant détecte uniquement des tendances disposant d’un nombre minimum d’observations. Il indique :

- la donnée utilisée ;
- le niveau de confiance ;
- le rappel suggéré.

Un rappel n’est créé qu’après une action explicite de l’utilisateur. Aucune donnée n’est modifiée automatiquement.

## Outils système

Les fonctions d’infrastructure destinées à une utilisation sur plusieurs décennies comprennent :

### Recherche, étiquettes, favoris et épingles

- un index global unique couvrant objectifs, dépenses, documents, photos, journal, rendez-vous, contacts, connaissances, inventaire, bibliothèque, souhaits et décisions ;
- la même recherche accessible depuis la topbar avec `Ctrl + K` ;
- des étiquettes personnalisables et réutilisables dans tous les modules ;
- des favoris transversaux ;
- quatre éléments épinglés directement dans le Centre de Vie ;
- ouverture du module et de l’élément d’origine depuis chaque résultat.

### Pièces jointes et relations

- ajout de PDF, images, vidéos, audio, scans, documents bureautiques et factures à n’importe quelle donnée indexée ;
- stockage des fichiers dans IndexedDB ;
- copie dans le dossier VIE connecté ;
- inclusion des pièces jointes et des versions restaurables de l’historique dans l’archive ZIP complète ;
- relations explicites entre une dépense, un projet, un enfant, une entreprise, un objectif ou tout autre élément.

### Historique des modifications

- détection automatique des ajouts, suppressions et modifications importantes ;
- description de la section concernée ;
- instantanés complets stockés dans IndexedDB ;
- nombre de versions configurable ;
- restauration d’une ancienne version après création automatique d’un point de retour ;
- suppression individuelle des versions devenues inutiles.

### Importation

- fichiers CSV avec détection du séparateur et gestion des champs entre guillemets ;
- classeurs Excel `.xlsx` lus directement dans le navigateur ;
- contacts CSV ou vCard `.vcf` ;
- calendriers CSV ou iCalendar `.ics` ;
- import d’opérations financières, d’inventaire, de contacts, d’événements et d’objectifs ;
- prévisualisation avant confirmation ;
- contrôle des doublons et historique des importations.

### Évolution et machine à remonter le temps

- instantanés annuels des finances, du patrimoine, des objectifs, de la discipline, de la santé, de la carrière et du business ;
- affichage des objectifs et biens enregistrés pour chaque année ;
- comparaison entre une année passée et la situation actuelle ;
- capture ou actualisation de l’année courante ;
- accès aux versions datées de l’historique pour une restauration plus précise.

### Bibliothèque personnelle

- livres, vidéos, PDF, articles, cours et podcasts ;
- statut et progression ;
- favoris, mots-clés et notes ;
- connexion à une compétence ;
- ajout facultatif d’un fichier comme pièce jointe universelle.

### Liste de souhaits

- technologies, terrains, vêtements, formations, voyages ou projets personnels ;
- prix, montant déjà préparé, priorité et date cible ;
- connexion à un objectif et à un plan d’épargne ;
- contributions progressives sans modifier automatiquement les finances.

### Simulateurs

- scénarios de construction, véhicule, entreprise, voyage et retraite ;
- budget, capital disponible, épargne mensuelle, durée, rendement et autres engagements ;
- calcul en direct du reste à financer, de la durée, de l’effort requis et de la date estimée ;
- enregistrement des hypothèses sans altération automatique des objectifs réels.

### Carte des objectifs et modèles

- carte mentale interactive avec dépendances entre vision, diplômes, compétences, épargne, certifications et expériences ;
- nœuds et relations modifiables ;
- modèles réutilisables pour maison, mariage, entreprise, voyage et formation ;
- création confirmée d’un objectif, d’étapes, de tâches, de rappels et, selon le cas, d’un projet immobilier ou d’une idée business.

### Espaces de vie

- Vie personnelle, Famille, Business et Immobilier fournis par défaut ;
- espaces supplémentaires personnalisables ;
- sélection des modules et étiquettes de chaque espace ;
- tableau de bord local à l’espace tout en conservant les connexions globales.

### Tableau de sécurité

- dernière sauvegarde ;
- état d’intégrité ;
- espace utilisé et quota estimé ;
- disponibilité des pièces jointes ;
- état de l’historique ;
- accès direct à la sauvegarde, à l’archive complète et à l’Espace VIE.

## Conseil de Vie

Le **Conseil de Vie** produit un rapport structuré, sans conversation permanente :

- ce qui progresse bien ;
- ce qui mérite de l’attention ;
- les opportunités identifiées ;
- les prochaines actions recommandées, classées par impact ;
- un score consolidé calculé à partir des neuf indicateurs ;
- une explication et un accès au module source pour chaque constat ;
- un historique des rapports générés ;
- un export texte lisible.

Le Conseil de Vie applique cinq principes : données de l’utilisateur uniquement, objectifs personnels comme référence, constats explicables, aucune décision prise à sa place et aucune action automatique.

Le Centre de décisions accepte désormais des critères pondérés. Chaque option peut recevoir une note par critère ; VIE calcule alors un score pondéré tout en laissant la décision finale à l’utilisateur.

## Cycles de vie

Le département **Cycles de vie** adapte l’interface aux grandes étapes de l’existence sans déplacer ni supprimer les données.

Cycles fournis :

- étudier ;
- trouver et développer un emploi ;
- fonder une famille ;
- construire ;
- investir ;
- élever et transmettre aux enfants ;
- entreprendre ;
- voyager ;
- préparer la retraite.

Le cycle mis en avant augmente la priorité visuelle de ses modules et propose des rappels contextuels qui ne sont créés qu’après confirmation.

Le département comprend également :

- une boussole de valeurs et principes de vie, avec spiritualité facultative ;
- un radar d’équilibre entre santé, finances, famille, business, apprentissage et repos ;
- le suivi hebdomadaire du temps et un chronomètre de sessions ;
- des plans d’imprévus pour emploi, véhicule, finances, déménagement et catastrophe naturelle ;
- la préparation des voyages : documents, visa, assurance, budget, itinéraire et bagages ;
- la gestion de la maison après construction : pièces, mobilier, équipements et entretien ;
- le journal des véhicules : assurance, échéances, carburant, kilométrage, entretien et réparations ;
- une étude préalable des achats importants ;
- une cartographie du réseau professionnel par domaine d’expertise ;
- un livre de vie organisé par périodes ;
- une vision annuelle comparant intentions et réalisations ;
- une revue mensuelle générée depuis les données ;
- un inventaire numérique sans mots de passe ;
- un registre d’héritage numérique sans automatisation des démarches.

Les valeurs actives sont reprises dans les revues et dans le Conseil de Vie.

## Centre de Cohérence

Le **Centre de Cohérence** vérifie l’alignement entre les données sans qualifier les choix de bons ou de mauvais.

Il comprend :

### Graphe de connaissances

- profil, objectifs et informations associées réunis dans un graphe navigable ;
- terrains, budgets, dépenses, documents, personnes, entreprises et photos ;
- accès direct au module source de chaque nœud.

### Moteur de règles sans code

- déclencheurs sur budget, inactivité d’un objectif, échéance ou fin de projet ;
- opérateurs et seuils personnalisables ;
- création d’alerte, de rappel ou archivage des tâches terminées ;
- protection contre les exécutions répétées le même jour ;
- historique de chaque règle exécutée.

### Journal des événements

- ajouts, modifications, suppressions et règles exécutées ;
- heure, date, module et nature de l’action ;
- recherche, filtre et export texte.

### Santé des données

- champs incomplets ;
- doublons ;
- références de fichiers manquantes ;
- dépenses sans catégorie ;
- objectifs sans échéance ;
- contacts incomplets ;
- relations orphelines ;
- contrôle réel des pièces jointes dans IndexedDB ou dans le dossier VIE.

### Ingénierie des objectifs

- score descriptif de concrétisation ;
- échéance, budget, étapes, ressources et progression ;
- centre de ressources : argent, temps, matériel, compétences, personnes et documents ;
- dépendances entre étapes et signalement automatique des éléments bloqués.

### Mode annuel et audit personnel

- création ou actualisation automatique de la vision de l’année ;
- objectifs, budget, habitudes et bilan ;
- audit annuel avec finances, patrimoine, objectifs, habitudes, formations et événements ;
- génération automatique au 31 décembre lorsque l’application est utilisée ce jour-là ;
- export texte du dossier annuel.

### Alertes, versions, KPI et maturité

- alertes explicables sur absence de données, projet inactif, CV ancien, document ou entretien ;
- versions de documents avec fichier, numéro de version, restauration et archive ZIP ;
- KPI personnalisés à saisie manuelle ou calculés depuis l’épargne, le véhicule ou les candidatures ;
- niveaux de maturité non compétitifs pour finances, santé, apprentissage et projets.

Le Centre de décisions conserve désormais les risques, alternatives, décision finale, date de revue, résultat observé et leçons apprises.

## Sécurité & Protection

La sécurité est une couche transversale de VIE, active avant et après la connexion.

### Authentification et session

- compte local préconfiguré avec adresse e-mail ;
- mot de passe vérifié par PBKDF2-SHA-256 avec sel aléatoire et 310 000 itérations ;
- aucun mot de passe enregistré en clair dans le code, `localStorage`, les sauvegardes ou les exports ;
- PIN rapide facultatif pour une session déjà ouverte ;
- WebAuthn/biométrie lorsque le navigateur et le contexte le permettent ;
- déconnexion et verrouillage manuels ;
- verrouillage automatique après 1, 5, 10, 15 ou 30 minutes ;
- session mémorisable uniquement dans l’onglet courant et jusqu’à sa fermeture.

### Chiffrement local

Après la première connexion réussie :

- l’état utilisateur est chiffré par AES-GCM ;
- les pièces jointes du coffre, fichiers universels, versions documentaires et instantanés historiques sont chiffrés dans IndexedDB ;
- la copie en clair de `localStorage` est supprimée ;
- la clé dérivée du mot de passe reste uniquement en mémoire ;
- le fichier de base du dossier VIE devient `ma-vie.secure` ;
- les sauvegardes locales et du dossier sont chiffrées lorsque la session sécurisée est active.

### Réauthentification

Le mot de passe principal est redemandé pour :

- export complet ;
- import d’un espace ;
- restauration ou suppression d’une sauvegarde ;
- restauration historique ;
- ouverture et suppression d’un fichier du coffre ;
- modification des paramètres de sécurité ;
- changement du mot de passe ou du PIN ;
- suppression définitive de la corbeille.

### Archive sécurisée et transfert

- génération d’une archive `.vie` chiffrée par AES-GCM ;
- clé dérivée du mot de passe d’archive par PBKDF2 ;
- données, documents, médias et historique réunis ;
- déchiffrement local à l’import ;
- prévisualisation du nombre d’éléments ajoutés, correspondants et conservés ;
- choix entre ajout sans écrasement et remplacement après sauvegarde ;
- aucune écriture silencieuse sur les données existantes.

### Récupération

- génération d’une clé de récupération au premier déverrouillage ;
- affichage unique de la clé ;
- stockage exclusif d’une clé de chiffrement enveloppée, jamais de la clé de récupération en clair ;
- réinitialisation contrôlée du mot de passe ;
- aucun mécanisme de contournement lorsque la clé n’a pas été préparée.

### Protection post-connexion

- compteur d’inactivité ;
- fermeture des modales lors du verrouillage ;
- masquage des détails dans les notifications ;
- réauthentification systématique du coffre privé si l’option est active ;
- quatre niveaux de sensibilité ;
- journal de sécurité distinct de l’historique des données ;
- alertes de tentatives échouées, exports et restaurations ;
- limitation temporaire après plusieurs échecs de connexion.

### Profils et confidentialité visuelle

- registre local de profils privés ;
- stockage, configuration, sauvegardes, historique et journaux séparés par profil ;
- profil Invité temporaire ne donnant accès à aucune donnée du profil principal ;
- verrouillage renforcé configurable pour finances, journal, santé, relations, enfants, business et sauvegardes ;
- Mode discret masquant montants, noms et photos ;
- bouton de verrouillage immédiat ;
- raccourci Panique `Ctrl + Shift + L`.

### Conflits, diagnostic et zéro surprise

- identification de l’espace, de l’appareil, de la version et de l’empreinte SHA-256 ;
- synchronisation automatique désactivée par sécurité ;
- détection des versions locales ou distantes plus récentes ;
- choix explicite entre comparer, fusionner, conserver le local, conserver le dossier ou créer une copie ;
- fusion sans écrasement des éléments existants ;
- diagnostic de la base, de l’historique, des fichiers, des documents, des sauvegardes, de l’index et du stockage ;
- nettoyage proposé mais jamais automatique ;
- sauvegarde préalable aux imports, restaurations, fusions et suppressions définitives ;
- politique de confidentialité interne consultable dans l’application.

### Corbeille

Les suppressions des données indexées passent par une corbeille :

- conservation de 30 jours ;
- restauration dans la collection d’origine ;
- suppression définitive après réauthentification ;
- historique conservé séparément.

Principes fondamentaux : **local d’abord, accès minimal et zéro surprise**. Aucune suppression, fusion, restauration, export ou écrasement important ne doit être silencieux.

## Espace VIE, portabilité et continuité

Ma Vie dispose maintenant d’un véritable espace de données portable :

- au premier lancement, choix entre **Créer un nouvel espace VIE**, **Ouvrir un espace VIE existant** ou continuer localement ;
- identité de l’espace liée au profil de l’utilisateur, et non à l’ordinateur ;
- création automatique de la structure `VIE/Base de données`, `Documents`, `Photos`, `Rapports`, `Sauvegardes`, `Exportations`, `Paramètres` et `Médias` dans les navigateurs compatibles avec l’API d’accès au système de fichiers ;
- conservation d’une copie locale de sécurité dans `localStorage` ;
- mémorisation optionnelle de l’autorisation du dossier via IndexedDB ;
- synchronisation après les modifications et vérification des versions locales/distantes ;
- détection d’une version plus récente avant remplacement ;
- sauvegardes quotidiennes, hebdomadaires, mensuelles, manuelles et avant mise à jour ;
- historique, contrôle d’intégrité, restauration, téléchargement et suppression des versions ;
- durée de conservation et nombre maximal de versions configurables ;
- copie de documents, photos, sons et vidéos dans le dossier connecté ;
- export complet en ZIP portable avec les pièces jointes disponibles du coffre, ou JSON réimportable pour les données ;
- synthèse CSV compatible Excel, rapport imprimable en PDF et carte de progression PNG ;
- import d’une archive ZIP VIE ou d’une sauvegarde JSON ;
- diagnostic au démarrage de la base, des dossiers, des médias et des sauvegardes.

La liaison directe à un dossier dépend des capacités et autorisations du navigateur. Sur les navigateurs non compatibles, les exports ZIP/JSON restent pleinement utilisables pour transférer ou sauvegarder les données.

## Coach VIE

Le **Coach VIE** est un conseiller personnel explicable :

- il analyse uniquement les données réellement enregistrées ;
- il compare les actions aux objectifs définis par l’utilisateur ;
- il affiche la donnée utilisée derrière chaque observation ;
- il distingue priorités, éléments à anticiper et signaux positifs ;
- il couvre finances, santé, apprentissage, business, construction, relations, objectifs et discipline ;
- il peut ouvrir directement le module source ou transformer un conseil en action du jour ;
- ses domaines, sa sensibilité et l’affichage des progrès sont configurables ;
- les conseils peuvent être marqués comme traités puis réaffichés ;
- un historique des analyses est conservé localement.

Philosophie intégrée :

> Aider l’utilisateur à construire consciemment la vie qu’il souhaite, avec ses ressources, ses contraintes, ses priorités et son évolution réelle.

Le Coach observe et explique ; l’utilisateur décide. Il ne remplace jamais un médecin, un juriste, un conseiller financier ou tout autre professionnel qualifié.

## Fonctionnalités principales

- Mode Aujourd’hui avec trois priorités quotidiennes calculées et expliquées ;
- Pilotage stratégique avec ressources, jalons, scénarios, risques, Plans B, pré-mortem et revues ;
- circulation régie par une charte explicite entre objectifs, dépenses, ressources, échéances, alertes et progression ;
- neuf indicateurs indépendants de vie ;
- accomplissements significatifs et ligne de vie transversale ;
- coffre numérique avec pièces jointes locales ;
- historique visuel, carte personnelle et wiki hiérarchique ;
- inventaire complet et calendrier de maintenance ;
- vision pluriannuelle et centre de décisions ;
- liens automatiques et manuels entre les modules ;
- assistant comportemental fondé sur des observations vérifiables ;
- Conseil de Vie avec constats, opportunités et actions classées ;
- Cycles de vie avec valeurs, temps, imprévus, voyages, maison, véhicules, réseau et transmission numérique ;
- Centre de Cohérence avec graphe, règles, santé des données, ressources, dépendances, audit et maturité ;
- recherche universelle, étiquettes, favoris et éléments épinglés ;
- pièces jointes et relations disponibles pour toutes les données indexées ;
- historique restaurable et machine à remonter le temps ;
- import CSV, Excel, vCard et iCalendar ;
- bibliothèque multimédia, souhaits, simulateurs, carte d’objectifs et modèles ;
- espaces de vie et tableau de sécurité ;
- authentification locale, session sécurisée, verrouillage automatique et réauthentification ;
- stockage local, dossier VIE, serveur SQLite facultatif, sauvegardes et archives de transfert chiffrés ;
- service Windows, gestionnaire de zone de notification et démarrage automatique ;
- clé de récupération, journal de sécurité, alertes et corbeille restaurable ;
- objectifs détaillés avec finances, temps, moyens, compétences et étapes ;
- validation quotidienne des habitudes et historique de discipline ;
- rappels, reports et alertes intelligentes ;
- revenus, dépenses, budgets et objectifs d’épargne ;
- inventaire du patrimoine et suivi des entretiens ;
- projets immobiliers avec budgets liés, phases, plans versionnés, galerie Avant/Après, documents universels et visionneuse zoomable ;
- suivi des idées, clients, revenus et rentabilité business ;
- compétences, formations, certifications, livres et langues ;
- sommeil, sport, alimentation, santé mentale et rendez-vous ;
- relations, responsabilités et projets familiaux ;
- préparation de l’avenir et de l’épargne des enfants ;
- garde-robe, équipement, stocks souhaités, consommables, acquisitions confirmées et calendrier d’entretien ;
- journal avec humeur, tags et historique ;
- rapports de progression et recommandations ;
- recherche globale avec le raccourci `Ctrl + K` ;
- création rapide depuis la topbar ;
- sidebar dépliable et repliable sur ordinateur ;
- menu latéral mobile ;
- persistance automatique dans le stockage local du navigateur et IndexedDB pour les pièces jointes ;
- synchronisation optionnelle avec un dossier VIE ;
- exports ZIP, JSON, CSV compatible Excel, rapport imprimable/PDF et PNG.

## Gouvernance personnelle et circulation des données — version 11

Cette évolution consolide les angles morts du système sans ajouter une collection de nouveaux modules. Les fonctions sont réparties dans les espaces déjà existants :

- **Système personnel → Gouvernance & vision** : visions à 1, 3, 5 et 10 ans, valeurs, priorités actuelles, protections, limites et définition personnelle de la réussite ;
- **Centre de Cohérence** : capacité réelle, arbitrage entre objectifs et dette personnelle financière, administrative, personnelle ou de maintenance ;
- **Habitudes & discipline → Mes engagements** : personne concernée, promesse, échéance, importance, preuve, état et prochaine action ;
- **Centre de décisions** : options, critères, raisons, hypothèses, décision choisie, date de réévaluation, résultat observé et apprentissage avec le recul ;
- **Pilotage stratégique → Revues périodiques** : budget, durée et temps prévus comparés aux valeurs réelles et aux causes déclarées ;
- **Outils système → Recherche & organisation** : Inbox universelle pour capturer une idée, un fichier, une dépense, une tâche, un objectif, une note ou un lien avant classement ;
- **Centre de Cohérence → Santé des données** : revue mensuelle de nettoyage, sans suppression automatique ;
- **Pilotage stratégique** : niveau de préparation avant lancement, clairement distinct d’une probabilité de réussite ;
- **Objectifs & projets → Historique** : abandon conscient avec raison, ressources consommées, résultats obtenus et leçon ;
- **Journal personnel → Leçons & héritage** : journal des leçons et bibliothèque de vie, distincts de la transmission dédiée aux enfants ;
- **Centre de Vie** : trois prochains mouvements proposés à partir des échéances, engagements, risques, documents et contraintes réellement enregistrés.

### Charte de circulation

Le moteur transversal expose chaque règle avec :

- sa donnée source ;
- son déclencheur ;
- son effet autorisé ;
- sa destination d’écriture ;
- son niveau de contrôle ;
- sa présence éventuelle dans le Centre de Vie, les rappels, les alertes et les bilans.

Quatre modes sont distingués :

1. **Automatique non destructif** : recalcul déterministe, relation, preuve, rappel ou alerte traçable ;
2. **Proposition** : une action est présentée puis acceptée ou ignorée par l’utilisateur ;
3. **Confirmation obligatoire** : aucune modification n’est appliquée avant validation explicite ;
4. **Décision humaine** : VIE montre les faits mais ne peut pas choisir, arbitrer ou changer de stratégie.

Les opérations destructives, les changements de scénario, les arbitrages, l’abandon d’un objectif et les modifications de budget important ne sont jamais silencieux. Les bilans hebdomadaires et annuels peuvent inclure gouvernance, capacité, engagements, dette personnelle, décisions, leçons, objectifs arrêtés et écarts prévu/réel sans modifier leurs données sources.

Principe conservé :

> **Local d’abord, accès minimal et zéro surprise.**

## Moteur de progression automatique — version 18.2

VIE introduit `ProgressEngine 1.0.0`. Dans les domaines déjà migrés, aucun pourcentage de progression ne peut être saisi directement. Les anciennes valeurs manuelles sont recalculées à l’ouverture puis avant chaque sauvegarde.

### Couverture actuelle

- compétences ;
- formations ;
- objectifs et projets d’objectif ;
- sous-objectifs ;
- étapes et actions liées ;
- projets, phases et tâches de construction.

Les autres domaines sont inscrits dans `progressEngine.pendingScopes` et seront migrés progressivement : Business, feuilles de carrière, famille, cycles de vie et bibliothèques.

### Règles explicables

**Compétence**

```text
4 étapes factuelles :
origine documentée
+ apprentissage
+ mise en pratique
+ validation externe
```

Le score correspond au nombre d’étapes documentées sur quatre. Le niveau cible est choisi sous forme Débutant, Intermédiaire, Avancé ou Expert, jamais comme pourcentage.

**Formation**

```text
modules terminés ÷ modules définis
```

Une formation explicitement terminée vaut 100 %. Le formulaire accepte les états `todo`, `active` et `completed`, pas un nombre de progression.

**Objectif**

```text
étapes terminées ou actions liées terminées
```

S’il existe des étapes, elles pilotent le calcul. Sinon VIE utilise les sous-objectifs, puis les actions. Un objectif marqué terminé vaut 100 %.

**Construction**

```text
moyenne des phases
phase = terminée ou tâches terminées ÷ tâches définies
```

Une entrée de journal ou une photo de chantier documente l’évolution mais ne modifie plus directement le pourcentage.

Chaque résultat conserve un `progressMeta` avec méthode, numérateur, dénominateur, explication et version du moteur. Il s’agit d’une progression factuelle, jamais d’une probabilité de réussite.

## Défilement fluide des barres d’onglets — version 18.1

Les barres d’onglets des 16 routes concernées disposent maintenant d’un contrôleur horizontal commun :

- boutons précédent et suivant affichés uniquement en cas de débordement ;
- défilement tactile natif avec inertie ;
- conversion de la molette verticale en déplacement horizontal lorsque la barre peut encore défiler ;
- retour au défilement normal de la page lorsque le début ou la fin est atteint ;
- indicateurs de fondu sur les côtés ;
- barre de défilement discrète sur ordinateur ;
- navigation clavier avec Gauche, Droite, Début et Fin ;
- recentrage instantané de l’onglet actif après un changement de contenu ;
- conservation de la position pendant le rendu partiel des onglets.

Le composant est injecté après chaque rendu sans imbriquer plusieurs contrôleurs. Sur téléphone, les flèches restent disponibles en complément du glissement horizontal.

## Sphère de compétences et capital humain — version 18

La page **Carrière & apprentissage → Sphère de compétences** devient le premier espace React métier complet de VIE.

### Stores spécialisés

Les données restent hors du registre générique des entités :

- `skillStore` : compétence, catégorie, niveau sémantique, score, cible, dates, sources et preuves ;
- `trainingStore` : formation, organisme, période, durée, coût, énergie, roadmap, compétences produites et certification ;
- `certificateStore` : certification, organisme, validité, document et formation d’origine ;
- `portfolioStore` : projets et preuves de réalisation ;
- `skillUpdateEvents` : propositions d’évolution en attente, acceptées ou ignorées ;
- `skillBaselines` : instantanés temporels du capital humain.

Ces collections sont chiffrées et sauvegardées avec l’état VIE, mais ne deviennent pas de nouveaux `EntityType` du Core.

### Formation comme événement d’évolution

Une formation enregistre explicitement :

- temps en heures ;
- coût et devise ;
- énergie demandée ;
- objectifs liés ;
- modules et progression ;
- compétences attendues ;
- certification ;
- preuves et références.

Terminer une formation ne modifie jamais automatiquement une compétence. VIE capture une baseline et crée un `skillUpdateEvent` pour chaque capacité produite. L’utilisateur valide ou ignore séparément chaque proposition.

Lors d’une validation, la compétence reçoit :

- son nouveau score et son niveau sémantique ;
- la formation comme source ;
- les preuves et la certification ;
- une date de mise à jour ;
- une nouvelle baseline après évolution.

### Interface React

La sphère place l’utilisateur au centre et répartit les compétences autour de lui. Les liens pointillés indiquent des compétences issues d’une même formation. Le panneau de détail affiche niveau, cible, sources, preuves et objectifs qui requièrent la compétence.

Sur téléphone, la sphère devient une liste de cartes sans réduire artificiellement le graphe. Les propositions d’évolution restent visibles sous forme de cartes de validation.

### Matching Objectifs ↔ compétences

Le contrat `vie.skill-sphere.v1` compare les compétences du `skillStore` aux exigences déclarées dans les objectifs. Il restitue uniquement l’écart observé entre score actuel et score requis ; aucune probabilité de réussite n’est inventée.

## Illustrations vectorielles pour chaque page — version 17.2

Les 23 routes principales disposent désormais d’une illustration SVG distincte : Centre de Vie, Pilotage stratégique, Conseil de Vie, Centre de Cohérence, Cycles, Coach, Système personnel, Outils, Profil, Objectifs, Discipline, Rappels, Finances, Immobilier, Business, Carrière, Santé, Relations, Enfants, Apparence, Journal, Rapports et Espace VIE.

Les illustrations sont regroupées dans le sprite SVG interne de `index.html` :

- aucun fichier PNG, JPG ou SVG externe ;
- aucune requête réseau ;
- poids réduit et mise à l’échelle sans perte ;
- `aria-hidden` pour les illustrations décoratives ;
- couleurs adaptées au domaine sans bande latérale ou supérieure ;
- grille dédiée sur ordinateur et recomposition compacte sur téléphone ;
- animation d’entrée unique, supprimée avec `prefers-reduced-motion`.

Le composant React `VieIllustration` utilise le même sprite que les pages JavaScript. Le Mode Aujourd’hui possède donc également son illustration en mode React et dans son HTML de repli.

## Design System VIE et frontière Core/React — version 17.1

La migration React dispose maintenant d’une frontière explicite :

```text
VIE Core
   ↓
VieViewAdapters — contrats figés et minimaux
   ↓
VieShell — intentions déclaratives
   ↓
Composants React
```

`VieViewAdapters` est un script local pur, sans accès au stockage. Il transforme l’état métier en contrats versionnés tels que `vie.today-hero.v1`, `vie.objective-summary.v1`, `vie.resource-summary.v1`, `vie.skill-sphere.v1` et `vie.timeline.v1`. Les objets produits sont profondément figés et ne contiennent ni mot de passe, ni configuration de sécurité, ni accès SQLite.

Le Design System initial comprend :

- `VieShell` et `useVieIntent` ;
- `VieCard` ;
- `VieGlassPanel` ;
- `VieButton` ;
- `VieBadge` ;
- `VieProgress` ;
- `VieTimeline` ;
- `VieEmptyState` ;
- `VieModal` ;
- `useVieEntrance` avec Framer Motion DOM mini.

Le bandeau du Mode Aujourd’hui utilise désormais `VieShell`, `VieBadge`, `VieButton` et `VieGlassPanel`. React émet seulement des intentions comme `{ type: "navigate", route: "cycles" }` ; le moteur VIE valide et exécute l’action.

Le glassmorphisme reste limité aux surfaces de pilotage peu denses. Il n’est pas appliqué aux tableaux, paramètres, formulaires ou historiques volumineux.

## Migration progressive vers React — version 17

La migration frontend a commencé sans réécriture brutale :

- **React 19** et React DOM sont intégrés localement ;
- **Tailwind CSS** est compilé avec le préfixe `tw-` et sans réinitialisation globale ;
- **Framer Motion** utilise son moteur DOM mini pour limiter le poids ;
- **Vite** produit un bundle IIFE compatible avec l’application actuelle ;
- aucun CDN ou accès Internet n’est utilisé à l’exécution.

Le premier îlot React remplace le bandeau du **Mode Aujourd’hui** : salutation horaire, horloge, cycle actif et navigation. Les données restent détenues par le cœur VIE ; React reçoit uniquement les propriétés nécessaires et renvoie les intentions de navigation au moteur existant.

L’ancien HTML demeure dans la vue comme repli : si le bundle React ne peut pas être chargé, le Dashboard reste utilisable. Les racines React sont démontées explicitement avant un changement de route afin d’éviter les fuites mémoire.

Les 23 routes et les 731 actions restent disponibles. Les modules seront migrés progressivement, en commençant par les composants partagés, sans déplacer le chiffrement vers le serveur et sans supprimer le mode autonome.

### Construction reproductible

```bash
cd frontend-react
npm ci
npm run build
```

`node_modules` est réservé au développement. Le paquet utilisateur contient seulement `vie-react-bridge.js` et `vie-react.css` dans `assets/react`.

## Menus d’actions uniformes dans les tableaux — version 16.4

Toutes les lignes de tableaux qui possèdent une colonne d’actions sont désormais normalisées automatiquement :

- bouton compact à trois points dans la dernière colonne ;
- menu contextuel avec libellés français dérivés de l’action réelle ;
- conservation intégrale des commandes existantes — modifier, supprimer, consulter, télécharger, restaurer, changer l’état ou enregistrer ;
- menu flottant qui n’est pas coupé par le défilement horizontal du tableau ;
- fermeture au clic extérieur, au défilement, au redimensionnement ou avec Échap ;
- navigation au clavier avec les flèches et restauration du focus ;
- recomposition en panneau inférieur avec fond de fermeture sur téléphone.

Le système est appliqué après chaque rendu complet et après chaque changement d’onglet fluide. Les tableaux sans colonne d’actions restent inchangés.

## Navigation ultra fluide entre les onglets — version 16.3

Le moteur de rendu distingue maintenant trois situations :

- **changement de route** : nouvelle page et retour contrôlé en haut ;
- **changement d’onglet interne** : seuls la sous-navigation, les actions contextuelles et le contenu de l’onglet sont remplacés ;
- **mise à jour de données sur la même route** : le défilement est conservé et aucune animation complète de page n’est relancée.

Lors d’un changement d’onglet, le conteneur principal de la page reste physiquement le même dans le DOM. La position verticale, le défilement horizontal de la barre d’onglets et le focus clavier sont restaurés. Une transition de contenu de 180 ms remplace l’ancienne animation complète, sans requête réseau ni rechargement du document.

## Interface plus vivante, sans surcharge — version 16.2

Cette évolution ajoute une présence visuelle discrète sans réintroduire d’images ou de données fictives :

- salutation adaptée à l’heure locale et horloge réelle dans le Mode Aujourd’hui ;
- transitions courtes entre les pages et apparition progressive des cartes ;
- profondeur légère au survol, réactions des icônes et pression visible des boutons ;
- ambiance lumineuse très douce dans l’espace de travail et le bandeau du jour ;
- états vides plus chaleureux avec actions de démarrage explicites ;
- animation de validation des tâches et durée visible des notifications ;
- avatar par initiales animé subtilement lorsqu’aucune photo personnelle n’est définie.

Toutes les animations respectent `prefers-reduced-motion` et sont neutralisées lorsque l’utilisateur demande moins de mouvement. Aucune bande colorée n’a été réintroduite sur les cartes du Dashboard, du Coach VIE ou du Centre de Cohérence.

## Démarrage vide et suppression des médias de démonstration — version 16.1

Le paquet ne charge plus de données métier fictives lors d’une nouvelle installation, de la création d’un profil ou de l’ouverture du profil Invité. Objectifs, transactions, habitudes, projets, journaux, relations, construction, inventaire, santé, carrière et autres collections commencent vides.

Les photos et illustrations fournies uniquement pour la démonstration ont été retirées du paquet. L’interface utilise désormais :

- des initiales lorsque le profil n’a pas de photo personnelle ;
- le mannequin vectoriel interactif déjà intégré au code, sans image PNG ;
- des états vides invitant l’utilisateur à créer ses propres éléments ;
- uniquement la police locale nécessaire à l’identité visuelle.

Une mise à jour ne supprime jamais silencieusement les données personnelles déjà chiffrées. Le menu du profil propose **Réinitialiser vers un espace vide** : il crée d’abord une sauvegarde, conserve le compte et la sécurité, puis efface explicitement les données métier du profil.

## HTTPS local et chaîne de sécurité — version 16

VIE utilise désormais le serveur local comme mode principal recommandé :

```text
Navigateur
   ↓ HTTPS/TLS — certificat localhost approuvé
Session locale — cookies Secure/HttpOnly/SameSite + jeton CSRF
   ↓
VIE Server — 127.0.0.1 uniquement
   ↓
Enveloppes AES-GCM déjà chiffrées
   ↓
SQLite, pièces jointes, sauvegardes et journal d’audit
```

### Certificat local sans bricolage manuel

`INSTALLER-VIE.bat` réalise explicitement les opérations suivantes :

1. création d’une autorité locale propre à VIE et d’un certificat serveur valable pour `localhost`, `127.0.0.1` et `::1` ;
2. installation de l’autorité publique dans le magasin de confiance Windows ;
3. conservation de la seule clé privée du serveur dans `C:\VIE\server\tls`, sous les droits NTFS réduits ;
4. démarrage du service sur `https://localhost:8080/vie/` ;
5. contrôle de santé HTTPS après installation.

La clé privée de l’autorité de certification n’est jamais conservée après la signature du certificat serveur. La commande `init-tls` réutilise un certificat encore valide ; `renew-tls` effectue une rotation explicite. Le script `reparer-https.ps1` réinstalle la confiance locale sans demander OpenSSL à l’utilisateur.

### Transport et session

- TLS 1.2 minimum et TLS 1.3 privilégié ;
- redirection HTTP 308 vers HTTPS sur le même port pour les anciens raccourcis ;
- HSTS après la première connexion HTTPS réussie ;
- cookie de session `__Host-…`, `Secure`, `HttpOnly` et `SameSite=Strict` ;
- jeton CSRF distinct exigé dans un en-tête personnalisé ;
- contrôle de l’origine et de `Sec-Fetch-Site` ;
- nouveau jeton serveur à chaque redémarrage, ce qui invalide les anciennes sessions de transport ;
- aucune écoute sur `0.0.0.0`.

Le verrouillage applicatif reste séparé : dérivation PBKDF2, clé maître indépendante, effacement de la clé de session lors du verrouillage, délai d’inactivité, limitation des tentatives, réauthentification des opérations sensibles et journal d’événements de sécurité.

### Fichiers, sauvegardes et opérations sensibles

Les contrôles existants restent actifs : tailles maximales, identifiants normalisés, chemins confinés aux dossiers autorisés, enveloppe AES-GCM obligatoire, empreinte SHA-256, corbeille temporaire, sauvegarde préalable aux suppressions importantes et conflits de révision sans écrasement silencieux.

HTTPS protège le transport local ; il ne remplace ni le chiffrement au repos, ni la sécurité de Windows, ni les sauvegardes. Une compromission administrateur du système d’exploitation reste hors de portée de l’application.

### Mode autonome

Le mode `file://` est conservé comme secours portable et hors service. Il ne bénéficie ni de TLS, ni de SQLite, ni des sauvegardes serveur. L’interface l’indique comme **mode autonome de secours**, sans empêcher l’accès aux données locales chiffrées.

## Dashboard factuel et préparation interactive — version 15

**Correctif 15.0.1 :** les anciennes règles visuelles ont été retirées à la source, toutes les cartes du Dashboard concernées utilisent désormais une bordure neutre, et les fichiers CSS/JavaScript sont versionnés dans `index.html` afin d’éviter l’affichage d’une ancienne copie en cache.

Cette correction remplace les indicateurs abstraits du Dashboard par des statistiques directement calculées depuis les données enregistrées.

### Vue d’ensemble réelle

La Vue d’ensemble affiche maintenant, selon Aujourd’hui, les 7 derniers jours ou le mois courant :

- revenus enregistrés et nombre d’opérations ;
- dépenses enregistrées ;
- solde exact de la période ;
- actions du jour réalisées et ouvertes ;
- habitudes réalisées, manquées et à faire ;
- objectifs actifs, en retard et bloqués ;
- échéances et rappels de la période ;
- dépenses chantier réellement enregistrées ;
- entretiens, documents et engagements à traiter.

Chaque carte précise sa donnée source, sa période et ouvre le module correspondant. Les cadrans `/100` ont été supprimés de cette partie du Dashboard.

### Cartes sans bandes colorées

Les bandes latérales ou supérieures rouges, orange, vertes et bleues ont été supprimées des cartes de :

- Prochain meilleur mouvement ;
- Coach VIE ;
- Centre de Cohérence ;
- alertes intelligentes ;
- règles de circulation ;
- minimum viable.

Les états restent lisibles par leur texte, leur icône et leurs étiquettes, sans transformer la bordure de la carte en signal décoratif.

### Prêt à démarrer ?

L’ancien ensemble de blocs a été remplacé par une liste interactive et neutre :

- score de préparation dans une barre horizontale ;
- nombre d’éléments prêts, partiels et manquants ;
- huit lignes factuelles : objectif, budget, temps, compétences, documents, risques, première action et Plan B ;
- valeur et explication de chaque source ;
- bouton « Mettre à jour » sur chaque ligne ;
- ouverture directe du formulaire de ressource ou du module concerné ;
- décisions Démarrer ou Reporter toujours laissées à l’utilisateur.

Aucun bloc noir ni indicateur informe n’est utilisé dans cette vue.

## Construction multimédia et audit d’interface — version 14

Cette évolution n’ajoute pas un système de fichiers propre à l’immobilier. Elle spécialise les **pièces jointes universelles** de VIE pour les projets de construction, tout en conservant les mêmes règles de chiffrement, recherche, historique et portabilité.

### Projets enrichis

Chaque projet peut maintenant conserver :

- nom, type, localisation et statut ;
- objectif, description et notes ;
- budget prévu, consommé et restant ;
- dates de début et cible ;
- progression et priorité ;
- intervenants ;
- plans, documents, médias, phases, risques, dépenses et historique ;
- image de couverture chiffrée.

### Plans et versions

Les plans prennent en charge :

- architecture, fondations, électricité, plomberie, toiture, façade et 3D ;
- images SVG, JPG, PNG et WebP ;
- documents PDF ;
- auteur, date, statut et numéro de version ;
- ajout, modification, remplacement, consultation, téléchargement et suppression ;
- conservation automatique de la version précédente lorsqu’un fichier est remplacé.

Aucun plan n’est écrasé silencieusement.

### Galerie et chronologie visuelle

La galerie regroupe les médias du projet par date, phase et nature :

```text
Avant → Fondations → Murs → Toiture → Finitions → Après
```

Elle comprend :

- ajout multiple de photos et vidéos ;
- miniatures chargées paresseusement ;
- filtres Photo, Plan, Vidéo et Document ;
- comparaison Avant / Après avec curseur ;
- chronologie horizontale ;
- dépenses et phase associées à chaque entrée du journal ;
- suppression confirmée vers la corbeille.

### Visionneuse universelle

Les images, plans, vidéos et PDF peuvent être ouverts dans une visionneuse cohérente avec VIE :

- zoom de 50 à 400 % ;
- déplacement par souris ou geste tactile ;
- précédent et suivant ;
- réinitialisation ;
- plein écran ;
- métadonnées ;
- téléchargement ;
- navigation clavier ;
- focus contenu dans la fenêtre ;
- libération des URL temporaires après fermeture.

Cette visionneuse est également utilisée par les pièces jointes universelles hors Construction.

### Documents et recherche globale

Les catégories suivantes sont disponibles :

- plans ;
- devis ;
- factures ;
- contrats ;
- documents administratifs ;
- photos ;
- vidéos ;
- notes.

Plans, documents, journaux et pièces jointes sont indexés dans la recherche globale de VIE.

### Construction ↔ Finances

Une dépense de chantier confirmée contient le projet, la phase, le poste, le fournisseur, la quantité, le prix et le justificatif. La validation :

1. crée ou met à jour une seule transaction financière ;
2. recalcule le budget consommé du projet ;
3. relie la transaction au projet et à la phase ;
4. chiffre et rattache la facture éventuelle ;
5. actualise l’interface sans rechargement de page.

La création d’une dépense depuis Finances peut également produire l’écriture chantier liée lorsque le projet est sélectionné.

### Responsive et modales

L’audit d’interface apporte :

- recomposition des dépenses et documents en cartes sur téléphone ;
- grilles adaptées aux grands écrans, ordinateurs portables et tablettes ;
- visionneuse plein écran sur mobile ;
- modales en panneau inférieur sur téléphone ;
- champs et boutons tactiles d’au moins 44 pixels ;
- focus clavier contenu dans les dialogues ;
- validation immédiate des champs ;
- état de traitement pendant les opérations asynchrones ;
- messages d’erreur intégrés ;
- transition d’ouverture et de fermeture ;
- absence de rechargement complet lors des modifications.

L’ensemble conserve les couleurs, composants, transitions et comportements du reste de VIE.

## Stabilité des onglets et SVG Construction — version 18.7.3

La barre d’onglets de Construction & immobilier ne transforme plus la molette verticale en mouvement horizontal. Le recentrage initial et les redimensionnements sont stabilisés, le scroll snapping automatique est désactivé et les flèches gardent une largeur fixe afin d’éviter toute oscillation visuelle.

Les icônes du contenu Construction sont normalisées en SVG de contour (`fill:none`, `stroke:currentColor`) et l’illustration immobilière a été redessinée avec des formes fermées pour éviter les aplats noirs ou déformés selon le navigateur et l’échelle Windows.

## Assistance Windows qui reste ouverte — version 18.7.2

Le paquet contient maintenant un point d’entrée unique à sa racine :

```text
COMMENCER-ICI.cmd
```

Il ouvre le menu `server\AIDE-VIE-NE-SE-FERME-PAS.cmd`, qui attend explicitement un choix et ne disparaît pas après une erreur. Il permet d’installer ou mettre à jour, diagnostiquer la page blanche, démarrer le serveur au premier plan, ouvrir VIE et consulter les journaux sans lancer directement les exécutables ou scripts PowerShell.

## Correctif installation Windows et page blanche — version 18.7.1

Le serveur Windows installait les fichiers principaux et le dossier `assets`, mais une ancienne version de `index.html` chargeait `recurrence-engine.js` à la racine alors que l’installateur ne copiait pas ce fichier. Le serveur refusait également les fichiers JavaScript racine non listés. Cela pouvait produire une page blanche après mise à jour.

Le moteur de récurrence est maintenant livré comme ressource autorisée :

```text
assets/recurrence-engine.js
```

L’installateur vérifie le paquet avant élévation, copie et contrôle toutes les ressources de démarrage, arrête l’ancien gestionnaire de zone de notification, teste l’API puis chaque fichier en HTTPS, ouvre une URL avec cache renouvelé et affiche un message clair de réussite ou d’échec. Les données et sauvegardes de `C:\VIE` restent conservées.

Un outil non destructif est installé dans :

```text
C:\VIE\server\DIAGNOSTIC-VIE.bat
```

Il vérifie service, configuration, certificat, fichiers et réponses HTTPS. En cas d’échec de démarrage, l’interface affiche désormais des instructions de réparation au lieu d’une page blanche silencieuse.

## Verticale Alimentation : catalogue, panier et budget — version 18.7

Cette version termine un parcours Alimentation de bout en bout dans le domaine spécialisé, sans ajouter d’article au Core :

```text
Catégorie Alimentation
   ↓
Catalogue d’articles réutilisables
   ↓
Panier modifiable
   ↓ validation humaine
Purchase par article
   ↓
Au maximum une transaction financière partagée
   ↓
Budget réel + occurrences futures + écart
```

### Catalogue et panier

Les articles alimentaires existants apparaissent dans un catalogue avec image, sous-catégorie, unité et prix. La recherche est locale. Ajouter plusieurs fois le même article augmente sa quantité au lieu de créer des doublons.

Le panier permet de modifier directement :

- la quantité ;
- le prix unitaire ;
- le total de chaque ligne ;
- la présence de l’article.

Tant que le panier n’est pas validé, il ne représente ni achat ni dépense. Lors du checkout, VIE crée un `Purchase` par article avec un `batchId` commun. Si l’utilisateur coche la synchronisation financière, une seule transaction est créée pour le total du panier afin d’éviter toute double comptabilisation.

### Budget Alimentation

Pour chaque mois, la verticale calcule :

- le budget cible défini par l’utilisateur ;
- les achats réels du `PurchaseStore` ;
- les achats futurs issus des occurrences ;
- la projection totale ;
- l’écart restant ou le dépassement.

Ces calculs ne nécessitent pas de suivre chaque utilisation d’un aliment. Le contrat figé `vie.purchase-workspace.v1` présente catalogue, panier et budget à React sans lui donner accès au stockage.

> **Panier ≠ achat ; occurrence ≠ dépense ; checkout confirmé = achats réels et au maximum une écriture financière.**

## Articles, achats et budget prévisionnel — version 18.6

Cette version stabilise le domaine spécialisé des achats sans ajouter de nouvel `EntityType` générique au Core :

```text
ArticleStore
├── identité
├── imageBlobId
├── categoryId / subcategoryId
├── caractéristiques
├── prix indicatif
└── frequencyRuleId
        ↓
PurchaseStore
├── articleId
├── quantité
├── prix unitaire / prix total
├── date
└── magasin ou source
        ↓
FrequencyRule + RecurrenceBinding
        ↓
Occurrence budgétaire calculée
```

La même fiche article peut donc recevoir dix achats successifs sans dupliquer son identité, son image ou sa classification.

### Classification hiérarchique et personnalisable

Le store `consumptionCategoryStore` fournit une taxonomie locale initiale :

- Alimentation : épicerie, boissons, produits frais, snacks ;
- Hygiène & soins : dentaire, douche, cheveux, soins corporels ;
- Maison : nettoyage, entretien, cuisine, linge ;
- Vêtements : hauts, bas, chaussures, accessoires ;
- Études & travail : fournitures, livres, matériel ;
- Électronique : accessoires, câbles, périphériques ;
- Transport, Santé et Autre.

L’utilisateur peut créer ses propres catégories et sous-catégories, les modifier, les archiver ou supprimer celles qui ne sont reliées à aucune donnée. Une catégorie encore utilisée est archivée plutôt que supprimée afin de ne casser aucun historique.

### Images locales

Une fiche article accepte :

- une photo importée depuis le PC ;
- une photo prise depuis un appareil compatible grâce à `capture="environment"` ;
- une image déjà présente dans les Fichiers universels de VIE ;
- une illustration SVG inline de VIE en solution de repli.

L’article ne conserve que `imageBlobId` et une miniature. Le fichier original reste dans le stockage universel local et chiffré. Les SVG personnels sont nettoyés puis rasterisés en PNG avant stockage.

### Fiche article et budget

Chaque fiche affiche maintenant :

- catégorie → sous-catégorie ;
- image et caractéristiques ;
- prix habituel ;
- FrequencyRule et sa révision ;
- dernier et prochain achat ;
- progression du cycle de renouvellement ;
- nombre d’achats documentés.

Le budget prévisionnel mensuel additionne les occurrences réelles du calendrier par catégorie. Les regroupements de trois achats ou plus dans les sept prochains jours produisent un signal explicable avec montant estimé. Ces montants restent non engagés : aucune transaction n’est créée avant confirmation d’un achat réel.

Le contrat de présentation devient `vie.consumption-overview.v2` et conserve les principes : image locale, fréquence séparée, achat explicite et absence de suivi de chaque utilisation.

> **Article, Purchase et FrequencyRule sont trois données différentes reliées par des identifiants stables.**

## Routine & Recurrence Engine — version 18.5

Cette version transforme le contrat de fréquence en première brique fonctionnelle complète :

```text
Objet métier
   ↓ RecurrenceBinding
FrequencyRule révisable
   ↓ moteur pur et déterministe
Occurrence calculée
   ↓ action humaine
Execution persistée
```

### Moteur déterministe local

Le fichier autonome `recurrence-engine.js` ne lit aucun stockage, n’effectue aucune requête et ne modifie aucun domaine. À entrées identiques et date de référence identique, il produit exactement les mêmes clés d’occurrence.

Le moteur prend en charge dans cette première verticale :

- `CALENDAR_SLOTS` pour les habitudes et activités avec jours et heures choisis ;
- `ROLLING_INTERVAL` pour les achats prévisibles et entretiens ;
- `EXPLICIT_DATES` comme contrat initial pour les dates ponctuelles répétées ;
- semaines ISO du lundi au dimanche ;
- ancrages `FIXED_CALENDAR`, `LAST_DOMAIN_EVENT` et `LAST_COMPLETION` ;
- états `PLANNED`, `DONE`, `MISSED`, `SKIPPED` et `CANCELLED` ;
- `MISSED` calculé depuis le calendrier, jamais inventé comme événement ;
- clés déterministes incluant règle, révision, date et créneau ;
- contrôle d’intégrité des règles, bindings, exécutions et doublons.

Les tests de contrat reproductibles peuvent être exécutés sans dépendance :

```bash
node tests/recurrence-engine.test.js
node tests/routine-commitment.test.js
node tests/routine-ui-contract.test.js
node tests/reflective-memory.test.js
node tests/reflective-ui-contract.test.js
node tests/life-compass.test.js
node tests/life-compass-ui-contract.test.js
node tests/budget-allocation.test.js
node tests/budget-allocation-ui-contract.test.js
node tests/purchase-workspace-v2.test.js
node tests/purchase-catalog-ui-contract.test.js
node tests/purchase-calendar.test.js
node tests/purchase-calendar-ui-contract.test.js
node tests/expense-taxonomy.test.js
node tests/expense-taxonomy-ui-contract.test.js
node tests/consumption-contract.test.js
node tests/purchase-workspace.test.js
node tests/windows-package.test.js
node tests/construction-ui-contract.test.js
```

Les occurrences restent des projections et ne sont pas persistées. Seuls sont conservés :

- les règles ;
- leurs anciennes révisions ;
- les bindings ;
- les exécutions réellement validées.

### Première migration progressive

Trois domaines existants alimentent maintenant le moteur sans devenir des `EntityType` génériques :

- `HabitStore` → calendrier fixe ;
- `ConsumptionStore` → intervalle depuis le dernier achat réel ;
- `MaintenanceStore` → intervalle depuis la dernière intervention terminée.

Une modification des jours, heures ou intervalles crée une nouvelle révision de règle. Une exécution ne modifie jamais la fréquence source.

### Utilisation visible

Le Mode Aujourd’hui affiche désormais le **Programme récurrent d’aujourd’hui**, groupé en Matin, Journée et Soir. Une occurrence peut être :

- terminée ;
- ignorée explicitement ;
- rouverte ;
- renvoyée vers son module source ;
- transformée en achat réel uniquement depuis le formulaire d’achat contrôlé.

Le nouvel onglet **Système personnel → Fréquences & occurrences** affiche :

- la semaine réelle sur sept jours ;
- la progression automatique `exécutions ÷ occurrences` ;
- les règles et bindings actifs ;
- les occurrences manquées et restantes ;
- les ressources temporelles et financières estimées ;
- l’historique des exécutions ;
- le diagnostic d’intégrité.

Les habitudes acceptent plusieurs moments au format `Matin | 08:00`. Les entretiens ne demandent plus la prochaine date : elle est dérivée de la dernière intervention et de l’intervalle.

Le contrat profondément figé `vie.recurrence-plan.v1` permet à React de présenter ces projections sans accéder aux stores ou au stockage.

> **Une occurrence prévue n’est ni du temps réellement consommé, ni une dépense réelle, ni une preuve d’exécution.**

## Contraintes personnelles récurrentes — version 18.8

Les routines d’entretien personnel restent des objets du `HabitStore`. VIE ne crée ni nouveau store, ni nouvelle primitive Core :

```text
Habitude ou routine
   ↓ RecurrenceBinding
FrequencyRule { commitment: "REQUIRED" | "OPTIONAL" }
   ↓
Occurrence dérivée : PLANNED → DONE ou MISSED
```

- `REQUIRED` exprime une contrainte personnelle à protéger dans le plan ;
- `OPTIONAL` exprime une activité souhaitée ;
- aucun des deux états ne crée une exécution automatiquement ;
- `DONE` exige toujours une validation humaine ;
- `MISSED` reste dérivé lorsque la fenêtre est passée ;
- un achat prévisible reste `OPTIONAL` et ne devient jamais une obligation ;
- modifier l’engagement crée une nouvelle révision de la `FrequencyRule` sans écraser l’ancienne.

Le Mode Aujourd’hui sépare maintenant **Obligatoire**, **À examiner** et **Habitudes**. Il affiche aussi le suivi hebdomadaire par routine, par exemple `Laver le linge 0/1`. L’onglet **Fréquences & occurrences** présente les contraintes obligatoires avant les activités optionnelles. Le bouton **Nouvelle contrainte** ouvre le formulaire habituel préconfiguré pour l’entretien personnel, mais l’utilisateur choisit lui-même les jours et heures.

Le contrat `vie.recurrence-plan.v1` reste inchangé. Le nouveau contrat profondément figé `vie.recurrence-plan.v2` ajoute uniquement la sémantique `commitment`, les sous-résumés REQUIRED/OPTIONAL, les ressources temporelles et budgétaires séparées et des intentions déclaratives. Le moteur local passe en version `1.1.0`.

> **Obligatoire signifie « à protéger dans mon plan », jamais « réalisé automatiquement ».**

## Mémoire réflexive et conseils traçables — version 18.9

VIE enrichit le module **Journal personnel** sans créer de nouvelle primitive Core. Les données restent dans deux stores spécialisés :

```text
ThoughtStore — pensée conservée telle quelle
ReflectionStore — développement rédigé par l’utilisateur
        ↓ relations explicites
VieViewAdapters.reflectiveMemory
        ↓ contrat figé
Journal · Conseil de Vie · Coach VIE · Rapports & analyses
```

Trois statuts épistémiques restent strictement séparés :

- `DECLARED` : contenu effectivement formulé par l’utilisateur ;
- `DERIVED` : comptage descriptif ou rapprochement calculé ;
- `ADVICE` : proposition contextuelle à examiner.

Une pensée possède son contenu, sa date, son contexte, ses thèmes, sa source éventuelle et des relations vers une observation, une décision, un objectif ou un projet. Une réflexion peut développer plusieurs pensées par identifiants stables. Le texte de la pensée n’est jamais copié dans les autres modules.

Une réflexion peut contenir un **principe potentiel**, mais le bouton **Adopter comme principe** exige une confirmation explicite. L’adoption crée une relation de provenance ; aucune réflexion ne devient automatiquement une règle de vie.

La carte conceptuelle compte les thèmes qui reviennent et affiche leurs preuves. Elle peut dire :

> « Partage apparaît dans trois éléments déclarés. »

Elle ne peut pas dire :

> « Vous êtes une personne définie par le partage. »

Les conseils réflexifs n’existent que lorsqu’une pensée ou une réflexion a été reliée explicitement à une décision, un objectif ou un projet. Chaque conseil propose **Pourquoi me dis-tu ça ?** et expose la chaîne :

```text
DECLARED → DERIVED → ADVICE
```

Le contrat profondément figé `vie.reflective-memory.v1` fournit pensées, réflexions, thèmes, principes, relations, conseils, provenance, rapport d’évolution factuelle et diagnostic d’intégrité. Il ne lit aucun stockage et ne réalise aucune requête réseau.

Le rapport de réflexion affiche les thèmes récurrents, pensées, réflexions, décisions, objectifs et projets associés. Il est exportable avec ses sources et rappelle qu’aucune conclusion psychologique automatique n’est autorisée.

> **Pensée ≠ réflexion ≠ principe ≠ conseil.**

## Boussole de vie et baselines de vision — version 19.0

La **Boussole de vie** conserve la conception personnelle et datée de la réussite sans prétendre définir une vie réussie pour l’utilisateur.

```text
Pensées + principes
        ↓ déclaration explicite
Baseline de vision immuable
        ↓ dimensions et sources choisies
Boussole de vie
        ↓ comparaison descriptive
Revue périodique
```

Une baseline contient :

- une définition personnelle actuelle de la réussite ;
- une date et un numéro de révision ;
- des dimensions entièrement révisables ;
- un poids déclaré pour chaque dimension ;
- une hiérarchie facultative ;
- les sources factuelles que l’utilisateur souhaite relier ;
- une question de revue périodique ;
- la référence à la baseline précédente.

Le formulaire propose `Devenir`, `Aimer`, `Construire`, `Partager` et `Transmettre`, mais ces dimensions ne deviennent jamais une doctrine de VIE. L’utilisateur peut les renommer, les supprimer, en ajouter, modifier leur hiérarchie et choisir leurs sources avant de créer la baseline. La somme des poids doit être explicitement validée à `100 %`.

Une baseline publiée n’est jamais modifiée ou supprimée depuis la Boussole. Toute évolution crée une nouvelle révision et conserve l’ancienne. Le comparateur peut uniquement constater :

> « La conception déclarée de la réussite présente quatre modifications entre les baselines 01 et 02. »

Il ne qualifie pas cette évolution de bonne, mauvaise ou incohérente.

La Boussole compare quatre faits distincts :

- importance déclarée ;
- temps ou traces enregistrés ;
- activités documentées ;
- accomplissements explicitement enregistrés.

Les résultats utilisent les libellés `moins documenté`, `davantage documenté`, `proche dans les traces` ou `aucune base enregistrée`. Ils ne constituent ni une note de réussite, ni une mesure de valeur humaine. Une absence de donnée dans VIE ne prouve jamais une absence dans la vie réelle.

Le contrat profondément figé `vie.life-compass.v1` expose les baselines, dimensions, comparaisons, preuves, période, couverture, revues et contrôles d’intégrité. Les sources disponibles couvrent notamment apprentissage, compétences, lectures, objectifs, projets, travail, relations, famille, contributions, transmission, connaissances, décisions, réflexions, santé et temps enregistré.

La question :

> **« Qu’as-tu fait de ce qui t’a été donné ? »**

apparaît uniquement lorsqu’une revue est ouverte volontairement. La réponse devient une observation `DECLARED`. Elle peut ensuite être transformée explicitement en réflexion liée, sans notification permanente et sans jugement moral.

Le rapport **Boussole de vie** est visible dans **Système personnel → Gouvernance & vision** et **Rapports & analyses**. Il est exportable avec la période, les sources et les garde-fous.

> **La Boussole décrit un écart entre intentions et traces ; elle ne juge jamais une vie.**

## Moteur d’allocation budgétaire — version 20.0

**Finances & patrimoine** devient un moteur analytique d’allocation plutôt qu’une simple liste de dépenses.

```text
Ressources financières
        ↓
Budget global de la période
        ↓
BudgetAllocationStore
        ├── Apparence
        ├── Alimentation
        ├── Logement
        ├── Formation
        ├── Transport
        ├── Loisirs
        ├── Épargne
        └── domaines complémentaires
```

Deux stores spécialisés sont utilisés sans nouvelle primitive Core :

- `BudgetStore` : conteneur global d’une période mensuelle ;
- `BudgetAllocationStore` : montant décidé pour un domaine, statut et mode de projection.

Chaque allocation distingue :

- **dépensé réel** : transaction ou achat réellement enregistré dans son module source ;
- **engagé** : charge active ou acquisition explicitement confirmée ;
- **prévu** : projection qui ne constitue pas une dépense ;
- **disponible réel** : alloué moins réel ;
- **disponible après engagements** ;
- **disponible après prévision** ;
- **dépassement éventuel**, présenté comme un fait à examiner.

Les données sources ne sont jamais déplacées. Une dépense reste dans Finances, un achat de consommation dans son historique, une acquisition dans Apparence et une formation dans le capital humain. L’adapter déduplique les sources liées afin qu’une dépense ne soit comptée qu’une fois.

### Coût d’achat et rythme budgétaire

Pour les articles récurrents, VIE expose séparément :

```text
Brosse à dents
Coût d’achat              1 500 FCFA
Rythme                     90 jours
Équivalent mensuel           507 FCFA
```

L’utilisateur choisit par allocation :

- `DUE_PURCHASES` : appliquer les achats prévus à leur date réelle ;
- `MONTHLY_EQUIVALENT` : lisser leur équivalent mensuel.

Les deux valeurs restent visibles et ne sont jamais additionnées silencieusement. Une prévision récurrente ne crée ni transaction, ni achat, ni engagement.

### Vue analytique vivante

Le tableau financier affiche désormais :

- ressources en comptes et flux de la période ;
- budget global, montant alloué et montant non alloué ;
- réel, engagé, prévu et disponible pour chaque domaine ;
- sources détaillées et navigation vers leur module ;
- historique factuel sur six mois ;
- budget alloué, dépenses réelles, engagements, prévisions, disponible, dépassement, moyenne et tendance ;
- dépenses réelles sans allocation ;
- surallocation globale explicitement visible.

Les anciennes courbes statiques et montants de démonstration ont été supprimés. Les graphiques utilisent uniquement les données enregistrées.

Le contrat profondément figé `vie.budget-allocation.v1` expose le budget, les allocations, ressources, lignes réelles, engagements, prévisions, équivalents mensuels, historique, intégrité et intentions déclaratives. `VieViewAdapters` reste sans accès au stockage ou au réseau.

> **Prévu ≠ engagé ≠ dépensé. Coût d’achat ≠ équivalent mensuel.**

## Catalogue, panier et achats réalisés — version 21.0

L’onglet **Finances & patrimoine → Détails des achats** est désormais divisé en trois espaces fonctionnels :

```text
Catalogue
   ↓ sélection explicite
Panier modifiable
   ↓ validation humaine
Purchase réel
   ↓ agrégation analytique
BudgetAllocation
```

### Catalogue

Le catalogue réutilise exclusivement `ConsumptionStore` et ses fiches `Article`. Aucun nouveau type Core n’est introduit. Chaque carte présente :

- catégorie et sous-catégorie ;
- image générique ou photo personnelle locale ;
- unité et format ;
- prix indicatif ;
- fréquence d’achat ;
- équivalent annuel du nombre d’achats et du coût ;
- présence éventuelle dans le panier.

Les sous-catégories alimentaires comprennent notamment Céréales, Légumineuses, Huiles, Produits laitiers, Viandes, Poissons, Fruits, Légumes, Boissons, Épicerie, Surgelés et Autres. Elles restent filtrables et extensibles.

L’image n’est jamais obligatoire. Le formulaire **Image de l’article** permet de remplacer ou retirer uniquement la ressource visuelle, sans recréer l’article, modifier sa fréquence ou toucher à ses achats. Le fichier reste local et chiffré ; l’article conserve seulement sa référence.

### Panier entièrement modifiable

Chaque ligne du panier permet de modifier directement :

- l’article ;
- la quantité ;
- le format ;
- le prix unitaire ;
- la valeur et l’unité de fréquence ;
- le mois prévu ;
- l’image par un formulaire indépendant.

Un même article ne possède qu’une ligne de panier. Changer une ligne vers un article déjà présent fusionne les quantités au lieu de créer un doublon.

Le panier alimente le statut **prévu** de `BudgetAllocation`, mais il ne crée ni `Purchase`, ni transaction. Lorsqu’une occurrence récurrente existe pour le même article et la même période, la sélection explicite du panier la remplace dans la projection afin d’éviter un double comptage.

### Achats réalisés

La validation du panier crée un `Purchase` par article avec un `batchId` commun. La transaction financière reste facultative et, si elle est demandée, une seule transaction groupe le panier. L’analyse budgétaire répartit toutefois ses lignes dans les allocations correspondantes sans compter la transaction et les achats une seconde fois.

Les achats réels restent consultables séparément du panier. Les anciennes transactions financières multi-articles sont conservées dans un registre distinct pour préserver l’historique.

### Projection annuelle

Le contrat calcule un équivalent descriptif :

```text
Riz · 8 500 FCFA · tous les 30 jours
≈ 12,2 achats par an
≈ 103 417 FCFA par an
```

Cette projection est `DERIVED`. Elle exprime une fréquence d’achat, jamais une fréquence d’utilisation et ne crée aucune obligation d’acheter.

Le contrat `vie.purchase-workspace.v1` reste inchangé. Le nouveau contrat figé `vie.purchase-workspace.v2` expose le catalogue filtré, toutes les options d’article, le panier éditable, les achats réels, la projection annuelle et l’impact sur l’allocation budgétaire.

> **Catalogue ≠ panier. Panier ≠ achat. Fréquence d’achat ≠ fréquence d’utilisation.**

## Taxonomie complète des dépenses — version 22.0

VIE fournit désormais un `ExpenseCategoryStore` hiérarchique distinct du catalogue d’articles et des allocations budgétaires.

```text
ExpenseCategoryStore
        ↓ référence facultative
Transaction / prévision / charge récurrente
        ↓ résolution du domaine
BudgetAllocation
```

Le référentiel contient seize catégories principales :

1. Logement ;
2. Alimentation ;
3. Transport ;
4. Santé ;
5. Bien-être & Hygiène personnelle ;
6. Habillement ;
7. Technologie & Communication ;
8. Finances & Obligations légales ;
9. Loisirs & Divertissement ;
10. Éducation & Développement personnel ;
11. Famille ;
12. Animaux de compagnie ;
13. Professionnel / Travail ;
14. Social & Relationnel ;
15. Projets & Investissements personnels ;
16. Imprévus & Divers.

Toutes les dépenses détaillées du référentiel sont fournies comme sous-catégories. La famille possède un niveau supplémentaire pour Couple, Enfants, Parents / famille élargie et Vie familiale générale.

Ces catégories sont uniquement des possibilités de classement :

- elles ne créent aucune transaction ;
- elles ne créent aucun budget ;
- elles ne supposent pas que la dépense concerne l’utilisateur ;
- elles ne constituent aucune recommandation ;
- elles peuvent être complétées par des catégories personnalisées.

Les catégories intégrées restent stables afin de préserver les historiques. Une catégorie personnalisée inutilisée peut être supprimée ; si elle possède des enfants ou des données liées, elle est masquée sans casser ses relations.

Les nouvelles transactions, prévisions et charges récurrentes utilisent un `expenseCategoryId` stable tout en conservant le libellé historique. Les anciennes catégories textuelles sont migrées vers le meilleur rapprochement disponible sans modifier les montants.

Le contrat `vie.expense-taxonomy.v1` expose la hiérarchie, les chemins, les usages réels de la période, les catégories personnalisées, les opérations non classées et le contrôle d’intégrité.

> **Catégorie disponible ≠ dépense réelle ≠ obligation personnelle.**

## Calendrier d’achats et budget temporel — version 23.0

Le module **Détails des achats** ajoute une quatrième vue dédiée au temps :

```text
Catalogue → Panier → Purchase / FrequencyRule
                         ↓
                   Calendrier d’achats
                         ↓
                   BudgetAllocation
```

Chaque ligne du panier possède désormais une **date prévue exacte**. Lorsqu’un article est ajouté, VIE utilise sa prochaine date estimée si elle appartient au mois sélectionné ; sinon il propose le milieu de la période. Cette date reste entièrement modifiable.

Le calendrier distingue visuellement :

- dépense prévue depuis le panier ;
- achat réellement réalisé ;
- achat récurrent à venir depuis la `FrequencyRule` ;
- dépassement budgétaire factuellement calculé.

Une sélection explicite du panier remplace l’occurrence récurrente du même article pour la période afin d’éviter un double comptage. Après validation d’un achat réel, le dernier `Purchase` déplace l’ancrage de fréquence et la prochaine estimation repart de cette nouvelle date.

Le calendrier répond à **quand l’argent peut sortir**. L’allocation budgétaire répond à **combien peut encore être consacré**. Aucun événement prévu ou récurrent ne devient une dépense réelle.

La page affiche également une répartition issue des données par sous-catégorie alimentaire : Féculents, Protéines, Produits laitiers, Fruits & légumes, Huiles et autres catégories réellement utilisées.

Les fiches Article possèdent maintenant des champs distincts pour la marque et le conditionnement. Ces informations restent dans le catalogue ; l’image demeure une ressource locale de présentation.

Le contrat `vie.purchase-calendar.v1` expose 42 cellules calendaires, les événements avec provenance, les totaux réel / prévu / récurrent, les prochains achats, la répartition par sous-catégorie et l’état de l’allocation.

> **Calendrier = quand. Budget = combien. Prévision ≠ achat réel.**

## Intentions d’acquisition visuelles — version 18.4

Cette évolution permet de représenter **ce que l’utilisateur veut réellement trouver** avant tout achat. Elle enrichit les modules existants au lieu de créer un nouveau domaine :

```text
Article souhaité
   ↓ choix de la nature
Bien durable / vêtement  →  Plan d’acquisition mensuel
Consommable              →  Intelligence de consommation
```

### Modèle recherché et critères

Une fiche visuelle peut désormais préciser :

- le nom de l’article ;
- son type ou modèle recherché ;
- sa couleur ou finition ;
- sa taille ou ses dimensions ;
- sa matière ;
- une liste de critères personnels ;
- sa priorité ;
- le mois prévu ;
- la quantité et le budget maximal.

Exemples :

- **Canapé** → canapé d’angle, tissu gris, dimensions maximales, mois prévu ;
- **Pardessus** → coupe longue, couleur beige, taille et matière souhaitées ;
- **Parfum ou dentifrice** → modèle ou variante habituelle avec fréquence de renouvellement.

### Références visuelles locales

Chaque fiche dispose toujours d’une illustration SVG locale issue du sprite inline de VIE. Les références intégrées couvrent notamment : canapé, pardessus, vêtement, chaussures, maison, technologie et consommable.

L’utilisateur peut aussi joindre depuis son appareil :

- une photo JPG ou PNG ;
- une image WebP ou GIF ;
- un dessin SVG.

Les fichiers restent dans les pièces jointes universelles chiffrées. Un SVG personnel n’est jamais exécuté ni conservé comme contenu actif : VIE retire les éléments dangereux, le convertit localement en PNG, puis stocke cette image rasterisée. Remplacer une référence visuelle n’efface pas silencieusement l’ancienne.

### Plan mensuel visuel

Les propositions du mois sont affichées sous forme de cartes recomposées sur mobile avec :

- l’image personnelle ou l’illustration VIE ;
- le modèle et les caractéristiques recherchés ;
- la priorité et l’état du plan ;
- le budget maximal ;
- les actions Planifier, Reporter, Confirmer au budget et Achat réalisé.

Le routeur **Article souhaité** oriente les biens durables vers Acquisitions et les consommables vers Consumption Store. Le contrat figé `vie.acquisition-visual-plan.v1` prépare la migration React sans donner à React un accès au stockage.

> **Une image décrit une intention. Elle ne prouve jamais qu’un achat a été réalisé et ne crée aucune dépense.**

## Intelligence de consommation prévisible — version 18.3

Cette évolution enrichit **Apparence & entretien** sans créer un nouveau module principal et sans ajouter de type générique au Core. La brique spécialisée repose sur :

```text
Consumption Store
├── Article
│   └── FrequencyRule
├── Purchase
└── Forecast — calculé à la lecture, jamais enregistré comme achat
```

### Article, achat, règle et prévision restent distincts

Chaque article peut conserver :

- son domaine : Apparence & entretien, Santé, Maison, Alimentation, Transport, Technologie ou Autre ;
- une sous-catégorie et une unité habituelle ;
- un prix indicatif, une quantité et un temps d’achat habituels ;
- une règle personnelle exprimée en jours, semaines, mois ou années ;
- son état actif ou archivé.

Chaque achat réel conserve séparément :

- sa date ;
- son coût total et sa quantité ;
- sa provenance : saisie, ticket, commande ou abonnement ;
- son fournisseur et le temps mobilisé ;
- son éventuel justificatif dans les pièces jointes universelles chiffrées ;
- sa transaction financière uniquement si l’utilisateur la crée ou la synchronise explicitement.

### Fréquence personnelle et apprentissage explicable

La fréquence initiale est affichée comme **Règle personnelle** et non comme une vérité physique. Après au moins trois achats, si l’apprentissage est activé, VIE utilise l’intervalle médian observé et affiche :

- **Historique observé** ;
- le nombre d’achats et d’intervalles disponibles ;
- un rythme descriptif : stable, variable ou irrégulier ;
- la raison exacte du calcul.

VIE n’invente aucun pourcentage de confiance ni aucune probabilité. La prochaine date, le coût indicatif et les occurrences dans l’horizon choisi sont recalculés automatiquement depuis les données sources.

### Interface et circulation contrôlée

L’onglet **Consommation prévisible** apporte :

- les renouvellements estimés à 7–365 jours ;
- les totaux indicatifs sur 60 jours par défaut ;
- l’historique groupé par mois et filtrable par domaine ;
- les coûts et le temps observés sur une période ;
- la création, modification, archivage, suppression et restauration des articles ;
- la création, modification, suppression et restauration des achats ;
- un accès depuis les prévisions financières, le Mode Aujourd’hui et l’inventaire personnel ;
- un contrat figé `vie.consumption-overview.v1` dans `VieViewAdapters`.

Un bouton **Achat réalisé** enregistre un événement réel. Une case séparée permet ensuite, si l’utilisateur le souhaite, de créer la dépense correspondante. **Une prévision ne crée jamais d’achat, de rappel, de mouvement financier ou d’obligation.** Aucun suivi de chaque utilisation n’est demandé.

> **Prévoir aide à préparer les ressources ; prévoir ne signifie ni devoir acheter ni avoir effectivement consommé.**

## Équipement, préparation et acquisitions — version 13

Cette évolution relie les biens durables, la garde-robe, les consommables, l’entretien et les finances sans transformer le renouvellement en obligation de consommation.

### Apparence & entretien → Acquisitions

- stocks actuels et stocks souhaités définis uniquement par l’utilisateur ;
- distinction entre quantité possédée et quantité réellement opérationnelle ;
- minimum acceptable, manque et progression par catégorie ;
- propositions mensuelles d’acquisition avec priorité, quantité et budget maximal ;
- états Proposition, Planifié, Confirmé au budget, Reporté et Acheté ;
- proposition de remplacement pour un objet déclaré Usé ou À remplacer ;
- décisions Ajouter au prochain mois, Plus tard ou Ignorer ;
- aucun achat ni mouvement financier créé à partir du seul état d’un objet ;
- progression annuelle d’acquisition distincte du stock actuel ;
- historique des acquisitions, coûts réels et répartition des couleurs ;
- comparaison factuelle des acquisitions personnelles avec l’effort déclaré pour les objectifs primordiaux.

### Circulation confirmée des données

```text
Proposition
   ↓ décision humaine
Acquisition planifiée
   ↓ confirmation budgétaire
Dépense prévisionnelle
   ↓ achat réellement confirmé
Dépense réelle + inventaire + historique + preuve
```

Une proposition ne crée aucune dépense. Une confirmation au budget crée seulement une prévision. Le formulaire **Achat réalisé** crée ensuite, en une seule opération traçable :

- la transaction financière ;
- l’objet ou la quantité dans l’inventaire ;
- l’historique d’acquisition ;
- la relation entre facture et objet ;
- une preuve pour l’objectif lié, sans modifier arbitrairement sa progression.

### Équipement & préparation

Le Système personnel distingue désormais :

- vêtements, chaussures et accessoires ;
- téléphone, ordinateur et matériel professionnel ;
- outils, mobilier et électroménager ;
- équipement de maison et de voyage ;
- état, quantité, utilité, contextes, garantie et durée de vie ;
- date de renouvellement ;
- rotation et dernière utilisation ;
- photo et localisation ;
- coût réel de possession : achat, réparations, entretien et accessoires.

### Consommables

Les anciennes fiches de stock restent importables pour préserver la compatibilité, puis sont migrées progressivement vers l’Intelligence de consommation. Le suivi courant repose désormais sur :

- l’article ;
- les achats réels ;
- la fréquence personnelle ;
- l’historique par période ;
- la prochaine date estimée ;
- le coût indicatif.

VIE ne demande plus d’enregistrer chaque utilisation d’une brosse, d’un savon, d’un parfum ou d’une cartouche. La dépense réelle n’est créée qu’après confirmation explicite de l’achat.

### Présentation et désencombrement

Les contextes Professionnel, Quotidien, Sport, Événement, Voyage et Cérémonie disposent de leurs propres conditions minimales. VIE montre ce qui manque sans imposer un style ou une quantité.

Les objets jamais ou rarement utilisés peuvent être marqués Conserver, Donner, Vendre ou Recycler. Ils ne sont jamais supprimés automatiquement et une décision peut être révisée depuis l’inventaire.

### Minimum viable personnel

Le Centre de Cohérence affiche maintenant la préparation minimale pour :

- Finances ;
- Équipement ;
- Documents ;
- Carrière ;
- Organisation ;
- Entretien.

Chaque indicateur précise s’il vient des données observées ou d’une évaluation personnelle. Il mesure une préparation, jamais une probabilité de réussite ni la valeur de la personne.

> **Posséder ≠ être préparé.**

## Serveur local SQLite — version 12

Le mode serveur local renforce la continuité sans transformer VIE en service cloud :

```text
Navigateur
   ↓
https://localhost:8080/vie/
   ↓
VIE Server sur le PC
   ↓
SQLite — C:\VIE\data\vie.db
   ↓
Pièces jointes et sauvegardes locales
```

### Propriétés essentielles

- exécutable Windows autonome `server/vie-server.exe` ;
- pilote SQLite intégré, sans DLL externe ;
- service Windows natif avec démarrage automatique ;
- gestionnaire dans la zone de notification ;
- écoute limitée à `127.0.0.1` ou `localhost` ;
- application disponible sous `/vie/` ;
- détection automatique du serveur par le navigateur ;
- conservation du mode autonome lorsque le serveur est absent ;
- synchronisation automatique de l’état déjà chiffré ;
- copie chiffrée des documents, médias, versions et instantanés historiques ;
- récupération paresseuse d’un fichier depuis SQLite sur un nouvel ordinateur ;
- contrôle de révision et conflit sans écrasement silencieux ;
- choix humain de la version à conserver après sauvegarde ;
- sauvegarde SQLite cohérente avec pièces jointes et empreinte SHA-256 ;
- sauvegarde quotidienne locale configurable ;
- restauration Windows avec copie de sécurité préalable ;
- aucune exposition directe de `vie.db`, `data`, `backups` ou `config.json` par HTTP.

Le navigateur chiffre l’état et les fichiers avant leur transmission à la boucle locale. Le serveur ne reçoit donc ni le mot de passe principal ni les données métier en clair. SQLite contient des enveloppes chiffrées, un registre de fichiers, les sauvegardes, les révisions et un journal serveur.

L’espace **Espace VIE → Serveur local** affiche :

- l’adresse et l’état du serveur ;
- le chemin de la base et des sauvegardes ;
- le nombre de pièces jointes recopiées ;
- les sauvegardes serveur disponibles ;
- les commandes de synchronisation, sauvegarde et diagnostic ;
- les conflits éventuels avec deux choix explicitement confirmés.

La documentation complète est disponible dans `server/README-SERVEUR.md` et les sources reproductibles dans `server/source`.

## Données et production

Cette version reste entièrement fonctionnelle côté navigateur. Les données sont enregistrées dans le stockage chiffré du navigateur et peuvent aussi être synchronisées avec un dossier VIE choisi par l’utilisateur ou avec VIE Server et sa base SQLite locale. Le Coach VIE fonctionne à partir de règles explicables. Aucune donnée métier n’est envoyée sur Internet ; le mode serveur communique uniquement avec la boucle locale après chiffrement côté navigateur.

Pour une synchronisation automatique entre appareils par Internet ou une utilisation multi-utilisateur en production, il restera possible de connecter l’application à :

- une authentification sécurisée ;
- une API ;
- une base de données distante ;
- un service de notifications système ;
- un stockage de fichiers chiffré ;
- éventuellement un assistant IA avec consentement explicite.

## Calendrier financier central — version 24.0

La vue **Finances & patrimoine → Calendrier financier** est la projection temporelle centrale du budget. Chaque journée peut contenir plusieurs sorties détaillées provenant du panier, des dépenses prévisionnelles, des engagements, des charges récurrentes et des achats prévisibles.

Une entrée expose sa date, sa catégorie hiérarchique, sa quantité, son prix unitaire, son total, sa fréquence, sa prochaine date indicative, son allocation et sa provenance. La journée calcule son impact total et sa ventilation par allocation.

Lorsqu’une prévision est réalisée, VIE conserve un instantané du plan initial dans `financialPlanHistory`, puis le relie au `Purchase` ou à la transaction réelle. Une modification du montant ou de la date réels ne modifie jamais silencieusement cet instantané. Le contrat figé `vie.financial-calendar.v1` expose ainsi :

```text
prévision → réalisation → écart descriptif → impact sur budget
```

Garde-fous :

- prévu ≠ réalisé ;
- une occurrence récurrente ≠ un achat ;
- un plan réalisé est remplacé par son réel dans l’impact budgétaire, jamais additionné une seconde fois ;
- l’écart ne constitue ni une note ni un jugement ;
- toute réalisation exige une confirmation explicite.

## Analyse de choix — version 25.0

**Choice Analysis / Analyse de choix v0.1** est intégré dans **Système personnel → Analyse de choix & décisions**. Son rôle est de rendre visibles les conséquences possibles de plusieurs options afin d’aider l’utilisateur à choisir consciemment.

Ce n’est ni un moteur de scénario, ni un moteur de prédiction. Chaque conséquence porte obligatoirement l’un des statuts suivants :

- `FACT` : donnée connue avec une source VIE enregistrée ;
- `ESTIMATED` : estimation explicite ;
- `ASSUMED` : hypothèse qui ne doit jamais être présentée comme un fait ;
- `UNKNOWN` : conséquence inconnue laissée visible.

Le contrat figé `vie.choice-analysis.v1` relie en lecture seule les ressources, les allocations financières, le temps, les compétences, les formations et les objectifs. Il expose les chaînes explicatives, par exemple :

```text
Coût envisagé
→ Budget Formation
→ Budget mensuel
→ Reste disponible avant le choix
→ Reste après simulation
→ Marge pour les autres dépenses
```

L’exploration et la comparaison ne créent aucune `Decision`, ne modifient aucun budget, temps, objectif, niveau de compétence ou plan. Seul le bouton explicite **« Je choisis… »** crée une `Decision` contenant un instantané traçable de l’analyse. La création des actions demande ensuite une seconde confirmation distincte.

```text
Explorer → Comparer → Choisir → Decision réelle → Plan / Actions
```

## Mise à jour GitHub contrôlée — version 26.0

L’installation Windows peut vérifier automatiquement les versions stables publiées dans :

```text
https://github.com/Cyrakovsky/ma-vie
```

La vérification est effectuée par le gestionnaire Windows au démarrage puis périodiquement, avec un intervalle réseau minimal de 24 heures. Elle peut être désactivée depuis l’icône VIE de la zone de notification. Aucune donnée métier n’est envoyée : seules des requêtes `GET` standard sont faites vers l’API publique GitHub.

Lorsqu’une version plus récente existe, VIE demande explicitement : **« Installer maintenant ? »**. Un refus ne modifie rien.

Après confirmation, l’updater :

1. relit la Release officielle `Cyrakovsky/ma-vie` ;
2. vérifie le tag, le manifeste, la version minimale de l’updater et l’hôte GitHub ;
3. télécharge `ma-vie.zip` ;
4. vérifie sa taille, son SHA-256 et le digest GitHub lorsqu’il est disponible ;
5. refuse les chemins ZIP dangereux et les archives anormalement grandes ;
6. exige une sauvegarde SQLite cohérente ;
7. crée un point de retour local protégé ;
8. installe uniquement après élévation UAC ;
9. contrôle la version et la santé du serveur ;
10. restaure automatiquement l’application, le serveur et la base SQLite pré-mise à jour si l’installation échoue.

Les dossiers `C:\VIE\data`, `C:\VIE\backups` et les pièces jointes ne sont jamais supprimés par l’updater. Les préférences de vérification automatique sont conservées entre les versions.

Outils visibles :

```text
COMMENCER-ICI.cmd → [7] Vérifier les mises à jour GitHub
C:\VIE\server\METTRE-A-JOUR-VIE.bat
Icône VIE → Vérifier les mises à jour GitHub…
```

Le dépôt contient également `.github/workflows/release.yml`, qui teste l’application et crée automatiquement les trois assets nécessaires à chaque tag `vX.Y.Z` :

```text
ma-vie.zip
ma-vie-update.json
ma-vie.zip.sha256
```

Le SHA-256 protège l’intégrité du paquet. Tant que l’exécutable n’est pas signé commercialement, Windows peut encore afficher SmartScreen lors de la première installation.

### Correctif Windows PowerShell — version 26.0.1

Les scripts `.ps1` sont livrés en **UTF-8 avec BOM** afin que Windows PowerShell 5.1 reconnaisse correctement les caractères français. Cela corrige les erreurs de parseur contenant `â€”`, `Ã ` ou « parenthèse fermante manquante » lors de l’option `[7]`.

Le menu et le lanceur de mise à jour privilégient désormais le correctif présent dans le nouveau paquet avant une ancienne copie déjà installée dans `C:\VIE\server`.

### Correctif des chemins Windows avec parenthèses — version 26.0.2

`INSTALLER-VIE.bat` n’utilise plus de variable de chemin développée dans un bloc Batch parenthésé. L’installation fonctionne désormais depuis des dossiers tels que `Téléchargements\ma-vie (15)`. La console reste ouverte en cas d’échec et affiche le code ainsi que le journal disponible.
