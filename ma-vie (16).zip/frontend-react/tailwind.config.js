/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,jsx}"],
  prefix: "tw-",
  corePlugins: { preflight: false },
  theme: {
    extend: {
      colors: {
        vie: {
          50: "#effbf6",
          100: "#dff5ec",
          300: "#76f1c8",
          500: "#0ca678",
          600: "#087f5b",
          800: "#174033"
        }
      },
      boxShadow: {
        "vie-soft": "0 16px 38px rgba(20,49,38,.09)"
      }
    }
  },
  plugins: []
};
