import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

export default defineConfig({
  base: "./",
  plugins: [react()],
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
    "process.env": "{}"
  },
  build: {
    outDir: resolve(import.meta.dirname, "../assets/react"),
    emptyOutDir: true,
    sourcemap: false,
    cssCodeSplit: false,
    minify: "esbuild",
    lib: {
      entry: resolve(import.meta.dirname, "src/bridge.jsx"),
      name: "VieReactBridge",
      formats: ["iife"],
      fileName: () => "vie-react-bridge.js"
    },
    rollupOptions: {
      output: {
        assetFileNames: asset => asset.name?.endsWith(".css") ? "vie-react.css" : "[name][extname]"
      }
    }
  }
});
