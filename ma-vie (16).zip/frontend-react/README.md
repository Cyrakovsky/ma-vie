# VIE React UI — migration progressive

Ce dossier contient le nouveau frontend React de VIE. Il est construit en **bibliothèque IIFE locale** afin de pouvoir cohabiter avec l’interface JavaScript existante pendant la migration route par route.

## Pile

- React et React DOM ;
- Tailwind CSS avec préfixe `tw-` et sans preflight global ;
- Framer Motion, utilisé dans sa variante DOM mini ;
- Vite pour la compilation locale.

## Construction

```bash
cd frontend-react
npm ci
npm run build
```

La construction produit uniquement :

```text
../assets/react/vie-react-bridge.js
../assets/react/vie-react.css
../assets/react/vie-view-adapters.js
```

Ces fichiers sont déjà fournis dans le paquet utilisateur. `node_modules` n’est jamais livré.

## Contraintes permanentes

- aucun CDN ;
- aucune requête Internet à l’exécution ;
- base Vite relative compatible avec `file://` ;
- CSS Tailwind préfixé pour ne pas modifier les modules existants ;
- données transmises par le pont VIE, jamais dupliquées dans React ;
- chiffrement effectué avant le serveur, comme dans l’architecture actuelle ;
- démontage explicite des racines React avant remplacement d’un îlot.

## Première migration

La version 26.0.2 conserve le bandeau React du **Mode Aujourd’hui**, la **Sphère de compétences** et les progressions produites par `ProgressEngine`. Les contrats profondément figés `vie.consumption-overview.v2`, `vie.purchase-workspace.v1`, `vie.purchase-workspace.v2`, `vie.purchase-calendar.v1`, `vie.financial-calendar.v1`, `vie.choice-analysis.v1`, `vie.acquisition-visual-plan.v1`, `vie.recurrence-plan.v1`, `vie.recurrence-plan.v2`, `vie.reflective-memory.v1`, `vie.life-compass.v1`, `vie.budget-allocation.v1` et `vie.expense-taxonomy.v1` présentent catalogue, panier, catégories, achats, occurrences, engagements REQUIRED/OPTIONAL, mémoire réflexive traçable, Boussole de vie versionnée, moteur d’allocation budgétaire, catalogue/panier/achats séparés, taxonomie complète des dépenses, calendrier d’achats, calendrier financier central, analyse de choix traçable et budgets sans donner à React un accès aux stores, aux images chiffrées, au stockage ou aux finances. `VieRecurrenceEngine` reste un moteur JavaScript pur placé sous les View Adapters. Si le bundle React est indisponible, les vues HTML JavaScript restent affichées comme solution de repli.
