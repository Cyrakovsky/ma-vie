import React, { useEffect, useMemo, useRef, useState } from "react";
import { VieBadge, VieButton, VieGlassPanel, VieIllustration, useVieEntrance, useVieIntent } from "./design-system";

const greetingFor = hour => hour < 5 ? "Bonsoir" : hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir";

export function TodayHero({ view }) {
  const [now, setNow] = useState(() => new Date());
  const introRef = useRef(null);
  const cycleRef = useRef(null);
  const dispatch = useVieIntent();
  useVieEntrance(introRef);
  useVieEntrance(cycleRef, { delay: 0.06 });

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const dateLabel = useMemo(() => now.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  }), [now.toDateString()]);

  const firstName = view?.identity?.firstName || "Utilisateur";
  const cycle = view?.cycle;

  return (
    <>
      <div ref={introRef} className="tw-min-w-0">
        <VieBadge tone="glass" className="today-mode-label">MODE AUJOURD’HUI</VieBadge>
        <h1><span>{greetingFor(now.getHours())}</span>, {firstName}</h1>
        <p className="today-live-line">
          <span>{dateLabel}</span>
          <time className="vie-react-clock" dateTime={now.toISOString()}>
            {now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </time>
        </p>
      </div>

      <VieGlassPanel ref={cycleRef} className="tw-min-w-0">
        <small>Cycle mis en avant</small>
        <strong className="tw-truncate">{cycle?.name || "Aucun cycle"}</strong>
        <div className="vie-react-cycle-actions">
          <VieButton variant="soft" size="small" onClick={() => dispatch(view.intents.adaptCycle)}>Adapter</VieButton>
          <VieButton variant="soft" size="small" onClick={() => dispatch(view.intents.openStrategy)}>Pilotage stratégique</VieButton>
        </div>
      </VieGlassPanel>
      <VieIllustration name="dashboard" className="dashboard-hero-illustration" />
    </>
  );
}
