import React from "react";
import { createRoot } from "react-dom/client";
import { TodayHero } from "./TodayHero";
import { SkillSphere } from "./SkillSphere";
import { VieShell } from "./design-system";
import "./styles.css";

const roots = new Map();

class IslandBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error) {
    console.error("Îlot React VIE indisponible", error);
  }

  render() {
    if (this.state.failed) return <span className="tw-text-sm tw-text-white">Interface temporairement indisponible</span>;
    return this.props.children;
  }
}

export function mountTodayHero(node, { view, dispatch = () => {} }) {
  if (!node) return false;
  let root = roots.get(node);
  if (!root) {
    root = createRoot(node);
    roots.set(node, root);
  }
  node.dataset.reactMounted = "true";
  root.render(
    <IslandBoundary>
      <VieShell dispatch={dispatch}>
        <TodayHero view={view} />
      </VieShell>
    </IslandBoundary>
  );
  return true;
}

export function mountSkillSphere(node, { view, dispatch = () => {} }) {
  if (!node) return false;
  let root = roots.get(node);
  if (!root) {
    root = createRoot(node);
    roots.set(node, root);
  }
  node.dataset.reactMounted = "true";
  root.render(
    <IslandBoundary>
      <VieShell dispatch={dispatch}>
        <SkillSphere view={view} />
      </VieShell>
    </IslandBoundary>
  );
  return true;
}

export function unmountWithin(scope) {
  if (!scope) return;
  for (const [node, root] of roots) {
    if (node === scope || scope.contains(node)) {
      root.unmount();
      delete node.dataset.reactMounted;
      roots.delete(node);
    }
  }
}

export function getMountedCount() {
  return roots.size;
}

const api = { mountTodayHero, mountSkillSphere, unmountWithin, getMountedCount };
window.VieReactBridge = api;
