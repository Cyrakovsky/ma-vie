import React, { useEffect, useMemo, useRef, useState } from "react";
import { VieBadge, VieButton, VieCard, VieEmptyState, VieIllustration, VieProgress, VieTimeline, useVieEntrance, useVieIntent } from "./design-system";

const levelLabel = level => ({ beginner:"Débutant", intermediate:"Intermédiaire", advanced:"Avancé", expert:"Expert" }[level] || "Débutant");

export function SkillSphere({ view }) {
  const dispatch = useVieIntent();
  const [category, setCategory] = useState("all");
  const filtered = useMemo(() => category === "all" ? view.skills : view.skills.filter(skill => skill.category === category), [view.skills, category]);
  const [selectedId, setSelectedId] = useState(() => filtered[0]?.id || "");
  const rootRef = useRef(null);
  useVieEntrance(rootRef);

  useEffect(() => {
    if (!filtered.some(skill => skill.id === selectedId)) setSelectedId(filtered[0]?.id || "");
  }, [filtered, selectedId]);

  const selected = view.skills.find(skill => skill.id === selectedId) || filtered[0] || null;
  const categories = [...new Set(view.skills.map(skill => skill.category))];
  const visible = filtered.slice(0, 14);
  const positions = new Map(visible.map((skill, index) => {
    const angle = -Math.PI / 2 + index * Math.PI * 2 / Math.max(1, visible.length);
    return [skill.id, { x: 50 + Math.cos(angle) * 38, y: 50 + Math.sin(angle) * 36 }];
  }));

  const sourceTimeline = (selected?.sources || []).map((source, index) => ({ id:source.id || `${source.type}-${index}`, title:source.label, detail:`${source.type}${source.date ? ` · ${source.date}` : ""}` }));

  return (
    <section ref={rootRef} className="vie-skill-sphere tw-grid tw-gap-4">
      <header className="tw-flex tw-flex-wrap tw-items-start tw-justify-between tw-gap-3">
        <div className="tw-flex tw-items-center tw-gap-3">
          <VieIllustration name="carriere" className="tw-h-16 tw-w-20 tw-text-vie-600" />
          <div><span className="page-kicker">CAPITAL HUMAIN</span><div className="tw-flex tw-flex-wrap tw-items-center tw-gap-2"><h2 className="tw-m-0 tw-text-xl tw-text-slate-900">Sphère de compétences</h2><VieBadge tone="green">Calcul automatique</VieBadge></div><p className="tw-mb-0 tw-mt-1 tw-text-xs tw-text-slate-500">Chaque capacité reste reliée à ses formations, preuves et objectifs.</p></div>
        </div>
        <div className="tw-flex tw-flex-wrap tw-gap-2"><VieButton variant="soft" size="small" onClick={() => dispatch(view.intents.openTraining)}>Formations</VieButton><VieButton variant="primary" size="small" onClick={() => dispatch(view.intents.addSkill)}>Ajouter une compétence</VieButton></div>
      </header>

      <div className="tw-grid tw-grid-cols-2 tw-gap-2 md:tw-grid-cols-4">
        <VieCard><small className="tw-text-slate-500">Compétences</small><strong className="tw-mt-1 tw-block tw-text-2xl">{view.skills.length}</strong></VieCard>
        <VieCard><small className="tw-text-slate-500">Preuves</small><strong className="tw-mt-1 tw-block tw-text-2xl">{view.skills.reduce((sum, skill) => sum + skill.evidence.length, 0)}</strong></VieCard>
        <VieCard><small className="tw-text-slate-500">À valider</small><strong className="tw-mt-1 tw-block tw-text-2xl">{view.pendingEvents.length}</strong></VieCard>
        <VieCard><small className="tw-text-slate-500">Baselines</small><strong className="tw-mt-1 tw-block tw-text-2xl">{view.baselineCount}</strong></VieCard>
      </div>

      {view.skills.length ? <>
        <nav className="tw-flex tw-gap-2 tw-overflow-x-auto tw-pb-1" aria-label="Filtrer les compétences"><button className={`status-button ${category === "all" ? "active" : ""}`} onClick={() => setCategory("all")}>Toutes</button>{categories.map(item => <button key={item} className={`status-button ${category === item ? "active" : ""}`} onClick={() => setCategory(item)}>{item}</button>)}</nav>
        <div className="skill-sphere-layout">
          <VieCard className="skill-sphere-canvas tw-relative tw-min-h-[520px] tw-overflow-hidden tw-bg-gradient-to-br tw-from-white tw-to-vie-50/60">
            <svg className="skill-sphere-links" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
              {visible.map(skill => { const point=positions.get(skill.id);return <line key={`center-${skill.id}`} x1="50" y1="50" x2={point.x} y2={point.y} />; })}
              {view.links.map((link,index) => { const from=positions.get(link.from),to=positions.get(link.to);return from&&to?<line className="source-link" key={`${link.from}-${link.to}-${index}`} x1={from.x} y1={from.y} x2={to.x} y2={to.y}/>:null; })}
            </svg>
            <div className="skill-sphere-person"><span>{view.person.name.split(/\s+/).map(part => part[0]).slice(0,2).join("").toUpperCase()}</span><strong>{view.person.name}</strong></div>
            {visible.map(skill => { const point=positions.get(skill.id);return <button key={skill.id} className={`skill-sphere-node ${skill.id === selected?.id ? "active" : ""}`} style={{ left:`${point.x}%`, top:`${point.y}%` }} onClick={() => setSelectedId(skill.id)} aria-pressed={skill.id === selected?.id}><span>{skill.score}%</span><strong>{skill.name}</strong><small>{levelLabel(skill.level)}</small></button>; })}
          </VieCard>

          <VieCard className="skill-sphere-detail">
            {selected ? <><header className="tw-flex tw-items-start tw-justify-between tw-gap-3"><div><VieBadge tone={selected.score >= 60 ? "green" : "neutral"}>{levelLabel(selected.level)}</VieBadge><h3 className="tw-mb-1 tw-mt-3 tw-text-xl">{selected.name}</h3><p className="tw-m-0 tw-text-xs tw-text-slate-500">{selected.category} · acquis {selected.acquiredAt || "date non renseignée"}</p></div><VieButton size="small" onClick={() => dispatch({ type:"edit-skill", id:selected.id })}>Modifier</VieButton></header><VieProgress className="tw-mt-5" value={selected.score} label="Progression documentée"/><p className="tw-mb-0 tw-mt-2 tw-text-[11px] tw-leading-relaxed tw-text-slate-500">{selected.progressDetail}</p><VieProgress className="tw-mt-3" value={selected.targetScore} label={`Niveau cible · ${levelLabel(selected.targetLevel)}`}/><section className="tw-mt-5"><h4 className="tw-mb-2 tw-text-sm">Sources</h4>{sourceTimeline.length?<VieTimeline items={sourceTimeline}/>:<p className="tw-text-xs tw-text-slate-500">Aucune source documentée.</p>}</section><section className="tw-mt-4"><h4 className="tw-mb-2 tw-text-sm">Preuves</h4><div className="tw-flex tw-flex-wrap tw-gap-1.5">{selected.evidence.length?selected.evidence.map(item=><VieBadge key={item.id||item.label} tone="green">✓ {item.label}</VieBadge>):<span className="tw-text-xs tw-text-slate-500">Aucune preuve liée.</span>}</div></section><section className="tw-mt-4"><h4 className="tw-mb-2 tw-text-sm">Objectifs associés</h4>{selected.requiredBy.length?selected.requiredBy.map(goal=><div key={goal.goalId} className="tw-mb-2 tw-rounded-xl tw-bg-slate-50 tw-p-2.5"><div className="tw-flex tw-justify-between tw-text-xs"><strong>{goal.goalName}</strong><span>écart {goal.gap}%</span></div><VieProgress className="tw-mt-2" value={goal.currentScore} label={`Requis ${goal.requiredScore}%`}/></div>):<p className="tw-text-xs tw-text-slate-500">Aucun objectif ne requiert encore cette compétence.</p>}</section></> : <VieEmptyState title="Aucune compétence sélectionnée" description="Choisissez une compétence dans la sphère."/>}
          </VieCard>
        </div>
      </> : <VieEmptyState icon={<span>+</span>} title="Votre sphère est vide" description="Ajoutez une compétence manuellement ou terminez une formation pour générer une proposition documentée." actionLabel="Ajouter une compétence" onAction={() => dispatch(view.intents.addSkill)} />}

      {view.pendingEvents.length > 0 && <VieCard><header className="tw-flex tw-items-center tw-justify-between"><div><h3 className="tw-m-0 tw-text-base">Évolutions proposées</h3><p className="tw-mb-0 tw-mt-1 tw-text-xs tw-text-slate-500">Aucune proposition n’est appliquée automatiquement.</p></div><VieBadge tone="warning">{view.pendingEvents.length}</VieBadge></header><div className="tw-mt-3 tw-grid tw-gap-2">{view.pendingEvents.map(event=><article key={event.id} className="tw-grid tw-grid-cols-[1fr_auto] tw-items-center tw-gap-3 tw-rounded-xl tw-border tw-border-slate-200 tw-p-3"><div><strong className="tw-block tw-text-sm">{event.skillName}</strong><small className="tw-text-slate-500">{event.trainingTitle} · {event.beforeScore}% → {event.proposedScore}% · {event.evidenceCount} preuve(s)</small></div><div className="tw-flex tw-gap-1"><VieButton variant="primary" size="small" onClick={() => dispatch({ type:"accept-skill-update", id:event.id })}>Valider</VieButton><VieButton size="small" onClick={() => dispatch({ type:"dismiss-skill-update", id:event.id })}>Ignorer</VieButton></div></article>)}</div></VieCard>}
    </section>
  );
}
