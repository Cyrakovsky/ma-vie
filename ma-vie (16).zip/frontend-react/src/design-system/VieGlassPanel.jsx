import React, { forwardRef } from "react";
import { cn } from "./cn";

export const VieGlassPanel = forwardRef(function VieGlassPanel({ className = "", children, ...props }, ref) {
  return (
    <div
      ref={ref}
      className={cn("tw-rounded-xl tw-border tw-border-white/15 tw-bg-white/10 tw-p-2.5 tw-shadow-sm tw-backdrop-blur-md", className)}
      {...props}
    >
      {children}
    </div>
  );
});
