import React from "react";
import { cn } from "./cn";

export function VieProgress({ value = 0, label = "Progression", className = "" }) {
  const normalized = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <div className={cn("tw-grid tw-gap-1.5", className)}>
      <div className="tw-flex tw-items-center tw-justify-between tw-text-xs tw-text-slate-600">
        <span>{label}</span><strong>{Math.round(normalized)}%</strong>
      </div>
      <div className="tw-h-1.5 tw-overflow-hidden tw-rounded-full tw-bg-slate-100" role="progressbar" aria-label={label} aria-valuemin="0" aria-valuemax="100" aria-valuenow={normalized}>
        <span className="tw-block tw-h-full tw-rounded-full tw-bg-vie-600 tw-transition-[width] tw-duration-300" style={{ width: `${normalized}%` }} />
      </div>
    </div>
  );
}
