import React from "react";
import { cn } from "./cn";

export function VieIllustration({ name = "dashboard", className = "", decorative = true, label = "" }) {
  return (
    <span className={cn("vie-illustration tw-inline-grid tw-place-items-center", className)} aria-hidden={decorative || undefined} aria-label={decorative ? undefined : label || name}>
      <svg viewBox="0 0 120 88" focusable="false" role={decorative ? undefined : "img"}>
        <use href={`#vie-illus-${name}`} />
      </svg>
    </span>
  );
}
