import React, { createContext, useContext } from "react";

const VieIntentContext = createContext(() => {});

export function VieShell({ dispatch = () => {}, children }) {
  return <VieIntentContext.Provider value={dispatch}>{children}</VieIntentContext.Provider>;
}

export function useVieIntent() {
  return useContext(VieIntentContext);
}
