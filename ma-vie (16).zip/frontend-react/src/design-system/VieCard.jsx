import React from "react";
import { cn } from "./cn";

export function VieCard({ as: Component = "article", interactive = false, className = "", children, ...props }) {
  return (
    <Component
      className={cn(
        "tw-rounded-2xl tw-border tw-border-slate-200/80 tw-bg-white tw-p-4 tw-shadow-vie-soft",
        interactive && "tw-transition tw-duration-200 hover:-tw-translate-y-0.5 hover:tw-border-vie-300",
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}
