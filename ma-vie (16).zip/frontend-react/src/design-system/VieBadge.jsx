import React from "react";
import { cn } from "./cn";

const tones = {
  neutral: "tw-bg-slate-50 tw-text-slate-600 tw-border-slate-200",
  glass: "tw-bg-white/10 tw-text-white/80 tw-border-white/15",
  green: "tw-bg-vie-100 tw-text-vie-600 tw-border-vie-300/40",
  warning: "tw-bg-amber-50 tw-text-amber-700 tw-border-amber-200",
  danger: "tw-bg-red-50 tw-text-red-700 tw-border-red-200"
};

export function VieBadge({ tone = "neutral", children, className = "" }) {
  return <span className={cn("tw-inline-flex tw-items-center tw-rounded-full tw-border tw-px-2 tw-py-1 tw-text-[10px] tw-font-semibold", tones[tone] || tones.neutral, className)}>{children}</span>;
}
