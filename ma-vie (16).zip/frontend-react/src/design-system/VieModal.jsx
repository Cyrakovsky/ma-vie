import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { VieButton } from "./VieButton";

export function VieModal({ open, title, description = "", children, onClose, footer = null }) {
  const dialogRef = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const previous = document.activeElement;
    dialogRef.current?.focus();
    const onKey = event => { if (event.key === "Escape") onClose?.(); };
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); previous?.focus?.(); };
  }, [open, onClose]);
  if (!open) return null;
  return createPortal(
    <div className="tw-fixed tw-inset-0 tw-z-[400] tw-grid tw-place-items-center tw-bg-slate-950/35 tw-p-4 tw-backdrop-blur-sm" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose?.(); }}>
      <section ref={dialogRef} tabIndex="-1" role="dialog" aria-modal="true" aria-label={title} className="tw-w-full tw-max-w-xl tw-rounded-2xl tw-border tw-border-white/50 tw-bg-white tw-p-5 tw-shadow-2xl tw-outline-none">
        <header className="tw-flex tw-items-start tw-justify-between tw-gap-4"><div><h2 className="tw-m-0 tw-text-xl tw-text-slate-900">{title}</h2>{description && <p className="tw-mb-0 tw-mt-1 tw-text-sm tw-text-slate-500">{description}</p>}</div><VieButton size="small" onClick={onClose} aria-label="Fermer">Fermer</VieButton></header>
        <div className="tw-mt-4">{children}</div>
        {footer && <footer className="tw-mt-5 tw-flex tw-justify-end tw-gap-2">{footer}</footer>}
      </section>
    </div>,
    document.body
  );
}
