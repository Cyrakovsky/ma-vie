import { useEffect } from "react";
import { animate } from "framer-motion/dom/mini";

export function useVieEntrance(ref, { delay = 0, y = 6 } = {}) {
  useEffect(() => {
    if (!ref.current || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return undefined;
    ref.current.dataset.vieMotion = "framer-dom-mini";
    const controls = animate(ref.current, { opacity: [0, 1], transform: [`translateY(${y}px)`, "translateY(0)"] }, { duration: 0.28, delay, ease: "ease-out" });
    return () => controls.cancel();
  }, [ref, delay, y]);
}
