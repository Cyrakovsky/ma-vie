import React from "react";
import { cn } from "./cn";

const variants = {
  primary: "button primary",
  soft: "button soft",
  neutral: "button",
  danger: "button danger"
};

export function VieButton({ variant = "neutral", size = "normal", className = "", children, ...props }) {
  return (
    <button
      type="button"
      className={cn(variants[variant] || variants.neutral, size === "small" && "small", "tw-transition-transform tw-duration-150 active:tw-scale-[.98]", className)}
      {...props}
    >
      {children}
    </button>
  );
}
