import React, { useRef } from "react";
import { useVieEntrance } from "./useVieEntrance";

export function VieTimeline({ items = [] }) {
  const ref = useRef(null);
  useVieEntrance(ref);
  return (
    <ol ref={ref} className="tw-grid tw-gap-0">
      {items.map((item, index) => (
        <li key={item.id || index} className="tw-relative tw-grid tw-grid-cols-[28px_1fr] tw-gap-3 tw-pb-4 last:tw-pb-0">
          {index < items.length - 1 && <i className="tw-absolute tw-left-[13px] tw-top-7 tw-h-[calc(100%-18px)] tw-w-px tw-bg-slate-200" />}
          <span className="tw-relative tw-z-10 tw-grid tw-h-7 tw-w-7 tw-place-items-center tw-rounded-full tw-border tw-border-vie-300 tw-bg-vie-100 tw-text-[10px] tw-font-bold tw-text-vie-600">{index + 1}</span>
          <div><strong className="tw-block tw-text-sm tw-text-slate-800">{item.title}</strong>{item.detail && <p className="tw-m-0 tw-mt-1 tw-text-xs tw-text-slate-500">{item.detail}</p>}</div>
        </li>
      ))}
    </ol>
  );
}
