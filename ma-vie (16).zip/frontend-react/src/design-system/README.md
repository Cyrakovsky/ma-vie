# Design System VIE

Le Design System VIE est volontairement petit. Il formalise l’identité existante sans devenir un framework parallèle.

## Briques

- `VieShell` : contexte d’intentions entre présentation et moteur VIE ;
- `VieCard` : surface principale lisible ;
- `VieGlassPanel` : verre réservé aux zones de pilotage à faible densité ;
- `VieButton` : variantes primaire, douce, neutre et destructive ;
- `VieBadge` : états courts ;
- `VieProgress` : progression déclarée, jamais probabilité inventée ;
- `VieTimeline` : enchaînement temporel ;
- `VieEmptyState` : absence de données avec prochaine action explicite ;
- `VieModal` : dialogue local accessible ;
- `VieIllustration` : illustration SVG locale issue du sprite VIE ;
- `useVieEntrance` : animation Motion courte et respectueuse de `prefers-reduced-motion`.

## Règles

1. React ne lit jamais directement LocalStorage, IndexedDB ou SQLite.
2. Un composant reçoit un contrat produit par `VieViewAdapters`.
3. Une action React émet une intention ; le Core décide comment la traiter.
4. Le glassmorphisme est interdit dans les tableaux, formulaires et pages à forte densité.
5. Les animations expliquent un changement d’état ; elles ne décorent pas chaque élément.
6. Toute brique doit rester utilisable sans animation et sur téléphone.
