import React from "react";
import { VieButton } from "./VieButton";

export function VieEmptyState({ icon = null, title, description, actionLabel = "", onAction = null }) {
  return (
    <div className="tw-grid tw-min-h-40 tw-place-items-center tw-content-center tw-gap-2 tw-rounded-2xl tw-border tw-border-dashed tw-border-slate-200 tw-bg-gradient-to-b tw-from-white tw-to-vie-50/40 tw-p-5 tw-text-center">
      {icon && <span className="tw-grid tw-h-10 tw-w-10 tw-place-items-center tw-rounded-full tw-bg-vie-100 tw-text-vie-600">{icon}</span>}
      <strong className="tw-text-sm tw-text-slate-800">{title}</strong>
      {description && <span className="tw-max-w-md tw-text-xs tw-leading-relaxed tw-text-slate-500">{description}</span>}
      {actionLabel && onAction && <VieButton variant="soft" size="small" onClick={onAction}>{actionLabel}</VieButton>}
    </div>
  );
}
