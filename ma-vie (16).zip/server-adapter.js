(() => {
  "use strict";

  const API_ROOT = `${location.origin}/api/v1`;
  const ACTIVE_PROFILE_KEY = "ma-vie-active-profile-v1";
  const PROFILE_REGISTRY_KEY = "ma-vie-profile-registry-v1";
  const ENCRYPTED_STATE_KEY = "ma-vie-secure-state-v1";
  const SECURITY_CONFIG_KEY = "ma-vie-security-config-v1";
  const isLoopback = ["localhost", "127.0.0.1", "::1", "[::1]"].includes(location.hostname);
  const isServerMode = isLoopback && location.protocol.startsWith("http") && location.pathname.startsWith("/vie/");
  const revisions = new Map();
  let statePushQueue = Promise.resolve();

  const status = {
    available: false,
    mode: isServerMode ? "détection" : "autonome",
    syncStatus: isServerMode ? "détection" : "local uniquement",
    revision: 0,
    lastSyncAt: "",
    lastError: "",
    serverVersion: "",
    appURL: "",
    database: "",
    databasePath: "",
    backupPath: "",
    backupCount: 0,
    fileCount: 0,
    lastBackup: "",
    localOnly: true,
    transport: isServerMode && location.protocol === "https:" ? "HTTPS/TLS" : "",
    tlsEnabled: isServerMode && location.protocol === "https:",
    tlsVersion: "",
    certificateFingerprint: "",
    certificateCAFingerprint: "",
    certificateExpiresAt: "",
    csrfProtected: false,
    secureSessionCookie: false
  };

  const scopedKey = (base, profileId) => profileId === "profile-main" ? base : `${base}:${profileId}`;
  const parse = value => { try { return JSON.parse(value || "null"); } catch (_) { return null; } };
  const readCookie = name => document.cookie.split(";").map(value=>value.trim()).find(value=>value.startsWith(`${name}=`))?.slice(name.length+1) || "";
  const csrfToken = () => decodeURIComponent(readCookie("__Host-vie_csrf_token") || readCookie("vie_csrf_token"));
  const dateNumber = value => { const time = new Date(value || 0).getTime(); return Number.isFinite(time) ? time : 0; };
  const profileId = () => localStorage.getItem(ACTIVE_PROFILE_KEY) || "profile-main";
  const dispatch = () => window.dispatchEvent(new CustomEvent("vie-server-status", {detail:{...status}}));
  const update = values => { Object.assign(status, values); dispatch(); return status; };

  async function request(path, options = {}, timeout = 8000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const headers = new Headers(options.headers || {});
      headers.set("X-VIE-Local", "1");
      const csrf = csrfToken();
      if (csrf) headers.set("X-VIE-CSRF", csrf);
      const response = await fetch(`${API_ROOT}${path}`, {
        ...options,
        headers,
        credentials: "same-origin",
        cache: "no-store",
        signal: controller.signal
      });
      const type = response.headers.get("content-type") || "";
      const payload = type.includes("application/json") ? await response.json() : await response.blob();
      if (!response.ok) {
        const error = new Error(payload?.error || payload?.message || `Erreur HTTP ${response.status}`);
        error.status = response.status;
        error.payload = payload;
        throw error;
      }
      return payload;
    } finally { clearTimeout(timer); }
  }

  async function health() {
    if (!isServerMode) return update({available:false, mode:"autonome", syncStatus:"local uniquement"});
    try {
      const data = await request("/health", {}, 1800);
      return update({
        available: true,
        mode: data.tlsEnabled ? "serveur local HTTPS" : "serveur local",
        serverVersion: data.serverVersion || "",
        appURL: data.appURL || "",
        database: data.database || "vie.db",
        databasePath: data.databasePath || "",
        backupPath: data.backupPath || "",
        backupCount: Number(data.backupCount || 0),
        fileCount: Number(data.fileCount || 0),
        lastBackup: data.lastBackup || "",
        localOnly: data.localOnly !== false,
        transport: data.transport || (location.protocol === "https:" ? "HTTPS/TLS" : "HTTP local"),
        tlsEnabled: data.tlsEnabled === true,
        tlsVersion: data.tlsVersion || "",
        certificateFingerprint: data.certificateFingerprint || "",
        certificateCAFingerprint: data.certificateCAFingerprint || "",
        certificateExpiresAt: data.certificateExpiresAt || "",
        csrfProtected: data.csrfProtected === true,
        secureSessionCookie: data.secureSessionCookie === true,
        lastError: ""
      });
    } catch (error) {
      return update({available:false, mode:"serveur indisponible", syncStatus:"copie navigateur", lastError:error.message || "Serveur local inaccessible"});
    }
  }

  async function bootstrap() {
    if (!isServerMode) return status;
    await health();
    if (!status.available) return status;
    const id = profileId();
    try {
      const remote = await request(`/bootstrap?profile=${encodeURIComponent(id)}`, {}, 6000);
      revisions.set(id, Number(remote.revision || 0));
      status.revision = Number(remote.revision || 0);
      if (!remote.found) return update({syncStatus:"serveur prêt · première sauvegarde attendue"});

      const localEnvelope = parse(localStorage.getItem(scopedKey(ENCRYPTED_STATE_KEY, id)));
      const remoteEnvelope = remote.envelope || null;
      const localTime = dateNumber(localEnvelope?.updatedAt);
      const remoteTime = dateNumber(remote.updatedAt || remoteEnvelope?.updatedAt);
      if (!localEnvelope || remoteTime > localTime) {
        localStorage.setItem(scopedKey(ENCRYPTED_STATE_KEY, id), JSON.stringify(remoteEnvelope));
        if (remote.securityConfig) localStorage.setItem(scopedKey(SECURITY_CONFIG_KEY, id), JSON.stringify(remote.securityConfig));
        if (Array.isArray(remote.profileRegistry) && remote.profileRegistry.length) localStorage.setItem(PROFILE_REGISTRY_KEY, JSON.stringify(remote.profileRegistry));
        update({syncStatus:"version SQLite chargée", lastSyncAt:new Date().toISOString()});
      } else if (localTime > remoteTime) update({syncStatus:"copie navigateur plus récente"});
      else update({syncStatus:"à jour", lastSyncAt:new Date().toISOString()});
      return status;
    } catch (error) {
      return update({syncStatus:"à vérifier", lastError:error.message || "Initialisation SQLite impossible"});
    }
  }

  async function adoptRemote(id = profileId()) {
    if (!status.available) return {ok:false,skipped:true};
    const remote = await request(`/bootstrap?profile=${encodeURIComponent(id)}`, {}, 10000);
    if (!remote.found) return {ok:false,found:false};
    localStorage.setItem(scopedKey(ENCRYPTED_STATE_KEY, id), JSON.stringify(remote.envelope));
    if (remote.securityConfig) localStorage.setItem(scopedKey(SECURITY_CONFIG_KEY, id), JSON.stringify(remote.securityConfig));
    if (Array.isArray(remote.profileRegistry) && remote.profileRegistry.length) localStorage.setItem(PROFILE_REGISTRY_KEY, JSON.stringify(remote.profileRegistry));
    revisions.set(id, Number(remote.revision || 0));
    update({syncStatus:"version SQLite chargée",revision:Number(remote.revision||0),lastSyncAt:new Date().toISOString(),lastError:""});
    return {ok:true,remote};
  }

  async function pushEnvelopeNow(id, envelope, securityConfig, profileRegistry, activeProfileId, metadata = {}) {
    if (!status.available || id === "profile-guest") return {ok:false, skipped:true};
    try {
      const result = await request(`/state/${encodeURIComponent(id)}`, {
        method:"PUT",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          envelope,
          securityConfig,
          profileRegistry,
          activeProfileId,
          appVersion:metadata.appVersion || "",
          deviceId:metadata.deviceId || "",
          updatedAt:envelope?.updatedAt || metadata.updatedAt || new Date().toISOString(),
          expectedRevision:revisions.get(id) || 0,
          force:metadata.force === true
        })
      }, 20000);
      revisions.set(id, Number(result.revision || 0));
      update({syncStatus:"à jour", revision:Number(result.revision || 0), lastSyncAt:new Date().toISOString(), lastError:""});
      return result;
    } catch (error) {
      if (error.status === 409) update({syncStatus:"conflit · décision requise", lastError:error.payload?.message || error.message});
      else update({syncStatus:"erreur de synchronisation", lastError:error.message || "Écriture SQLite impossible"});
      return {ok:false, conflict:error.status===409, error:error.message, details:error.payload || null};
    }
  }

  function pushEnvelope(...args) {
    const task = () => pushEnvelopeNow(...args);
    statePushQueue = statePushQueue.then(task,task);
    return statePushQueue;
  }

  async function pushFile(id, kind, fileId, secureRecord, logicalSize = 0) {
    if (!status.available || id === "profile-guest") return {ok:false, skipped:true};
    try {
      const result = await request(`/files/${encodeURIComponent(id)}/${encodeURIComponent(kind)}/${encodeURIComponent(fileId)}`, {
        method:"PUT",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({record:secureRecord, logicalSize, updatedAt:new Date().toISOString()})
      }, 120000);
      update({fileCount:status.fileCount + 1, lastError:""});
      return result;
    } catch (error) {
      update({lastError:error.message || "Copie de fichier impossible"});
      return {ok:false,error:error.message};
    }
  }

  async function pullFile(id, kind, fileId) {
    if (!status.available || id === "profile-guest") return null;
    try {
      const result = await request(`/files/${encodeURIComponent(id)}/${encodeURIComponent(kind)}/${encodeURIComponent(fileId)}`, {}, 120000);
      return result.found ? result.record : null;
    } catch (error) { update({lastError:error.message || "Lecture de fichier impossible"}); return null; }
  }

  async function deleteProfile(id) {
    if (!status.available || ["profile-main","profile-guest"].includes(id)) return {ok:false,skipped:true};
    try { return await request(`/state/${encodeURIComponent(id)}?confirm=true`, {method:"DELETE"}, 120000); }
    catch (error) { update({lastError:error.message||"Suppression du profil SQLite impossible"}); return {ok:false,error:error.message}; }
  }

  async function deleteFile(id, kind, fileId) {
    if (!status.available || id === "profile-guest") return {ok:false,skipped:true};
    try { return await request(`/files/${encodeURIComponent(id)}/${encodeURIComponent(kind)}/${encodeURIComponent(fileId)}?confirm=true`, {method:"DELETE"}, 20000); }
    catch (error) { update({lastError:error.message || "Suppression logique impossible"}); return {ok:false,error:error.message}; }
  }

  async function createBackup(id, reason = "manuelle") {
    const result = await request("/backups", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({profileId:id,reason})}, 120000);
    update({backupCount:status.backupCount+1,lastBackup:result.backup?.createdAt||new Date().toISOString(),lastError:""});
    return result.backup;
  }

  async function listBackups(id = profileId()) {
    const result = await request(`/backups?profile=${encodeURIComponent(id)}`, {}, 20000);
    return result.backups || [];
  }

  async function downloadBackup(backupId) {
    const blob = await request(`/backups/${encodeURIComponent(backupId)}`, {}, 120000);
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `VIE_BACKUP_${new Date().toISOString().slice(0,10)}.vie-local`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }

  async function verify() { return request("/verify", {method:"POST"}, 120000); }

  window.VieLocalServer = {
    status,
    isServerMode,
    bootstrap,
    health,
    pushEnvelope,
    adoptRemote,
    pushFile,
    pullFile,
    deleteFile,
    deleteProfile,
    createBackup,
    listBackups,
    downloadBackup,
    verify,
    open(){ if(status.appURL) window.open(status.appURL,"_blank","noopener"); },
    currentRevision(id = profileId()){ return revisions.get(id) || 0; }
  };
})();
