# Première publication de Ma Vie sur GitHub

Dépôt configuré :

```text
https://github.com/Cyrakovsky/ma-vie
```

Le dépôt est actuellement vide. L’updater répondra donc « aucune version publiée » jusqu’à la création du premier tag.

## Publier les sources

Dans PowerShell, placez-vous dans le dossier extrait de Ma Vie, puis exécutez :

```powershell
git init
git branch -M main
git add .
git commit -m "Ma Vie 26.0.2"
git remote add origin https://github.com/Cyrakovsky/ma-vie.git
git push -u origin main
```

GitHub peut demander de vous connecter. Aucun jeton ne doit être écrit dans les fichiers de Ma Vie.

## Créer la première version téléchargeable

```powershell
git tag v26.0.2
git push origin v26.0.2
```

Le workflow `.github/workflows/release.yml` exécute les tests puis publie automatiquement :

```text
ma-vie.zip
ma-vie-update.json
ma-vie.zip.sha256
```

Suivez son exécution dans l’onglet **Actions** du dépôt. La version apparaît ensuite dans **Releases**.

## Publier une version suivante

1. modifier l’application ;
2. mettre à jour `APP_VERSION` et `server/VERSION.txt` avec la même version ;
3. pousser les changements ;
4. créer et pousser un nouveau tag `vX.Y.Z`.

Une installation Windows existante vérifiera GitHub quotidiennement. Elle affichera une confirmation avant tout téléchargement et toute installation.
