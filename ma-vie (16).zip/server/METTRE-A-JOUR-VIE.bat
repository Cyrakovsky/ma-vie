@echo off
setlocal
chcp 65001 >nul
title Ma Vie - verifier les mises a jour GitHub

set "CHECKER=%~dp0verifier-mise-a-jour.ps1"
if not exist "%CHECKER%" set "CHECKER=C:\VIE\server\verifier-mise-a-jour.ps1"

if not exist "%CHECKER%" (
  echo ERREUR : le verificateur de mise a jour est introuvable.
  echo Reinstallez Ma Vie depuis un paquet complet.
  echo.
  pause
  exit /b 1
)

echo ============================================================
echo   MA VIE - MISE A JOUR DEPUIS GITHUB
echo ============================================================
echo.
echo Depot : https://github.com/Cyrakovsky/ma-vie
echo La verification ne modifie aucune donnee.
echo Une confirmation sera demandee avant toute installation.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CHECKER%" -InstallRoot "C:\VIE" -Force -Interactive
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo Verification terminee.
if "%RC%"=="10" echo Mise a jour disponible mais reportee.
if not "%RC%"=="0" if not "%RC%"=="10" echo La verification a rencontre une erreur ^(code %RC%^).
echo Journal : C:\VIE\logs\mise-a-jour.log
echo.
pause
exit /b %RC%
