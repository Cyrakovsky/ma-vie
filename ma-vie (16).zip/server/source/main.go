package main

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"mime"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"

	_ "modernc.org/sqlite"
)

const (
	serverVersion             = "1.1.0"
	serviceName               = "VIEServer"
	serviceTitle              = "VIE — Serveur personnel local"
	maxLogicalFileBytes int64 = 80 << 20
)

type Config struct {
	Listen        string `json:"listen"`
	BasePath      string `json:"basePath"`
	AppDir        string `json:"appDir"`
	DataDir       string `json:"dataDir"`
	BackupDir     string `json:"backupDir"`
	LogDir        string `json:"logDir"`
	OpenBrowser   bool   `json:"openBrowser"`
	AutoBackup    bool   `json:"autoBackup"`
	BackupTime    string `json:"backupTime"`
	RetentionDays int    `json:"retentionDays"`
	MaxBackups    int    `json:"maxBackups"`
	MaxRequestMB  int64  `json:"maxRequestMB"`
	AdminToken    string `json:"adminToken"`
	TLSEnabled    bool   `json:"tlsEnabled"`
	TLSCertFile   string `json:"tlsCertFile"`
	TLSKeyFile    string `json:"tlsKeyFile"`
	TLSCAFile     string `json:"tlsCAFile"`
	ConfigPath    string `json:"-"`
}

type Server struct {
	cfg          Config
	db           *sql.DB
	logger       *log.Logger
	httpServer   *http.Server
	tlsConfig    *tls.Config
	tlsInfo      TLSInfo
	sessionToken string
	csrfToken    string
	startedAt    time.Time
	backupMu     sync.Mutex
}

type StateRequest struct {
	Envelope         json.RawMessage `json:"envelope"`
	SecurityConfig   json.RawMessage `json:"securityConfig"`
	ProfileRegistry  json.RawMessage `json:"profileRegistry"`
	ActiveProfileID  string          `json:"activeProfileId"`
	AppVersion       string          `json:"appVersion"`
	DeviceID         string          `json:"deviceId"`
	UpdatedAt        string          `json:"updatedAt"`
	ExpectedRevision int64           `json:"expectedRevision"`
	Force            bool            `json:"force"`
}

type FileRequest struct {
	Record      json.RawMessage `json:"record"`
	LogicalSize int64           `json:"logicalSize"`
	UpdatedAt   string          `json:"updatedAt"`
}

type BackupInfo struct {
	ID        string `json:"id"`
	ProfileID string `json:"profileId"`
	Filename  string `json:"filename"`
	Checksum  string `json:"checksum"`
	Size      int64  `json:"size"`
	CreatedAt string `json:"createdAt"`
	Reason    string `json:"reason"`
	Path      string `json:"-"`
}

type VerifyResult struct {
	OK            bool   `json:"ok"`
	Database      string `json:"database"`
	StatesChecked int    `json:"statesChecked"`
	StatesValid   int    `json:"statesValid"`
	FilesChecked  int    `json:"filesChecked"`
	FilesValid    int    `json:"filesValid"`
	MissingFiles  int    `json:"missingFiles"`
	CheckedAt     string `json:"checkedAt"`
}

var safePart = regexp.MustCompile(`^[A-Za-z0-9._-]{1,180}$`)

func main() {
	command, cfgPath, err := parseCommand(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "Erreur :", err)
		os.Exit(2)
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Configuration impossible :", err)
		os.Exit(2)
	}
	switch command {
	case "install-service":
		if err := platformInstallService(cfg.ConfigPath); err != nil {
			fmt.Fprintln(os.Stderr, "Installation du service impossible :", err)
			os.Exit(1)
		}
		fmt.Println("Service VIE installé et configuré en démarrage automatique.")
	case "uninstall-service":
		if err := platformUninstallService(); err != nil {
			fmt.Fprintln(os.Stderr, "Désinstallation du service impossible :", err)
			os.Exit(1)
		}
		fmt.Println("Service VIE désinstallé.")
	case "init-tls", "renew-tls":
		info, err := ensureTLSMaterial(cfg, command == "renew-tls")
		if err != nil {
			fmt.Fprintln(os.Stderr, "Initialisation HTTPS impossible :", err)
			os.Exit(1)
		}
		if !info.Enabled {
			fmt.Println("HTTPS est désactivé dans config.json.")
			break
		}
		fmt.Println("Certificat HTTPS local prêt.")
		fmt.Println("Empreinte CA SHA-256 :", info.CAFingerprint)
		fmt.Println("Expiration serveur   :", info.ExpiresAt)
	case "service":
		if err := platformRunService(cfg); err != nil {
			fmt.Fprintln(os.Stderr, "Service VIE arrêté avec erreur :", err)
			os.Exit(1)
		}
	case "serve", "":
		if err := runInteractive(cfg); err != nil {
			fmt.Fprintln(os.Stderr, "Serveur VIE arrêté avec erreur :", err)
			os.Exit(1)
		}
	default:
		fmt.Fprintln(os.Stderr, "Commande inconnue. Utilisez serve, init-tls, renew-tls, install-service ou uninstall-service.")
		os.Exit(2)
	}
}

func parseCommand(args []string) (string, string, error) {
	command := "serve"
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		command = args[0]
		args = args[1:]
	}
	set := flag.NewFlagSet("vie-server", flag.ContinueOnError)
	cfg := set.String("config", "", "chemin du fichier config.json")
	if err := set.Parse(args); err != nil {
		return "", "", err
	}
	return command, *cfg, nil
}

func defaultConfig() (Config, error) {
	exe, err := os.Executable()
	if err != nil {
		return Config{}, err
	}
	exeDir := filepath.Dir(exe)
	root := filepath.Dir(exeDir)
	appDir := filepath.Join(root, "app")
	if _, err := os.Stat(filepath.Join(appDir, "index.html")); err != nil {
		if _, portableErr := os.Stat(filepath.Join(root, "index.html")); portableErr == nil {
			appDir = root
		}
	}
	return Config{
		Listen:        "127.0.0.1:8080",
		BasePath:      "/vie/",
		AppDir:        appDir,
		DataDir:       filepath.Join(root, "data"),
		BackupDir:     filepath.Join(root, "backups"),
		LogDir:        filepath.Join(root, "logs"),
		OpenBrowser:   true,
		AutoBackup:    true,
		BackupTime:    "06:30",
		RetentionDays: 180,
		MaxBackups:    30,
		MaxRequestMB:  128,
		TLSEnabled:    true,
		TLSCertFile:   filepath.Join(exeDir, "tls", "server-cert.pem"),
		TLSKeyFile:    filepath.Join(exeDir, "tls", "server-key.pem"),
		TLSCAFile:     filepath.Join(exeDir, "tls", "vie-local-ca.cer"),
		ConfigPath:    filepath.Join(exeDir, "config.json"),
	}, nil
}

func loadConfig(requested string) (Config, error) {
	cfg, err := defaultConfig()
	if err != nil {
		return Config{}, err
	}
	if requested != "" {
		abs, err := filepath.Abs(requested)
		if err != nil {
			return Config{}, err
		}
		cfg.ConfigPath = abs
	}
	if raw, err := os.ReadFile(cfg.ConfigPath); err == nil {
		raw = bytes.TrimPrefix(raw, []byte{0xEF, 0xBB, 0xBF})
		var disk Config
		var fields map[string]json.RawMessage
		if err := json.Unmarshal(raw, &disk); err != nil {
			return Config{}, fmt.Errorf("JSON invalide dans %s: %w", cfg.ConfigPath, err)
		}
		_ = json.Unmarshal(raw, &fields)
		base := filepath.Dir(cfg.ConfigPath)
		if disk.Listen != "" {
			cfg.Listen = disk.Listen
		}
		if disk.BasePath != "" {
			cfg.BasePath = disk.BasePath
		}
		if disk.AppDir != "" {
			cfg.AppDir = resolvePath(base, disk.AppDir)
		}
		if disk.DataDir != "" {
			cfg.DataDir = resolvePath(base, disk.DataDir)
		}
		if disk.BackupDir != "" {
			cfg.BackupDir = resolvePath(base, disk.BackupDir)
		}
		if disk.LogDir != "" {
			cfg.LogDir = resolvePath(base, disk.LogDir)
		}
		cfg.OpenBrowser = disk.OpenBrowser
		cfg.AutoBackup = disk.AutoBackup
		if disk.BackupTime != "" {
			cfg.BackupTime = disk.BackupTime
		}
		if disk.RetentionDays > 0 {
			cfg.RetentionDays = disk.RetentionDays
		}
		if disk.MaxBackups > 0 {
			cfg.MaxBackups = disk.MaxBackups
		}
		if disk.MaxRequestMB > 0 {
			cfg.MaxRequestMB = disk.MaxRequestMB
		}
		cfg.AdminToken = disk.AdminToken
		if _, present := fields["tlsEnabled"]; present {
			cfg.TLSEnabled = disk.TLSEnabled
		}
		if disk.TLSCertFile != "" {
			cfg.TLSCertFile = resolvePath(base, disk.TLSCertFile)
		}
		if disk.TLSKeyFile != "" {
			cfg.TLSKeyFile = resolvePath(base, disk.TLSKeyFile)
		}
		if disk.TLSCAFile != "" {
			cfg.TLSCAFile = resolvePath(base, disk.TLSCAFile)
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return Config{}, err
	}
	cfg.BasePath = "/" + strings.Trim(strings.TrimSpace(cfg.BasePath), "/") + "/"
	if cfg.BasePath == "//" {
		cfg.BasePath = "/vie/"
	}
	if cfg.AdminToken == "" {
		cfg.AdminToken = randomToken(32)
	}
	if err := validateConfig(cfg); err != nil {
		return Config{}, err
	}
	for _, dir := range []string{cfg.DataDir, cfg.BackupDir, cfg.LogDir, filepath.Join(cfg.DataDir, "attachments"), filepath.Join(cfg.DataDir, ".trash")} {
		if err := os.MkdirAll(dir, 0700); err != nil {
			return Config{}, err
		}
	}
	if _, err := os.Stat(cfg.ConfigPath); errors.Is(err, os.ErrNotExist) {
		if err := saveConfig(cfg); err != nil {
			return Config{}, err
		}
	}
	return cfg, nil
}

func resolvePath(base, value string) string {
	if filepath.IsAbs(value) {
		return filepath.Clean(value)
	}
	return filepath.Clean(filepath.Join(base, value))
}

func validateConfig(cfg Config) error {
	host, _, err := net.SplitHostPort(cfg.Listen)
	if err != nil {
		return fmt.Errorf("adresse d’écoute invalide: %w", err)
	}
	ip := net.ParseIP(host)
	if host != "localhost" && (ip == nil || !ip.IsLoopback()) {
		return errors.New("par sécurité, VIE Server doit écouter uniquement sur 127.0.0.1 ou localhost")
	}
	if _, err := os.Stat(filepath.Join(cfg.AppDir, "index.html")); err != nil {
		return fmt.Errorf("index.html introuvable dans %s", cfg.AppDir)
	}
	if cfg.TLSEnabled && (strings.TrimSpace(cfg.TLSCertFile) == "" || strings.TrimSpace(cfg.TLSKeyFile) == "" || strings.TrimSpace(cfg.TLSCAFile) == "") {
		return errors.New("HTTPS activé mais chemins de certificat, clé ou autorité locale manquants")
	}
	return nil
}

func saveConfig(cfg Config) error {
	disk := cfg
	disk.ConfigPath = ""
	raw, err := json.MarshalIndent(disk, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(cfg.ConfigPath), 0700); err != nil {
		return err
	}
	return atomicWrite(cfg.ConfigPath, raw, 0600)
}

func runInteractive(cfg Config) error {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	url := publicURL(cfg)
	fmt.Println("VIE Server")
	fmt.Println("--------------------")
	fmt.Println("Adresse  :", url)
	fmt.Println("Base     :", filepath.Join(cfg.DataDir, "vie.db"))
	fmt.Println("Données  :", cfg.DataDir)
	fmt.Println("Sauvegardes :", cfg.BackupDir)
	fmt.Println("Serveur démarré. Ctrl+C pour arrêter.")
	if cfg.OpenBrowser && os.Getenv("VIE_NO_AUTO_BROWSER") != "1" {
		go func() { time.Sleep(650 * time.Millisecond); _ = openBrowser(url) }()
	}
	return runServer(ctx, cfg)
}

func runServer(ctx context.Context, cfg Config) error {
	s, err := newServer(cfg)
	if err != nil {
		return err
	}
	defer s.close()
	errCh := make(chan error, 1)
	go func() { errCh <- serveConfiguredHTTP(s.httpServer, cfg, s.tlsConfig) }()
	go s.backupScheduler(ctx)
	select {
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		defer cancel()
		return s.httpServer.Shutdown(shutdownCtx)
	case err := <-errCh:
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	}
}

func newServer(cfg Config) (*Server, error) {
	tlsConfig, tlsInfo, err := loadServerTLS(cfg)
	if err != nil {
		return nil, err
	}
	logPath := filepath.Join(cfg.LogDir, "vie-server.log")
	file, err := os.OpenFile(logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return nil, err
	}
	logger := log.New(io.MultiWriter(file), "", log.Ldate|log.Ltime|log.LUTC)
	dbPath := filepath.Join(cfg.DataDir, "vie.db")
	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		file.Close()
		return nil, err
	}
	db.SetMaxOpenConns(1)
	for _, pragma := range []string{"PRAGMA journal_mode=WAL", "PRAGMA synchronous=FULL", "PRAGMA foreign_keys=ON", "PRAGMA busy_timeout=5000", "PRAGMA wal_autocheckpoint=1000"} {
		if _, err := db.Exec(pragma); err != nil {
			db.Close()
			file.Close()
			return nil, err
		}
	}
	if err := migrate(db); err != nil {
		db.Close()
		file.Close()
		return nil, err
	}
	cleanupServerTrash(cfg.DataDir, 30)
	s := &Server{cfg: cfg, db: db, logger: logger, tlsConfig: tlsConfig, tlsInfo: tlsInfo, sessionToken: randomToken(32), csrfToken: randomToken(32), startedAt: time.Now()}
	mux := http.NewServeMux()
	mux.HandleFunc("/", s.handle)
	s.httpServer = &http.Server{
		Addr: cfg.Listen, Handler: s.securityHeaders(mux),
		ReadHeaderTimeout: 8 * time.Second, ReadTimeout: 130 * time.Second,
		WriteTimeout: 130 * time.Second, IdleTimeout: 60 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}
	s.audit("server_start", "", "Serveur VIE démarré", "success")
	return s, nil
}

func (s *Server) close() {
	if s.db != nil {
		_, _ = s.db.Exec("PRAGMA wal_checkpoint(TRUNCATE)")
		_ = s.db.Close()
	}
}

func migrate(db *sql.DB) error {
	statements := []string{
		`CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)`,
		`CREATE TABLE IF NOT EXISTS server_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)`,
		`CREATE TABLE IF NOT EXISTS profiles (profile_id TEXT PRIMARY KEY, security_config TEXT NOT NULL DEFAULT '{}', profile_registry TEXT NOT NULL DEFAULT '[]', active_profile_id TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL)`,
		`CREATE TABLE IF NOT EXISTS state_envelopes (profile_id TEXT PRIMARY KEY REFERENCES profiles(profile_id) ON DELETE CASCADE, envelope TEXT NOT NULL, checksum TEXT NOT NULL, app_version TEXT NOT NULL DEFAULT '', device_id TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1)`,
		`CREATE TABLE IF NOT EXISTS files (id TEXT NOT NULL, profile_id TEXT NOT NULL, kind TEXT NOT NULL, logical_size INTEGER NOT NULL DEFAULT 0, stored_size INTEGER NOT NULL DEFAULT 0, checksum TEXT NOT NULL, relative_path TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT NOT NULL DEFAULT '', PRIMARY KEY(profile_id,kind,id))`,
		`CREATE TABLE IF NOT EXISTS backups (id TEXT PRIMARY KEY, profile_id TEXT NOT NULL DEFAULT '', filename TEXT NOT NULL, checksum TEXT NOT NULL, size INTEGER NOT NULL, reason TEXT NOT NULL, relative_path TEXT NOT NULL, created_at TEXT NOT NULL)`,
		`CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, action TEXT NOT NULL, profile_id TEXT NOT NULL DEFAULT '', detail TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'success')`,
		`CREATE INDEX IF NOT EXISTS idx_files_profile ON files(profile_id,kind,deleted_at)`,
		`CREATE INDEX IF NOT EXISTS idx_backups_date ON backups(created_at DESC)`,
		`CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(date DESC)`,
		`INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(1,datetime('now'))`,
	}
	for _, stmt := range statements {
		if _, err := db.Exec(stmt); err != nil {
			return err
		}
	}
	return nil
}

func (s *Server) securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Cross-Origin-Opener-Policy", "same-origin")
		w.Header().Set("Cross-Origin-Resource-Policy", "same-origin")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; media-src 'self' data: blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
		if s.cfg.TLSEnabled && r.TLS != nil {
			w.Header().Set("Strict-Transport-Security", "max-age=31536000")
		}
		if strings.HasPrefix(r.URL.Path, "/api/") {
			w.Header().Set("Cache-Control", "no-store")
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) handle(w http.ResponseWriter, r *http.Request) {
	if !isLoopbackRequest(r) {
		http.Error(w, "Accès local uniquement", http.StatusForbidden)
		return
	}
	if r.URL.Path == "/" {
		http.Redirect(w, r, s.cfg.BasePath, http.StatusTemporaryRedirect)
		return
	}
	if strings.HasPrefix(r.URL.Path, "/api/v1/") {
		s.handleAPI(w, r)
		return
	}
	if strings.HasPrefix(r.URL.Path, s.cfg.BasePath) {
		s.serveApp(w, r)
		return
	}
	http.NotFound(w, r)
}

func (s *Server) serveApp(w http.ResponseWriter, r *http.Request) {
	rel := strings.TrimPrefix(r.URL.Path, s.cfg.BasePath)
	if rel == "" || rel == "/" {
		rel = "index.html"
	}
	rel = filepath.ToSlash(filepath.Clean(strings.TrimPrefix(rel, "/")))
	allowed := rel == "index.html" || rel == "styles.css" || rel == "views.js" || rel == "script.js" || rel == "server-adapter.js" || (strings.HasPrefix(rel, "assets/") && !strings.Contains(rel, ".."))
	if !allowed {
		http.NotFound(w, r)
		return
	}
	full := filepath.Join(s.cfg.AppDir, filepath.FromSlash(rel))
	if !within(s.cfg.AppDir, full) {
		http.NotFound(w, r)
		return
	}
	info, err := os.Stat(full)
	if err != nil || info.IsDir() {
		http.NotFound(w, r)
		return
	}
	http.SetCookie(w, &http.Cookie{Name: s.sessionCookieName(), Value: s.sessionToken, Path: "/", HttpOnly: true, Secure: s.cfg.TLSEnabled, SameSite: http.SameSiteStrictMode, MaxAge: 12 * 3600})
	http.SetCookie(w, &http.Cookie{Name: s.csrfCookieName(), Value: s.csrfToken, Path: "/", HttpOnly: false, Secure: s.cfg.TLSEnabled, SameSite: http.SameSiteStrictMode, MaxAge: 12 * 3600})
	if ext := filepath.Ext(full); ext != "" {
		if kind := mime.TypeByExtension(ext); kind != "" {
			w.Header().Set("Content-Type", kind)
		}
	}
	if rel == "index.html" || strings.HasSuffix(rel, ".js") {
		w.Header().Set("Cache-Control", "no-cache")
	}
	http.ServeFile(w, r, full)
}

func (s *Server) handleAPI(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/api/v1/")
	if path == "health" && r.Method == http.MethodGet {
		s.handleHealth(w, r)
		return
	}
	if !s.authorized(r) {
		writeError(w, http.StatusForbidden, "Session locale VIE non autorisée")
		return
	}
	switch {
	case path == "bootstrap" && r.Method == http.MethodGet:
		s.handleBootstrap(w, r)
	case strings.HasPrefix(path, "state/") && r.Method == http.MethodPut:
		s.handleStatePut(w, r, strings.TrimPrefix(path, "state/"))
	case strings.HasPrefix(path, "state/") && r.Method == http.MethodDelete:
		s.handleStateDelete(w, r, strings.TrimPrefix(path, "state/"))
	case strings.HasPrefix(path, "files/"):
		s.handleFiles(w, r, strings.TrimPrefix(path, "files/"))
	case path == "backups" && r.Method == http.MethodGet:
		s.handleBackupsList(w, r)
	case path == "backups" && r.Method == http.MethodPost:
		s.handleBackupCreate(w, r)
	case strings.HasPrefix(path, "backups/") && r.Method == http.MethodGet:
		s.handleBackupDownload(w, r, strings.TrimPrefix(path, "backups/"))
	case path == "verify" && r.Method == http.MethodPost:
		s.handleVerify(w, r)
	default:
		writeError(w, http.StatusNotFound, "Route API inconnue")
	}
}

func (s *Server) sessionCookieName() string {
	if s.cfg.TLSEnabled {
		return "__Host-vie_local_session"
	}
	return "vie_local_session"
}

func (s *Server) csrfCookieName() string {
	if s.cfg.TLSEnabled {
		return "__Host-vie_csrf_token"
	}
	return "vie_csrf_token"
}

func (s *Server) authorized(r *http.Request) bool {
	if r.Header.Get("X-VIE-Admin-Token") != "" && subtleEqual(r.Header.Get("X-VIE-Admin-Token"), s.cfg.AdminToken) {
		return true
	}
	session, sessionErr := r.Cookie(s.sessionCookieName())
	csrf, csrfErr := r.Cookie(s.csrfCookieName())
	fetchSite := strings.ToLower(r.Header.Get("Sec-Fetch-Site"))
	fetchAllowed := fetchSite == "" || fetchSite == "same-origin" || fetchSite == "none"
	return sessionErr == nil && csrfErr == nil && subtleEqual(session.Value, s.sessionToken) && subtleEqual(csrf.Value, s.csrfToken) && subtleEqual(r.Header.Get("X-VIE-CSRF"), s.csrfToken) && r.Header.Get("X-VIE-Local") == "1" && fetchAllowed && s.validOrigin(r)
}

func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	transport := "HTTP local"
	tlsVersion := ""
	if s.cfg.TLSEnabled {
		transport = "HTTPS/TLS"
		if r.TLS != nil {
			tlsVersion = tlsVersionLabel(r.TLS.Version)
		}
	}
	response := map[string]any{"ok": true, "status": "actif", "serverVersion": serverVersion, "appURL": publicURL(s.cfg), "localOnly": true, "transport": transport, "tlsEnabled": s.cfg.TLSEnabled, "tlsVersion": tlsVersion, "certificateFingerprint": s.tlsInfo.Fingerprint, "certificateCAFingerprint": s.tlsInfo.CAFingerprint, "certificateExpiresAt": s.tlsInfo.ExpiresAt, "csrfProtected": true, "secureSessionCookie": s.cfg.TLSEnabled, "startedAt": s.startedAt.UTC().Format(time.RFC3339), "uptimeSeconds": int64(time.Since(s.startedAt).Seconds())}
	if s.authorized(r) {
		var stateCount, fileCount, backupCount int
		_ = s.db.QueryRow(`SELECT count(*) FROM state_envelopes`).Scan(&stateCount)
		_ = s.db.QueryRow(`SELECT count(*) FROM files WHERE deleted_at=''`).Scan(&fileCount)
		_ = s.db.QueryRow(`SELECT count(*) FROM backups`).Scan(&backupCount)
		var lastBackup string
		_ = s.db.QueryRow(`SELECT coalesce(max(created_at),'') FROM backups`).Scan(&lastBackup)
		response["database"] = "vie.db"
		response["databasePath"] = s.cfg.DataDir
		response["backupPath"] = s.cfg.BackupDir
		response["stateCount"] = stateCount
		response["fileCount"] = fileCount
		response["backupCount"] = backupCount
		response["lastBackup"] = lastBackup
	}
	writeJSON(w, http.StatusOK, response)
}

func (s *Server) handleBootstrap(w http.ResponseWriter, r *http.Request) {
	profile := normalizeProfile(r.URL.Query().Get("profile"))
	var envelope, securityConfig, registry, active, updated, appVersion, deviceID, checksum string
	var revision int64
	err := s.db.QueryRow(`SELECT e.envelope,p.security_config,p.profile_registry,p.active_profile_id,e.updated_at,e.revision,e.app_version,e.device_id,e.checksum FROM state_envelopes e JOIN profiles p ON p.profile_id=e.profile_id WHERE e.profile_id=?`, profile).Scan(&envelope, &securityConfig, &registry, &active, &updated, &revision, &appVersion, &deviceID, &checksum)
	if errors.Is(err, sql.ErrNoRows) {
		writeJSON(w, http.StatusOK, map[string]any{"ok": true, "found": false, "profileId": profile, "revision": 0})
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "Lecture SQLite impossible")
		return
	}
	sum := sha256.Sum256([]byte(envelope))
	if hex.EncodeToString(sum[:]) != checksum {
		s.audit("state_integrity_failed", profile, "empreinte de l’enveloppe invalide", "failed")
		writeError(w, http.StatusConflict, "Empreinte de l’état chiffré invalide")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "found": true, "profileId": profile, "envelope": json.RawMessage(envelope), "securityConfig": json.RawMessage(securityConfig), "profileRegistry": json.RawMessage(registry), "activeProfileId": active, "updatedAt": updated, "revision": revision, "appVersion": appVersion, "deviceId": deviceID})
}

func (s *Server) handleStatePut(w http.ResponseWriter, r *http.Request, rawProfile string) {
	if !safePart.MatchString(rawProfile) {
		writeError(w, http.StatusBadRequest, "Identifiant de profil invalide")
		return
	}
	profile := rawProfile
	if profile == "profile-guest" {
		writeError(w, http.StatusBadRequest, "Le profil invité ne peut pas être persisté")
		return
	}
	var req StateRequest
	if err := decodeJSON(w, r, s.cfg.MaxRequestMB, &req); err != nil {
		return
	}
	if len(req.Envelope) == 0 || !json.Valid(req.Envelope) || !validateSecureEnvelope(req.Envelope) || len(req.SecurityConfig) == 0 || !json.Valid(req.SecurityConfig) {
		writeError(w, http.StatusBadRequest, "Enveloppe chiffrée ou configuration invalide")
		return
	}
	if len(req.ProfileRegistry) == 0 || !json.Valid(req.ProfileRegistry) {
		req.ProfileRegistry = json.RawMessage("[]")
	}
	updated := req.UpdatedAt
	if updated == "" {
		var meta struct {
			UpdatedAt string `json:"updatedAt"`
		}
		_ = json.Unmarshal(req.Envelope, &meta)
		updated = meta.UpdatedAt
	}
	if updated == "" {
		updated = time.Now().UTC().Format(time.RFC3339Nano)
	}
	tx, err := s.db.Begin()
	if err != nil {
		writeError(w, 500, "Transaction SQLite impossible")
		return
	}
	defer tx.Rollback()
	var currentRevision int64
	var currentUpdated string
	err = tx.QueryRow(`SELECT revision,updated_at FROM state_envelopes WHERE profile_id=?`, profile).Scan(&currentRevision, &currentUpdated)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		writeError(w, 500, "Lecture de version impossible")
		return
	}
	if err == nil && !req.Force {
		if req.ExpectedRevision > 0 && req.ExpectedRevision != currentRevision {
			writeJSON(w, http.StatusConflict, map[string]any{"ok": false, "conflict": true, "message": "Une autre version existe déjà. Aucune donnée n’a été écrasée.", "currentRevision": currentRevision, "currentUpdatedAt": currentUpdated})
			return
		}
		if newer(currentUpdated, updated) {
			writeJSON(w, http.StatusConflict, map[string]any{"ok": false, "conflict": true, "message": "La version SQLite est plus récente. Aucune donnée n’a été écrasée.", "currentRevision": currentRevision, "currentUpdatedAt": currentUpdated})
			return
		}
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	if _, err = tx.Exec(`INSERT INTO profiles(profile_id,security_config,profile_registry,active_profile_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET security_config=excluded.security_config,profile_registry=excluded.profile_registry,active_profile_id=excluded.active_profile_id,updated_at=excluded.updated_at`, profile, string(req.SecurityConfig), string(req.ProfileRegistry), req.ActiveProfileID, now); err != nil {
		writeError(w, 500, "Profil SQLite non enregistré")
		return
	}
	revision := currentRevision + 1
	sum := sha256.Sum256(req.Envelope)
	if _, err = tx.Exec(`INSERT INTO state_envelopes(profile_id,envelope,checksum,app_version,device_id,updated_at,revision) VALUES(?,?,?,?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET envelope=excluded.envelope,checksum=excluded.checksum,app_version=excluded.app_version,device_id=excluded.device_id,updated_at=excluded.updated_at,revision=excluded.revision`, profile, string(req.Envelope), hex.EncodeToString(sum[:]), req.AppVersion, req.DeviceID, updated, revision); err != nil {
		writeError(w, 500, "État chiffré non enregistré")
		return
	}
	if _, err = tx.Exec(`INSERT INTO audit_log(date,action,profile_id,detail,status) VALUES(?,?,?,?,?)`, now, "state_saved", profile, fmt.Sprintf("révision %d", revision), "success"); err != nil {
		writeError(w, 500, "Journal SQLite non enregistré")
		return
	}
	if err = tx.Commit(); err != nil {
		writeError(w, 500, "Validation SQLite impossible")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "revision": revision, "updatedAt": updated, "checksum": hex.EncodeToString(sum[:])})
}

func (s *Server) handleStateDelete(w http.ResponseWriter, r *http.Request, rawProfile string) {
	if !safePart.MatchString(rawProfile) {
		writeError(w, http.StatusBadRequest, "Identifiant de profil invalide")
		return
	}
	profile := rawProfile
	if profile == "profile-main" || profile == "profile-guest" {
		writeError(w, http.StatusForbidden, "Ce profil ne peut pas être supprimé par cette route")
		return
	}
	if r.URL.Query().Get("confirm") != "true" {
		writeError(w, http.StatusBadRequest, "Confirmation explicite requise")
		return
	}
	if _, err := s.createBackup(profile, "avant suppression du profil"); err != nil {
		writeError(w, http.StatusInternalServerError, "Sauvegarde préalable impossible")
		return
	}
	rows, err := s.db.Query(`SELECT relative_path FROM files WHERE profile_id=? AND deleted_at=''`, profile)
	if err == nil {
		for rows.Next() {
			var rel string
			if rows.Scan(&rel) == nil {
				full := filepath.Join(s.cfg.DataDir, filepath.FromSlash(rel))
				trash := filepath.Join(s.cfg.DataDir, ".trash", time.Now().UTC().Format("20060102T150405")+"-"+hashName(profile+rel)+".vieblob")
				if within(s.cfg.DataDir, full) {
					_ = os.Rename(full, trash)
					nowTime := time.Now()
					_ = os.Chtimes(trash, nowTime, nowTime)
				}
			}
		}
		rows.Close()
	}
	tx, err := s.db.Begin()
	if err != nil {
		writeError(w, 500, "Transaction SQLite impossible")
		return
	}
	defer tx.Rollback()
	if _, err = tx.Exec(`DELETE FROM files WHERE profile_id=?`, profile); err != nil {
		writeError(w, 500, "Fichiers du profil non supprimés")
		return
	}
	if _, err = tx.Exec(`DELETE FROM profiles WHERE profile_id=?`, profile); err != nil {
		writeError(w, 500, "Profil SQLite non supprimé")
		return
	}
	if _, err = tx.Exec(`INSERT INTO audit_log(date,action,profile_id,detail,status) VALUES(?,?,?,?,?)`, time.Now().UTC().Format(time.RFC3339Nano), "profile_deleted", profile, "sauvegarde préalable créée", "success"); err != nil {
		writeError(w, 500, "Journal non enregistré")
		return
	}
	if err = tx.Commit(); err != nil {
		writeError(w, 500, "Suppression SQLite non validée")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "backupCreated": true, "trashRetentionDays": 30})
}

func (s *Server) handleFiles(w http.ResponseWriter, r *http.Request, tail string) {
	parts := strings.Split(strings.Trim(tail, "/"), "/")
	if len(parts) != 3 {
		writeError(w, 400, "Chemin de fichier invalide")
		return
	}
	profile, kind, id := parts[0], parts[1], parts[2]
	if !safePart.MatchString(profile) || !safePart.MatchString(kind) || !safePart.MatchString(id) {
		writeError(w, 400, "Identifiant de fichier invalide")
		return
	}
	switch r.Method {
	case http.MethodGet:
		s.getFile(w, profile, kind, id)
	case http.MethodPut:
		s.putFile(w, r, profile, kind, id)
	case http.MethodDelete:
		s.deleteFile(w, r, profile, kind, id)
	default:
		writeError(w, 405, "Méthode non autorisée")
	}
}

func (s *Server) putFile(w http.ResponseWriter, r *http.Request, profile, kind, id string) {
	if profile == "profile-guest" {
		writeError(w, 400, "Le profil invité ne peut pas stocker de fichier")
		return
	}
	var req FileRequest
	if err := decodeJSON(w, r, s.cfg.MaxRequestMB, &req); err != nil {
		return
	}
	if len(req.Record) == 0 || !json.Valid(req.Record) || !validateSecureEnvelope(req.Record) {
		writeError(w, 400, "Enveloppe chiffrée de fichier invalide")
		return
	}
	if req.LogicalSize < 0 || req.LogicalSize > maxLogicalFileBytes {
		writeError(w, http.StatusRequestEntityTooLarge, "Pièce jointe trop volumineuse : maximum 80 Mo")
		return
	}
	folder := filepath.Join(s.cfg.DataDir, "attachments", hashName(profile), kind)
	if err := os.MkdirAll(folder, 0700); err != nil {
		writeError(w, 500, "Dossier de pièces jointes inaccessible")
		return
	}
	filename := hashName(id) + ".vieblob"
	full := filepath.Join(folder, filename)
	if err := atomicWrite(full, req.Record, 0600); err != nil {
		writeError(w, 500, "Écriture de la pièce jointe impossible")
		return
	}
	rel, _ := filepath.Rel(s.cfg.DataDir, full)
	sum := sha256.Sum256(req.Record)
	now := time.Now().UTC().Format(time.RFC3339Nano)
	updated := req.UpdatedAt
	if updated == "" {
		updated = now
	}
	_, err := s.db.Exec(`INSERT INTO files(id,profile_id,kind,logical_size,stored_size,checksum,relative_path,created_at,updated_at,deleted_at) VALUES(?,?,?,?,?,?,?,?,?,'') ON CONFLICT(profile_id,kind,id) DO UPDATE SET logical_size=excluded.logical_size,stored_size=excluded.stored_size,checksum=excluded.checksum,relative_path=excluded.relative_path,updated_at=excluded.updated_at,deleted_at=''`, id, profile, kind, req.LogicalSize, len(req.Record), hex.EncodeToString(sum[:]), filepath.ToSlash(rel), now, updated)
	if err != nil {
		writeError(w, 500, "Métadonnées SQLite non enregistrées")
		return
	}
	s.audit("file_saved", profile, kind+":"+id, "success")
	writeJSON(w, 200, map[string]any{"ok": true, "checksum": hex.EncodeToString(sum[:]), "storedSize": len(req.Record)})
}

func (s *Server) getFile(w http.ResponseWriter, profile, kind, id string) {
	var rel, checksum string
	err := s.db.QueryRow(`SELECT relative_path,checksum FROM files WHERE profile_id=? AND kind=? AND id=? AND deleted_at=''`, profile, kind, id).Scan(&rel, &checksum)
	if errors.Is(err, sql.ErrNoRows) {
		writeJSON(w, 200, map[string]any{"ok": true, "found": false})
		return
	}
	if err != nil {
		writeError(w, 500, "Lecture SQLite impossible")
		return
	}
	full := filepath.Join(s.cfg.DataDir, filepath.FromSlash(rel))
	if !within(s.cfg.DataDir, full) {
		writeError(w, 500, "Chemin de fichier non sûr")
		return
	}
	raw, err := os.ReadFile(full)
	if err != nil {
		writeError(w, 404, "Pièce jointe absente")
		return
	}
	sum := sha256.Sum256(raw)
	if hex.EncodeToString(sum[:]) != checksum {
		writeError(w, 409, "Empreinte de la pièce jointe invalide")
		return
	}
	writeJSON(w, 200, map[string]any{"ok": true, "found": true, "record": json.RawMessage(raw), "checksum": checksum})
}

func (s *Server) deleteFile(w http.ResponseWriter, r *http.Request, profile, kind, id string) {
	if r.URL.Query().Get("confirm") != "true" {
		writeError(w, 400, "Confirmation explicite requise")
		return
	}
	var rel string
	err := s.db.QueryRow(`SELECT relative_path FROM files WHERE profile_id=? AND kind=? AND id=? AND deleted_at=''`, profile, kind, id).Scan(&rel)
	if errors.Is(err, sql.ErrNoRows) {
		writeJSON(w, 200, map[string]any{"ok": true, "alreadyAbsent": true})
		return
	}
	if err != nil {
		writeError(w, 500, "Lecture SQLite impossible")
		return
	}
	full := filepath.Join(s.cfg.DataDir, filepath.FromSlash(rel))
	trash := filepath.Join(s.cfg.DataDir, ".trash", time.Now().UTC().Format("20060102T150405")+"-"+hashName(profile+kind+id)+".vieblob")
	_ = os.MkdirAll(filepath.Dir(trash), 0700)
	if within(s.cfg.DataDir, full) {
		_ = os.Rename(full, trash)
		nowTime := time.Now()
		_ = os.Chtimes(trash, nowTime, nowTime)
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	_, err = s.db.Exec(`UPDATE files SET deleted_at=?,updated_at=? WHERE profile_id=? AND kind=? AND id=?`, now, now, profile, kind, id)
	if err != nil {
		writeError(w, 500, "Suppression logique impossible")
		return
	}
	s.audit("file_trashed", profile, kind+":"+id, "success")
	writeJSON(w, 200, map[string]any{"ok": true, "trashRetentionDays": 30})
}

func (s *Server) handleBackupCreate(w http.ResponseWriter, r *http.Request) {
	var body struct {
		ProfileID string `json:"profileId"`
		Reason    string `json:"reason"`
	}
	if err := decodeJSON(w, r, 2, &body); err != nil {
		return
	}
	info, err := s.createBackup(normalizeProfile(body.ProfileID), body.Reason)
	if err != nil {
		writeError(w, 500, "Sauvegarde cohérente impossible : "+err.Error())
		return
	}
	writeJSON(w, 201, map[string]any{"ok": true, "backup": info})
}
func (s *Server) handleBackupsList(w http.ResponseWriter, r *http.Request) {
	profile := normalizeProfile(r.URL.Query().Get("profile"))
	rows, err := s.db.Query(`SELECT id,profile_id,filename,checksum,size,created_at,reason,relative_path FROM backups WHERE profile_id='' OR profile_id=? ORDER BY created_at DESC LIMIT 100`, profile)
	if err != nil {
		writeError(w, 500, "Liste des sauvegardes inaccessible")
		return
	}
	defer rows.Close()
	items := []BackupInfo{}
	for rows.Next() {
		var x BackupInfo
		if rows.Scan(&x.ID, &x.ProfileID, &x.Filename, &x.Checksum, &x.Size, &x.CreatedAt, &x.Reason, &x.Path) == nil {
			items = append(items, x)
		}
	}
	writeJSON(w, 200, map[string]any{"ok": true, "backups": items})
}
func (s *Server) handleBackupDownload(w http.ResponseWriter, r *http.Request, id string) {
	if !safePart.MatchString(id) {
		writeError(w, 400, "Identifiant invalide")
		return
	}
	var filename, rel, checksum string
	if err := s.db.QueryRow(`SELECT filename,relative_path,checksum FROM backups WHERE id=?`, id).Scan(&filename, &rel, &checksum); err != nil {
		writeError(w, 404, "Sauvegarde introuvable")
		return
	}
	full := filepath.Join(s.cfg.BackupDir, filepath.FromSlash(rel))
	if !within(s.cfg.BackupDir, full) {
		writeError(w, 500, "Chemin non sûr")
		return
	}
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, strings.ReplaceAll(filename, "\"", "")))
	w.Header().Set("X-VIE-SHA256", checksum)
	http.ServeFile(w, r, full)
}

func (s *Server) createBackup(profile, reason string) (BackupInfo, error) {
	s.backupMu.Lock()
	defer s.backupMu.Unlock()
	if reason == "" {
		reason = "manuelle"
	}
	now := time.Now().UTC()
	id := "backup-" + now.Format("20060102T150405.000000000")
	filename := "VIE_BACKUP_" + now.Format("2006-01-02_15-04-05") + ".vie-local"
	tempDir, err := os.MkdirTemp(s.cfg.BackupDir, ".vie-backup-")
	if err != nil {
		return BackupInfo{}, err
	}
	defer os.RemoveAll(tempDir)
	snapshot := filepath.Join(tempDir, "vie.db")
	escaped := strings.ReplaceAll(snapshot, "'", "''")
	if _, err = s.db.Exec(`VACUUM INTO '` + escaped + `'`); err != nil {
		return BackupInfo{}, err
	}
	tempZip := filepath.Join(tempDir, filename)
	out, err := os.OpenFile(tempZip, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return BackupInfo{}, err
	}
	zw := zip.NewWriter(out)
	manifest, _ := json.MarshalIndent(map[string]any{"format": "VIE-LOCAL-BACKUP", "version": 1, "createdAt": now.Format(time.RFC3339Nano), "profileId": profile, "reason": reason, "serverVersion": serverVersion, "contains": []string{"SQLite chiffré au niveau applicatif", "Pièces jointes chiffrées", "Historique et paramètres"}}, "", "  ")
	if err = zipBytes(zw, "manifest.json", manifest); err == nil {
		err = zipFile(zw, "database/vie.db", snapshot)
	}
	attachments := filepath.Join(s.cfg.DataDir, "attachments")
	if err == nil {
		err = filepath.Walk(attachments, func(path string, info os.FileInfo, walkErr error) error {
			if walkErr != nil {
				return walkErr
			}
			if info.IsDir() {
				return nil
			}
			rel, relErr := filepath.Rel(attachments, path)
			if relErr != nil {
				return relErr
			}
			return zipFile(zw, "attachments/"+filepath.ToSlash(rel), path)
		})
	}
	closeErr := zw.Close()
	fileErr := out.Close()
	if err == nil {
		err = closeErr
	}
	if err == nil {
		err = fileErr
	}
	if err != nil {
		return BackupInfo{}, err
	}
	backupFile, err := os.Open(tempZip)
	if err != nil {
		return BackupInfo{}, err
	}
	hasher := sha256.New()
	_, copyErr := io.Copy(hasher, backupFile)
	stat, statErr := backupFile.Stat()
	closeHashErr := backupFile.Close()
	if copyErr != nil {
		return BackupInfo{}, copyErr
	}
	if statErr != nil {
		return BackupInfo{}, statErr
	}
	if closeHashErr != nil {
		return BackupInfo{}, closeHashErr
	}
	checksum := hex.EncodeToString(hasher.Sum(nil))
	final := filepath.Join(s.cfg.BackupDir, filename)
	if err = os.Rename(tempZip, final); err != nil {
		return BackupInfo{}, err
	}
	info := BackupInfo{ID: id, ProfileID: profile, Filename: filename, Checksum: checksum, Size: stat.Size(), CreatedAt: now.Format(time.RFC3339Nano), Reason: reason, Path: filename}
	_, err = s.db.Exec(`INSERT INTO backups(id,profile_id,filename,checksum,size,reason,relative_path,created_at) VALUES(?,?,?,?,?,?,?,?)`, info.ID, info.ProfileID, info.Filename, info.Checksum, info.Size, info.Reason, info.Path, info.CreatedAt)
	if err != nil {
		return BackupInfo{}, err
	}
	s.audit("backup_created", profile, filename, "success")
	s.cleanupBackups()
	return info, nil
}

func (s *Server) cleanupBackups() {
	rows, err := s.db.Query(`SELECT id,relative_path,created_at FROM backups ORDER BY created_at DESC`)
	if err != nil {
		return
	}
	type row struct{ id, path, date string }
	all := []row{}
	for rows.Next() {
		var x row
		if rows.Scan(&x.id, &x.path, &x.date) == nil {
			all = append(all, x)
		}
	}
	rows.Close()
	cutoff := time.Now().AddDate(0, 0, -s.cfg.RetentionDays)
	for index, x := range all {
		date, _ := time.Parse(time.RFC3339Nano, x.date)
		if index >= s.cfg.MaxBackups || (!date.IsZero() && date.Before(cutoff)) {
			full := filepath.Join(s.cfg.BackupDir, filepath.FromSlash(x.path))
			if within(s.cfg.BackupDir, full) {
				_ = os.Remove(full)
			}
			_, _ = s.db.Exec(`DELETE FROM backups WHERE id=?`, x.id)
		}
	}
}
func cleanupServerTrash(dataDir string, retentionDays int) {
	root := filepath.Join(dataDir, ".trash")
	cutoff := time.Now().AddDate(0, 0, -retentionDays)
	entries, _ := os.ReadDir(root)
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		info, err := entry.Info()
		if err == nil && info.ModTime().Before(cutoff) {
			_ = os.Remove(filepath.Join(root, entry.Name()))
		}
	}
}

func (s *Server) backupScheduler(ctx context.Context) {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	s.checkScheduledBackup()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.checkScheduledBackup()
		}
	}
}
func (s *Server) checkScheduledBackup() {
	cleanupServerTrash(s.cfg.DataDir, 30)
	if !s.cfg.AutoBackup {
		return
	}
	now := time.Now()
	if now.Format("15:04") < s.cfg.BackupTime {
		return
	}
	date := now.Format("2006-01-02")
	var last string
	_ = s.db.QueryRow(`SELECT value FROM server_meta WHERE key='last_auto_backup_date'`).Scan(&last)
	if last == date {
		return
	}
	if _, err := s.createBackup("", "automatique"); err != nil {
		s.logger.Println("Sauvegarde automatique échouée:", err)
		return
	}
	_, _ = s.db.Exec(`INSERT INTO server_meta(key,value,updated_at) VALUES('last_auto_backup_date',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at`, date, time.Now().UTC().Format(time.RFC3339Nano))
}

func (s *Server) handleVerify(w http.ResponseWriter, _ *http.Request) {
	result, err := s.verify()
	if err != nil {
		writeError(w, 500, "Vérification impossible : "+err.Error())
		return
	}
	writeJSON(w, 200, result)
}
func (s *Server) verify() (VerifyResult, error) {
	result := VerifyResult{CheckedAt: time.Now().UTC().Format(time.RFC3339Nano)}
	if err := s.db.QueryRow(`PRAGMA quick_check`).Scan(&result.Database); err != nil {
		return result, err
	}
	states, err := s.db.Query(`SELECT envelope,checksum FROM state_envelopes`)
	if err != nil {
		return result, err
	}
	for states.Next() {
		var envelope, want string
		if states.Scan(&envelope, &want) != nil {
			continue
		}
		result.StatesChecked++
		sum := sha256.Sum256([]byte(envelope))
		if hex.EncodeToString(sum[:]) == want {
			result.StatesValid++
		}
	}
	states.Close()
	rows, err := s.db.Query(`SELECT relative_path,checksum FROM files WHERE deleted_at=''`)
	if err != nil {
		return result, err
	}
	for rows.Next() {
		var rel, want string
		if rows.Scan(&rel, &want) != nil {
			continue
		}
		result.FilesChecked++
		full := filepath.Join(s.cfg.DataDir, filepath.FromSlash(rel))
		got, err := sha256File(full)
		if err != nil {
			result.MissingFiles++
			continue
		}
		if got == want {
			result.FilesValid++
		}
	}
	rows.Close()
	result.OK = result.Database == "ok" && result.StatesChecked == result.StatesValid && result.FilesChecked == result.FilesValid
	status := "success"
	if !result.OK {
		status = "warning"
	}
	s.audit("integrity_check", "", fmt.Sprintf("db=%s states=%d/%d files=%d/%d", result.Database, result.StatesValid, result.StatesChecked, result.FilesValid, result.FilesChecked), status)
	return result, nil
}

func (s *Server) audit(action, profile, detail, status string) {
	_, _ = s.db.Exec(`INSERT INTO audit_log(date,action,profile_id,detail,status) VALUES(?,?,?,?,?)`, time.Now().UTC().Format(time.RFC3339Nano), action, profile, detail, status)
	s.logger.Printf("%s profile=%s status=%s %s", action, profile, status, detail)
}

func decodeJSON(w http.ResponseWriter, r *http.Request, maxMB int64, target any) error {
	if maxMB <= 0 {
		maxMB = 16
	}
	body := http.MaxBytesReader(w, r.Body, maxMB<<20)
	defer body.Close()
	decoder := json.NewDecoder(body)
	if err := decoder.Decode(target); err != nil {
		writeError(w, 400, "JSON invalide ou trop volumineux")
		return err
	}
	return nil
}
func validateSecureEnvelope(raw json.RawMessage) bool {
	var envelope struct{ Format, Algorithm, IV, Data string }
	if json.Unmarshal(raw, &envelope) != nil {
		return false
	}
	return envelope.Format == "VIE-SECURE" && envelope.Algorithm == "AES-GCM" && envelope.IV != "" && envelope.Data != ""
}
func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]any{"ok": false, "error": message})
}
func normalizeProfile(value string) string {
	value = strings.TrimSpace(value)
	if safePart.MatchString(value) {
		return value
	}
	return "profile-main"
}
func newer(a, b string) bool {
	ta, ea := time.Parse(time.RFC3339Nano, a)
	tb, eb := time.Parse(time.RFC3339Nano, b)
	return ea == nil && eb == nil && ta.After(tb)
}
func randomToken(size int) string {
	raw := make([]byte, size)
	if _, err := rand.Read(raw); err != nil {
		return fmt.Sprintf("%d", time.Now().UnixNano())
	}
	return hex.EncodeToString(raw)
}
func hashName(value string) string {
	sum := sha256.Sum256([]byte(value))
	return hex.EncodeToString(sum[:16])
}
func sha256File(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer file.Close()
	hasher := sha256.New()
	if _, err = io.Copy(hasher, file); err != nil {
		return "", err
	}
	return hex.EncodeToString(hasher.Sum(nil)), nil
}
func atomicWrite(path string, data []byte, mode os.FileMode) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".vie-write-")
	if err != nil {
		return err
	}
	name := tmp.Name()
	defer os.Remove(name)
	if err = tmp.Chmod(mode); err == nil {
		_, err = tmp.Write(data)
	}
	if err == nil {
		err = tmp.Sync()
	}
	closeErr := tmp.Close()
	if err == nil {
		err = closeErr
	}
	if err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		_ = os.Remove(path)
	}
	return os.Rename(name, path)
}
func within(root, path string) bool {
	rootAbs, _ := filepath.Abs(root)
	pathAbs, _ := filepath.Abs(path)
	rel, err := filepath.Rel(rootAbs, pathAbs)
	return err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}
func isLoopbackRequest(r *http.Request) bool {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return false
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}
func (s *Server) validOrigin(r *http.Request) bool {
	origin := r.Header.Get("Origin")
	if origin == "" {
		return true
	}
	_, port, err := net.SplitHostPort(s.cfg.Listen)
	if err != nil {
		return false
	}
	scheme := "http"
	if s.cfg.TLSEnabled {
		scheme = "https"
	}
	allowed := map[string]bool{
		scheme + "://localhost:" + port: true,
		scheme + "://127.0.0.1:" + port: true,
		scheme + "://[::1]:" + port:     true,
	}
	return allowed[origin]
}
func subtleEqual(a, b string) bool {
	if len(a) != len(b) || len(a) == 0 {
		return false
	}
	var diff byte
	for i := range a {
		diff |= a[i] ^ b[i]
	}
	return diff == 0
}
func publicOrigin(cfg Config) string {
	_, port, err := net.SplitHostPort(cfg.Listen)
	if err != nil || port == "" {
		port = "8080"
	}
	scheme := "http"
	if cfg.TLSEnabled {
		scheme = "https"
	}
	return scheme + "://localhost:" + port
}

func publicURL(cfg Config) string {
	return publicOrigin(cfg) + cfg.BasePath
}
func openBrowser(url string) error {
	switch runtime.GOOS {
	case "windows":
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		return exec.Command("open", url).Start()
	default:
		return exec.Command("xdg-open", url).Start()
	}
}
func zipBytes(zw *zip.Writer, name string, data []byte) error {
	header := &zip.FileHeader{Name: name, Method: zip.Deflate}
	header.SetMode(0600)
	writer, err := zw.CreateHeader(header)
	if err != nil {
		return err
	}
	_, err = writer.Write(data)
	return err
}
func zipFile(zw *zip.Writer, name, path string) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return err
	}
	header := &zip.FileHeader{Name: name, Method: zip.Deflate, Modified: info.ModTime()}
	header.SetMode(0600)
	writer, err := zw.CreateHeader(header)
	if err != nil {
		return err
	}
	_, err = io.Copy(writer, file)
	return err
}

func (s *Server) sortedBackups() []BackupInfo {
	rows, err := s.db.Query(`SELECT id,profile_id,filename,checksum,size,created_at,reason,relative_path FROM backups ORDER BY created_at DESC`)
	if err != nil {
		return nil
	}
	defer rows.Close()
	items := []BackupInfo{}
	for rows.Next() {
		var x BackupInfo
		if rows.Scan(&x.ID, &x.ProfileID, &x.Filename, &x.Checksum, &x.Size, &x.CreatedAt, &x.Reason, &x.Path) == nil {
			items = append(items, x)
		}
	}
	sort.Slice(items, func(i, j int) bool { return items[i].CreatedAt > items[j].CreatedAt })
	return items
}
