//go:build windows

package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/mgr"
)

type vieService struct{ cfg Config }

func (service *vieService) Execute(_ []string, requests <-chan svc.ChangeRequest, changes chan<- svc.Status) (bool, uint32) {
	const accepted = svc.AcceptStop | svc.AcceptShutdown
	changes <- svc.Status{State: svc.StartPending}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- runServer(ctx, service.cfg) }()
	changes <- svc.Status{State: svc.Running, Accepts: accepted}
	for {
		select {
		case request := <-requests:
			switch request.Cmd {
			case svc.Interrogate:
				changes <- request.CurrentStatus
			case svc.Stop, svc.Shutdown:
				changes <- svc.Status{State: svc.StopPending}
				cancel()
				select {
				case err := <-done:
					if err != nil {
						return true, 1
					}
				case <-time.After(12 * time.Second):
					return true, 2
				}
				return false, 0
			}
		case err := <-done:
			if err != nil {
				return true, 1
			}
			return false, 0
		}
	}
}

func platformRunService(cfg Config) error {
	return svc.Run(serviceName, &vieService{cfg: cfg})
}

func platformInstallService(configPath string) error {
	executable, err := os.Executable()
	if err != nil {
		return err
	}
	manager, err := mgr.Connect()
	if err != nil {
		return err
	}
	defer manager.Disconnect()
	if existing, openErr := manager.OpenService(serviceName); openErr == nil {
		existing.Close()
		return errors.New("le service VIE existe déjà")
	}
	config := mgr.Config{DisplayName: serviceTitle, StartType: mgr.StartAutomatic, Description: "Serveur local HTTPS et SQLite de Ma Vie — accès limité à cet ordinateur."}
	service, err := manager.CreateService(serviceName, executable, config, "service", "--config", filepath.Clean(configPath))
	if err != nil {
		return err
	}
	defer service.Close()
	if err = service.Start(); err != nil {
		return fmt.Errorf("service installé mais démarrage impossible: %w", err)
	}
	return nil
}

func platformUninstallService() error {
	manager, err := mgr.Connect()
	if err != nil {
		return err
	}
	defer manager.Disconnect()
	service, err := manager.OpenService(serviceName)
	if err != nil {
		return err
	}
	defer service.Close()
	_, _ = service.Control(svc.Stop)
	time.Sleep(700 * time.Millisecond)
	return service.Delete()
}
