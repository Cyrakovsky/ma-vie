package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func testServer(t *testing.T) *Server {
	t.Helper()
	root := t.TempDir()
	app := filepath.Join(root, "app")
	for _, dir := range []string{app, filepath.Join(root, "data"), filepath.Join(root, "backups"), filepath.Join(root, "logs")} {
		if err := os.MkdirAll(dir, 0700); err != nil {
			t.Fatal(err)
		}
	}
	if err := os.WriteFile(filepath.Join(app, "index.html"), []byte("<!doctype html><title>VIE</title>"), 0600); err != nil {
		t.Fatal(err)
	}
	cfg := Config{Listen: "127.0.0.1:18080", BasePath: "/vie/", AppDir: app, DataDir: filepath.Join(root, "data"), BackupDir: filepath.Join(root, "backups"), LogDir: filepath.Join(root, "logs"), BackupTime: "06:30", RetentionDays: 30, MaxBackups: 5, MaxRequestMB: 8, AdminToken: "test-token", ConfigPath: filepath.Join(root, "config.json")}
	s, err := newServer(cfg)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(s.close)
	return s
}

func authorizedRequest(method, path string, body []byte, server *Server) *http.Request {
	req := httptest.NewRequest(method, path, bytes.NewReader(body))
	req.RemoteAddr = "127.0.0.1:32100"
	req.Header.Set("X-VIE-Local", "1")
	req.Header.Set("X-VIE-CSRF", server.csrfToken)
	req.Header.Set("Content-Type", "application/json")
	req.AddCookie(&http.Cookie{Name: server.sessionCookieName(), Value: server.sessionToken})
	req.AddCookie(&http.Cookie{Name: server.csrfCookieName(), Value: server.csrfToken})
	return req
}

func TestValidateConfigRejectsRemoteListen(t *testing.T) {
	cfg := Config{Listen: "0.0.0.0:8080", AppDir: t.TempDir()}
	if err := validateConfig(cfg); err == nil {
		t.Fatal("une écoute publique aurait dû être refusée")
	}
}

func TestEncryptedStateRevisionConflict(t *testing.T) {
	s := testServer(t)
	payload := map[string]any{
		"envelope":        map[string]any{"format": "VIE-SECURE", "algorithm": "AES-GCM", "iv": "opaque", "data": "opaque", "updatedAt": "2026-08-08T06:00:00Z"},
		"securityConfig":  map[string]any{"configured": true},
		"profileRegistry": []map[string]any{{"id": "profile-main"}},
		"activeProfileId": "profile-main", "appVersion": "12.0.0", "deviceId": "test", "updatedAt": "2026-08-08T06:00:00Z", "expectedRevision": 0,
	}
	raw, _ := json.Marshal(payload)
	first := httptest.NewRecorder()
	s.handle(first, authorizedRequest(http.MethodPut, "/api/v1/state/profile-main", raw, s))
	if first.Code != http.StatusOK {
		t.Fatalf("première écriture: %d %s", first.Code, first.Body.String())
	}
	payload["expectedRevision"] = 99
	payload["updatedAt"] = "2026-08-08T07:00:00Z"
	raw, _ = json.Marshal(payload)
	conflict := httptest.NewRecorder()
	s.handle(conflict, authorizedRequest(http.MethodPut, "/api/v1/state/profile-main", raw, s))
	if conflict.Code != http.StatusConflict {
		t.Fatalf("conflit attendu, obtenu %d", conflict.Code)
	}
}

func TestEncryptedFileBackupAndIntegrity(t *testing.T) {
	s := testServer(t)
	filePayload, _ := json.Marshal(map[string]any{"record": map[string]any{"format": "VIE-SECURE", "algorithm": "AES-GCM", "iv": "opaque", "data": "opaque"}, "logicalSize": 42})
	put := httptest.NewRecorder()
	s.handle(put, authorizedRequest(http.MethodPut, "/api/v1/files/profile-main/vault/document-1", filePayload, s))
	if put.Code != http.StatusOK {
		t.Fatalf("fichier: %d %s", put.Code, put.Body.String())
	}
	verify, err := s.verify()
	if err != nil || !verify.OK {
		t.Fatalf("vérification: %+v %v", verify, err)
	}
	backup, err := s.createBackup("profile-main", "test")
	if err != nil {
		t.Fatal(err)
	}
	if backup.Size <= 0 {
		t.Fatal("sauvegarde vide")
	}
	if _, err := os.Stat(filepath.Join(s.cfg.BackupDir, backup.Filename)); err != nil {
		t.Fatal(err)
	}
}
