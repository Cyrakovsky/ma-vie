package main

import (
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestTLSMaterialGenerationAndReuse(t *testing.T) {
	root := t.TempDir()
	cfg := Config{
		Listen:      "127.0.0.1:18443",
		BasePath:    "/vie/",
		TLSEnabled:  true,
		TLSCertFile: filepath.Join(root, "tls", "server-cert.pem"),
		TLSKeyFile:  filepath.Join(root, "tls", "server-key.pem"),
		TLSCAFile:   filepath.Join(root, "tls", "vie-local-ca.cer"),
	}
	first, err := ensureTLSMaterial(cfg, false)
	if err != nil {
		t.Fatal(err)
	}
	if !first.Enabled || !first.Generated || len(first.Fingerprint) != 64 || len(first.CAFingerprint) != 64 || first.ExpiresAt == "" {
		t.Fatalf("informations TLS incomplètes: %+v", first)
	}
	for _, path := range []string{cfg.TLSCertFile, cfg.TLSKeyFile, cfg.TLSCAFile} {
		if info, err := os.Stat(path); err != nil || info.Size() == 0 {
			t.Fatalf("fichier TLS manquant %s: %v", path, err)
		}
	}
	second, err := ensureTLSMaterial(cfg, false)
	if err != nil {
		t.Fatal(err)
	}
	if second.Generated || second.Fingerprint != first.Fingerprint || second.CAFingerprint != first.CAFingerprint {
		t.Fatalf("le certificat valide ne devait pas être remplacé: %+v / %+v", first, second)
	}
	tlsConfig, info, err := loadServerTLS(cfg)
	if err != nil || tlsConfig == nil || !info.Enabled {
		t.Fatalf("configuration TLS non chargeable: %+v %v", info, err)
	}
	if got := publicURL(cfg); got != "https://localhost:18443/vie/" {
		t.Fatalf("URL HTTPS inattendue: %s", got)
	}
}

func TestBrowserAuthorizationRequiresCSRF(t *testing.T) {
	server := testServer(t)
	valid := authorizedRequest(http.MethodGet, "/api/v1/bootstrap?profile=profile-main", nil, server)
	if !server.authorized(valid) {
		t.Fatal("la requête locale complète devrait être autorisée")
	}
	missingHeader := authorizedRequest(http.MethodGet, "/api/v1/bootstrap?profile=profile-main", nil, server)
	missingHeader.Header.Del("X-VIE-CSRF")
	if server.authorized(missingHeader) {
		t.Fatal("une requête sans en-tête CSRF ne doit pas être autorisée")
	}
	crossOrigin := authorizedRequest(http.MethodGet, "/api/v1/bootstrap?profile=profile-main", nil, server)
	crossOrigin.Header.Set("Origin", "https://example.invalid")
	if server.authorized(crossOrigin) {
		t.Fatal("une origine externe ne doit pas être autorisée")
	}
}

func TestHTTPSConfigRejectsMissingPaths(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "index.html"), []byte("VIE"), 0600); err != nil {
		t.Fatal(err)
	}
	cfg := Config{Listen: "127.0.0.1:8080", AppDir: root, TLSEnabled: true}
	if err := validateConfig(cfg); err == nil || !strings.Contains(err.Error(), "chemins") {
		t.Fatalf("les chemins TLS manquants auraient dû être refusés: %v", err)
	}
}
