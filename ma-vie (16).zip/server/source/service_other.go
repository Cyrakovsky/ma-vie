//go:build !windows

package main

import "errors"

func platformRunService(cfg Config) error { return runInteractive(cfg) }
func platformInstallService(_ string) error {
	return errors.New("l’installation native comme service est disponible sous Windows")
}
func platformUninstallService() error {
	return errors.New("la désinstallation native du service est disponible sous Windows")
}
