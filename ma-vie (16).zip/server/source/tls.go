package main

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const certificateRenewalWindow = 180 * 24 * time.Hour

type TLSInfo struct {
	Enabled       bool   `json:"enabled"`
	Fingerprint   string `json:"fingerprint"`
	CAFingerprint string `json:"caFingerprint"`
	ExpiresAt     string `json:"expiresAt"`
	Generated     bool   `json:"generated,omitempty"`
}

func ensureTLSMaterial(cfg Config, force bool) (TLSInfo, error) {
	if !cfg.TLSEnabled {
		return TLSInfo{Enabled: false}, nil
	}
	if !force {
		if info, err := inspectTLSMaterial(cfg); err == nil {
			expires, _ := time.Parse(time.RFC3339, info.ExpiresAt)
			if time.Until(expires) >= certificateRenewalWindow {
				return info, nil
			}
		}
	}
	for _, path := range []string{cfg.TLSCertFile, cfg.TLSKeyFile, cfg.TLSCAFile} {
		if strings.TrimSpace(path) == "" {
			return TLSInfo{}, errors.New("chemin TLS manquant dans config.json")
		}
		if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			return TLSInfo{}, err
		}
	}

	now := time.Now().UTC()
	caKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return TLSInfo{}, err
	}
	caSerial, err := randomSerial()
	if err != nil {
		return TLSInfo{}, err
	}
	caTemplate := &x509.Certificate{
		SerialNumber:          caSerial,
		Subject:               pkix.Name{Organization: []string{"Ma Vie"}, CommonName: "VIE Local Root CA"},
		NotBefore:             now.Add(-time.Hour),
		NotAfter:              now.AddDate(10, 0, 0),
		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
		BasicConstraintsValid: true,
		IsCA:                  true,
		MaxPathLen:            0,
		MaxPathLenZero:        true,
	}
	caDER, err := x509.CreateCertificate(rand.Reader, caTemplate, caTemplate, &caKey.PublicKey, caKey)
	if err != nil {
		return TLSInfo{}, err
	}
	caCert, err := x509.ParseCertificate(caDER)
	if err != nil {
		return TLSInfo{}, err
	}

	serverKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return TLSInfo{}, err
	}
	serverSerial, err := randomSerial()
	if err != nil {
		return TLSInfo{}, err
	}
	serverTemplate := &x509.Certificate{
		SerialNumber: serverSerial,
		Subject:      pkix.Name{Organization: []string{"Ma Vie"}, CommonName: "localhost"},
		NotBefore:    now.Add(-time.Hour),
		NotAfter:     now.AddDate(5, 0, 0),
		DNSNames:     []string{"localhost"},
		IPAddresses: []net.IP{
			net.ParseIP("127.0.0.1"),
			net.ParseIP("::1"),
		},
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	serverDER, err := x509.CreateCertificate(rand.Reader, serverTemplate, caCert, &serverKey.PublicKey, caKey)
	if err != nil {
		return TLSInfo{}, err
	}
	keyDER, err := x509.MarshalPKCS8PrivateKey(serverKey)
	if err != nil {
		return TLSInfo{}, err
	}
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: serverDER})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER})
	if err := atomicWrite(cfg.TLSCertFile, certPEM, 0644); err != nil {
		return TLSInfo{}, err
	}
	if err := atomicWrite(cfg.TLSKeyFile, keyPEM, 0600); err != nil {
		return TLSInfo{}, err
	}
	caPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: caDER})
	if err := atomicWrite(cfg.TLSCAFile, caPEM, 0644); err != nil {
		return TLSInfo{}, err
	}
	info, err := inspectTLSMaterial(cfg)
	if err != nil {
		return TLSInfo{}, err
	}
	info.Generated = true
	return info, nil
}

func randomSerial() (*big.Int, error) {
	limit := new(big.Int).Lsh(big.NewInt(1), 128)
	serial, err := rand.Int(rand.Reader, limit)
	if err != nil {
		return nil, err
	}
	if serial.Sign() == 0 {
		serial.SetInt64(1)
	}
	return serial, nil
}

func inspectTLSMaterial(cfg Config) (TLSInfo, error) {
	pair, err := tls.LoadX509KeyPair(cfg.TLSCertFile, cfg.TLSKeyFile)
	if err != nil {
		return TLSInfo{}, fmt.Errorf("certificat ou clé TLS invalide: %w", err)
	}
	if len(pair.Certificate) == 0 {
		return TLSInfo{}, errors.New("certificat TLS vide")
	}
	leaf, err := x509.ParseCertificate(pair.Certificate[0])
	if err != nil {
		return TLSInfo{}, err
	}
	if time.Now().Before(leaf.NotBefore) || !time.Now().Before(leaf.NotAfter) {
		return TLSInfo{}, errors.New("certificat TLS hors de sa période de validité")
	}
	if err := leaf.VerifyHostname("localhost"); err != nil {
		return TLSInfo{}, fmt.Errorf("certificat non valable pour localhost: %w", err)
	}
	caDER, err := os.ReadFile(cfg.TLSCAFile)
	if err != nil {
		return TLSInfo{}, fmt.Errorf("certificat racine local introuvable: %w", err)
	}
	if block, _ := pem.Decode(caDER); block != nil {
		caDER = block.Bytes
	}
	ca, err := x509.ParseCertificate(caDER)
	if err != nil {
		return TLSInfo{}, fmt.Errorf("certificat racine local invalide: %w", err)
	}
	if err := leaf.CheckSignatureFrom(ca); err != nil {
		return TLSInfo{}, fmt.Errorf("chaîne TLS VIE invalide: %w", err)
	}
	return TLSInfo{
		Enabled:       true,
		Fingerprint:   certificateFingerprint(leaf.Raw),
		CAFingerprint: certificateFingerprint(ca.Raw),
		ExpiresAt:     leaf.NotAfter.UTC().Format(time.RFC3339),
	}, nil
}

func certificateFingerprint(raw []byte) string {
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func loadServerTLS(cfg Config) (*tls.Config, TLSInfo, error) {
	if !cfg.TLSEnabled {
		return nil, TLSInfo{Enabled: false}, nil
	}
	info, err := inspectTLSMaterial(cfg)
	if err != nil {
		return nil, TLSInfo{}, fmt.Errorf("HTTPS local indisponible; exécutez « vie-server init-tls »: %w", err)
	}
	pair, err := tls.LoadX509KeyPair(cfg.TLSCertFile, cfg.TLSKeyFile)
	if err != nil {
		return nil, TLSInfo{}, err
	}
	return &tls.Config{
		Certificates: []tls.Certificate{pair},
		MinVersion:   tls.VersionTLS12,
		NextProtos:   []string{"http/1.1"},
		CurvePreferences: []tls.CurveID{
			tls.X25519,
			tls.CurveP256,
		},
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
		},
	}, info, nil
}

type bufferedConn struct {
	net.Conn
	reader *bufio.Reader
}

func (c *bufferedConn) Read(p []byte) (int, error) { return c.reader.Read(p) }

type tlsRedirectListener struct {
	net.Listener
	tlsConfig   *tls.Config
	cfg         Config
	startOnce   sync.Once
	closeOnce   sync.Once
	connections chan net.Conn
	errors      chan error
	done        chan struct{}
}

func (l *tlsRedirectListener) start() {
	l.connections = make(chan net.Conn, 64)
	l.errors = make(chan error, 1)
	l.done = make(chan struct{})
	go func() {
		for {
			conn, err := l.Listener.Accept()
			if err != nil {
				select {
				case l.errors <- err:
				case <-l.done:
				}
				return
			}
			go l.classify(conn)
		}
	}()
}

func (l *tlsRedirectListener) classify(conn net.Conn) {
	_ = conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	reader := bufio.NewReaderSize(conn, 4096)
	first, err := reader.Peek(1)
	_ = conn.SetReadDeadline(time.Time{})
	if err != nil {
		_ = conn.Close()
		return
	}
	if first[0] != 0x16 {
		redirectPlainHTTP(conn, reader, l.cfg)
		return
	}
	secure := tls.Server(&bufferedConn{Conn: conn, reader: reader}, l.tlsConfig.Clone())
	select {
	case l.connections <- secure:
	case <-l.done:
		_ = secure.Close()
	}
}

func (l *tlsRedirectListener) Accept() (net.Conn, error) {
	l.startOnce.Do(l.start)
	select {
	case conn := <-l.connections:
		return conn, nil
	case err := <-l.errors:
		return nil, err
	case <-l.done:
		return nil, net.ErrClosed
	}
}

func (l *tlsRedirectListener) Close() error {
	l.startOnce.Do(l.start)
	l.closeOnce.Do(func() { close(l.done) })
	return l.Listener.Close()
}

func redirectPlainHTTP(conn net.Conn, reader *bufio.Reader, cfg Config) {
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(5 * time.Second))
	request, err := http.ReadRequest(reader)
	path := cfg.BasePath
	if err == nil {
		if request.Body != nil {
			_ = request.Body.Close()
		}
		if request.URL != nil && strings.HasPrefix(request.URL.RequestURI(), "/") {
			path = request.URL.RequestURI()
		}
	}
	location := publicOrigin(cfg) + path
	body := "VIE utilise HTTPS local. Redirection vers " + location + "\n"
	_, _ = fmt.Fprintf(conn, "HTTP/1.1 308 Permanent Redirect\r\nLocation: %s\r\nCache-Control: no-store\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s", location, len([]byte(body)), body)
}

func serveConfiguredHTTP(server *http.Server, cfg Config, tlsConfig *tls.Config) error {
	listener, err := net.Listen("tcp", cfg.Listen)
	if err != nil {
		return err
	}
	if !cfg.TLSEnabled {
		return server.Serve(listener)
	}
	return server.Serve(&tlsRedirectListener{Listener: listener, tlsConfig: tlsConfig, cfg: cfg})
}

func tlsVersionLabel(version uint16) string {
	switch version {
	case tls.VersionTLS13:
		return "TLS 1.3"
	case tls.VersionTLS12:
		return "TLS 1.2"
	default:
		return "TLS"
	}
}
