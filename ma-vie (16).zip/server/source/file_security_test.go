package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestEncryptedFileRejectsOversizedLogicalPayload(t *testing.T) {
	server := testServer(t)
	payload, _ := json.Marshal(map[string]any{
		"record":      map[string]any{"format": "VIE-SECURE", "algorithm": "AES-GCM", "iv": "opaque", "data": "opaque"},
		"logicalSize": maxLogicalFileBytes + 1,
	})
	response := httptest.NewRecorder()
	server.handle(response, authorizedRequest(http.MethodPut, "/api/v1/files/profile-main/vault/too-large", payload, server))
	if response.Code != http.StatusRequestEntityTooLarge {
		t.Fatalf("taille excessive: code %d, corps %s", response.Code, response.Body.String())
	}
}
