@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "VIE_NO_AUTO_BROWSER=1"
if exist "%~dp0config.json" (
  "%~dp0vie-server.exe" init-tls --config "%~dp0config.json" >nul
  if errorlevel 1 (
    echo Le certificat HTTPS local n'est pas pret. Lancez INSTALLER-VIE.bat ou reparer-https.ps1.
    pause
    exit /b 1
  )
  start "VIE Server" /min "%~dp0vie-server.exe" serve --config "%~dp0config.json"
) else (
  echo Configuration VIE introuvable. Lancez INSTALLER-VIE.bat.
  pause
  exit /b 1
)
timeout /t 2 /nobreak >nul
start "" https://localhost:8080/vie/
