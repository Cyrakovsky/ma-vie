﻿param(
  [string]$InstallRoot="C:\VIE",
  [switch]$Renouveler
)

$ErrorActionPreference="Stop"
$ServiceName="VIEServer"
$ServerDir=Join-Path $InstallRoot "server"
$Exe=Join-Path $ServerDir "vie-server.exe"
$ConfigPath=Join-Path $ServerDir "config.json"

function Test-Administrator {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Resolve-ConfigPath([string]$Base,[string]$Value) {
  if([IO.Path]::IsPathRooted($Value)){return [IO.Path]::GetFullPath($Value)}
  return [IO.Path]::GetFullPath((Join-Path $Base $Value))
}

if(!(Test-Administrator)){
  $args="-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  if($Renouveler){$args+=" -Renouveler"}
  $process=Start-Process powershell.exe -Verb RunAs -ArgumentList $args -PassThru -Wait
  exit $process.ExitCode
}
if(!(Test-Path $Exe)){throw "Serveur VIE introuvable : $Exe"}
if(!(Test-Path $ConfigPath)){throw "Configuration VIE introuvable : $ConfigPath"}

$config=Get-Content $ConfigPath -Raw|ConvertFrom-Json
if(!($config.PSObject.Properties.Name -contains "tlsEnabled") -or !$config.tlsEnabled){
  throw "HTTPS n’est pas activé dans config.json. Relancez INSTALLER-VIE.bat pour migrer proprement l’installation."
}

$wasRunning=$false
$service=Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if($service -and $service.Status -eq "Running"){
  $wasRunning=$true
  Stop-Service -Name $ServiceName -Force
  Start-Sleep -Milliseconds 800
}
try{
  $command=if($Renouveler){"renew-tls"}else{"init-tls"}
  Write-Host "Vérification du certificat HTTPS local…" -ForegroundColor Cyan
  & $Exe $command --config $ConfigPath
  if($LASTEXITCODE -ne 0){throw "La préparation du certificat a échoué."}
  $CAFile=Resolve-ConfigPath $ServerDir ([string]$config.tlsCAFile)
  $certificate=New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $CAFile
  $store="Cert:\LocalMachine\Root"
  if(!(Get-ChildItem $store|Where-Object{$_.Thumbprint -eq $certificate.Thumbprint})){
    Write-Host "Installation explicite de l’autorité VIE dans le magasin de confiance Windows." -ForegroundColor Yellow
    Import-Certificate -FilePath $CAFile -CertStoreLocation $store|Out-Null
  }
  if($Renouveler){
    $obsolete=Get-ChildItem $store|Where-Object{$_.Subject -like "*CN=VIE Local Root CA*" -and $_.Thumbprint -ne $certificate.Thumbprint}
    foreach($old in $obsolete){Write-Host "Retrait de l’ancienne autorité VIE $($old.Thumbprint)." -ForegroundColor Yellow;$old|Remove-Item -Force}
  }
  Write-Host "HTTPS VIE prêt · autorité $($certificate.Thumbprint)" -ForegroundColor Green
} finally {
  if($service){Start-Service -Name $ServiceName;Start-Sleep -Seconds 2}
}

$port=($config.listen -split ':')[-1]
$url="https://localhost:$port/"+$config.basePath.Trim('/')+"/"
Start-Process $url
Write-Host "Adresse : $url"
