﻿param(
  [string]$InstallRoot="C:\VIE",
  [switch]$RetirerCertificatHTTPS
)
$ErrorActionPreference="Stop"
$exe=Join-Path $InstallRoot "server\vie-server.exe"
$configPath=Join-Path $InstallRoot "server\config.json"
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $args="-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  if($RetirerCertificatHTTPS){$args+=" -RetirerCertificatHTTPS"}
  Start-Process powershell.exe -Verb RunAs -ArgumentList $args
  exit
}
if(Test-Path $exe){& $exe uninstall-service --config $configPath}
if($RetirerCertificatHTTPS -and (Test-Path $configPath)){
  $config=Get-Content $configPath -Raw|ConvertFrom-Json
  if($config.tlsCAFile){
    $serverDir=Join-Path $InstallRoot "server"
    $caPath=if([IO.Path]::IsPathRooted([string]$config.tlsCAFile)){[string]$config.tlsCAFile}else{[IO.Path]::GetFullPath((Join-Path $serverDir ([string]$config.tlsCAFile)))}
    if(Test-Path $caPath){
      $cert=New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $caPath
      $storeItems=Get-ChildItem Cert:\LocalMachine\Root|Where-Object{$_.Thumbprint -eq $cert.Thumbprint -or $_.Subject -like "*CN=VIE Local Root CA*"}
      if($storeItems){$storeItems|Remove-Item -Force;Write-Host "Autorité(s) HTTPS VIE retirée(s) explicitement." -ForegroundColor Yellow}
    }
  }
}else{
  Write-Host "Le certificat HTTPS local est conservé avec l’installation VIE. Utilisez -RetirerCertificatHTTPS pour le supprimer explicitement." -ForegroundColor Cyan
}
Write-Host "Le service VIE a été retiré. Les dossiers app, data et backups sont conservés." -ForegroundColor Yellow
