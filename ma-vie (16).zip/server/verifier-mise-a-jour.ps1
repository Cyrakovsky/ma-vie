﻿param(
  [string]$InstallRoot = "C:\VIE",
  [switch]$Force,
  [switch]$Interactive
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$UpdaterVersion = "1.0.0"
$ServerDir = Join-Path $InstallRoot "server"
$AppDir = Join-Path $InstallRoot "app"
$LogDir = Join-Path $InstallRoot "logs"
$StatePath = Join-Path $ServerDir "update-state.json"
$InstalledConfigPath = Join-Path $ServerDir "update-config.json"
$ConfigPath = if (Test-Path $InstalledConfigPath) { $InstalledConfigPath } else { Join-Path $PSScriptRoot "update-config.json" }
$LogPath = Join-Path $LogDir "mise-a-jour.log"

function Write-UpdateLog([string]$Message) {
  try {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    Add-Content -Path $LogPath -Encoding UTF8 -Value "[$((Get-Date).ToString('s'))] CHECK $Message"
  } catch {}
}

function Show-Info([string]$Text,[string]$Title="Ma Vie — mise à jour") {
  if (!$Interactive) { return }
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($Text,$Title,[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
  } catch { Write-Host $Text }
}

function Save-State($State) {
  try {
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText($StatePath,($State | ConvertTo-Json -Depth 8),$utf8)
  } catch { Write-UpdateLog "État non enregistré : $($_.Exception.Message)" }
}

trap {
  $message=$_.Exception.Message
  Write-UpdateLog "ERREUR : $message`n$($_ | Out-String)"
  if($Interactive){Show-Info "La vérification a échoué sans modifier Ma Vie.`r`n`r`n$message`r`n`r`nJournal : $LogPath" "Ma Vie — erreur de mise à jour"}
  exit 3
}

function Convert-AppVersion([string]$Value) {
  $clean = ([string]$Value).Trim().TrimStart('v','V') -replace '-.*$',''
  try { return [Version]$clean } catch { throw "Version invalide : $Value" }
}

function Get-LocalVersion {
  $versionFile = Join-Path $AppDir "VERSION.txt"
  if (Test-Path $versionFile) {
    $text = Get-Content $versionFile -Raw
    if ($text -match 'Application Ma Vie\s+([0-9]+\.[0-9]+\.[0-9]+)') { return $Matches[1] }
  }
  $scriptFile = Join-Path $AppDir "script.js"
  if (Test-Path $scriptFile) {
    $text = Get-Content $scriptFile -Raw
    if ($text -match 'APP_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"') { return $Matches[1] }
  }
  throw "Version locale introuvable dans $AppDir. Installez d’abord Ma Vie avec INSTALLER-VIE.bat."
}

if (!(Test-Path $ConfigPath)) {
  Show-Info "Configuration de mise à jour introuvable : $ConfigPath"
  exit 2
}
$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
if ([string]$config.repository -ne "Cyrakovsky/ma-vie") { throw "Dépôt de mise à jour non autorisé : $($config.repository)" }
if ([string]$config.apiUrl -ne "https://api.github.com/repos/Cyrakovsky/ma-vie/releases/latest") { throw "API de mise à jour non autorisée : $($config.apiUrl)" }
if (!$Force -and !$config.automaticCheck) { exit 0 }

$state = if (Test-Path $StatePath) { try { Get-Content $StatePath -Raw | ConvertFrom-Json } catch { [pscustomobject]@{} } } else { [pscustomobject]@{} }
$interval = [Math]::Max(1,[int]$config.checkIntervalHours)
if (!$Force -and $state.lastCheckedAt) {
  $last = [DateTime]::MinValue
  if ([DateTime]::TryParse([string]$state.lastCheckedAt,[ref]$last) -and (Get-Date) -lt $last.AddHours($interval)) { exit 0 }
}

$headers = @{
  "Accept" = "application/vnd.github+json"
  "User-Agent" = "Ma-Vie-Updater/$UpdaterVersion"
  "X-GitHub-Api-Version" = "2022-11-28"
}
$state | Add-Member -NotePropertyName lastCheckedAt -NotePropertyValue ((Get-Date).ToUniversalTime().ToString("o")) -Force
try {
  $release = Invoke-RestMethod -Uri ([string]$config.apiUrl) -Headers $headers -TimeoutSec 20
} catch {
  $status = try { [int]$_.Exception.Response.StatusCode } catch { 0 }
  if ($status -eq 404) {
    $state | Add-Member -NotePropertyName lastResult -NotePropertyValue "NO_RELEASE" -Force
    Save-State $state
    Write-UpdateLog "Aucune GitHub Release n’est encore publiée."
    Show-Info "Le dépôt GitHub existe, mais aucune version n’y est encore publiée.`r`n`r`nCréez une première Release avec le tag v$(Get-LocalVersion)."
    exit 0
  }
  $state | Add-Member -NotePropertyName lastResult -NotePropertyValue "NETWORK_ERROR" -Force
  Save-State $state
  Write-UpdateLog "GitHub indisponible : $($_.Exception.Message)"
  if ($Interactive) { Show-Info "Impossible de vérifier GitHub maintenant.`r`n`r`n$($_.Exception.Message)" }
  exit 3
}

if ($release.draft -or $release.prerelease) { throw "La release reçue n’est pas une version stable." }
$remoteVersion = ([string]$release.tag_name).TrimStart('v','V')
$localVersion = Get-LocalVersion
[void](Convert-AppVersion $remoteVersion)
[void](Convert-AppVersion $localVersion)
$manifestAsset = $release.assets | Where-Object { $_.name -eq [string]$config.manifestAsset } | Select-Object -First 1
$packageAsset = $release.assets | Where-Object { $_.name -eq [string]$config.packageAsset } | Select-Object -First 1
if (!$manifestAsset -or !$packageAsset) {
  throw "Release incomplète : $($config.manifestAsset) et $($config.packageAsset) sont obligatoires."
}
if (([Uri]$manifestAsset.browser_download_url).Host -ne "github.com" -or ([Uri]$packageAsset.browser_download_url).Host -ne "github.com") { throw "Hôte de Release non autorisé." }

$manifest = Invoke-RestMethod -Uri ([string]$manifestAsset.browser_download_url) -Headers $headers -TimeoutSec 20
if ([string]$manifest.repository -ne [string]$config.repository) { throw "Le manifeste ne correspond pas au dépôt autorisé." }
if ([string]$manifest.version -ne $remoteVersion) { throw "Version incohérente entre le tag et le manifeste." }
if ([string]$manifest.package.name -ne [string]$config.packageAsset) { throw "Nom de paquet inattendu dans le manifeste." }
if ([string]$manifest.package.sha256 -notmatch '^[0-9a-fA-F]{64}$') { throw "Empreinte SHA-256 absente ou invalide." }
if ($manifest.minimumUpdaterVersion -and (Convert-AppVersion $UpdaterVersion) -lt (Convert-AppVersion ([string]$manifest.minimumUpdaterVersion))) { throw "Cette version exige l’updater $($manifest.minimumUpdaterVersion) ou supérieur. Installez d’abord le paquet manuellement." }

$state | Add-Member -NotePropertyName latestVersion -NotePropertyValue $remoteVersion -Force
if ((Convert-AppVersion $remoteVersion) -le (Convert-AppVersion $localVersion)) {
  $state | Add-Member -NotePropertyName lastResult -NotePropertyValue "UP_TO_DATE" -Force
  Save-State $state
  Write-UpdateLog "Version locale $localVersion à jour."
  Show-Info "Ma Vie est à jour.`r`n`r`nVersion installée : $localVersion"
  exit 0
}

$state | Add-Member -NotePropertyName lastResult -NotePropertyValue "UPDATE_AVAILABLE" -Force
$state | Add-Member -NotePropertyName lastNotifiedVersion -NotePropertyValue $remoteVersion -Force
Save-State $state
Write-UpdateLog "Mise à jour disponible : $localVersion -> $remoteVersion."

$answer = $null
try {
  Add-Type -AssemblyName System.Windows.Forms
  $message = "Une nouvelle version de Ma Vie est disponible.`r`n`r`nVersion installée : $localVersion`r`nNouvelle version : $remoteVersion`r`n`r`nVIE créera une sauvegarde, vérifiera SHA-256 et pourra revenir à l’ancienne version en cas d’échec.`r`n`r`nInstaller maintenant ?"
  $answer = [System.Windows.Forms.MessageBox]::Show($message,"Ma Vie — mise à jour disponible",[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
} catch {
  Write-UpdateLog "Interface de confirmation indisponible ; aucune installation lancée."
  exit 10
}
if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
  $state | Add-Member -NotePropertyName lastDeclinedAt -NotePropertyValue ((Get-Date).ToUniversalTime().ToString("o")) -Force
  Save-State $state
  Write-UpdateLog "Installation reportée par l’utilisateur."
  exit 10
}

$sourceUpdater = if (Test-Path (Join-Path $PSScriptRoot "mettre-a-jour-vie.ps1")) { Join-Path $PSScriptRoot "mettre-a-jour-vie.ps1" } else { Join-Path $ServerDir "mettre-a-jour-vie.ps1" }
if (!(Test-Path $sourceUpdater)) { throw "Moteur de mise à jour introuvable : $sourceUpdater" }
$tempUpdater = Join-Path $env:TEMP ("mettre-a-jour-vie-" + [Guid]::NewGuid().ToString("N") + ".ps1")
Copy-Item $sourceUpdater $tempUpdater -Force
$arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$tempUpdater`" -InstallRoot `"$InstallRoot`" -ExpectedVersion `"$remoteVersion`""
$process = Start-Process powershell.exe -Verb RunAs -ArgumentList $arguments -PassThru -Wait
try { Remove-Item $tempUpdater -Force -ErrorAction SilentlyContinue } catch {}
exit $process.ExitCode
