@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   Ma Vie - diagnostic de la page blanche et du serveur
echo ============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0diagnostiquer-vie.ps1" -InstallRoot "C:\VIE"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo Diagnostic termine : aucun probleme detecte.
) else (
  echo Diagnostic termine avec %RC% erreur(s).
  echo Le rapport a ete ouvert dans le Bloc-notes.
)
echo.
pause
exit /b %RC%
