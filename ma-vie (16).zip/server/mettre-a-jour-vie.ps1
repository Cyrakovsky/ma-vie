﻿param(
  [string]$InstallRoot = "C:\VIE",
  [string]$ExpectedVersion = "",
  [string]$Repository = "Cyrakovsky/ma-vie"
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$UpdaterVersion = "1.0.0"
$ServiceName = "VIEServer"
$AppDir = Join-Path $InstallRoot "app"
$ServerDir = Join-Path $InstallRoot "server"
$DataDir = Join-Path $InstallRoot "data"
$LogDir = Join-Path $InstallRoot "logs"
$UpdateDir = Join-Path $InstallRoot "updates"
$StatePath = Join-Path $ServerDir "update-state.json"
$ConfigPath = Join-Path $ServerDir "update-config.json"
$LogPath = Join-Path $LogDir "mise-a-jour.log"
$TempRoot = Join-Path $env:TEMP ("VIE-update-" + [Guid]::NewGuid().ToString("N"))
$InstallationStarted = $false
$RollbackRoot = ""

function Write-UpdateLog([string]$Message) {
  try {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    Add-Content -Path $LogPath -Encoding UTF8 -Value "[$((Get-Date).ToString('s'))] UPDATE $Message"
  } catch {}
}

function Show-Message([string]$Text,[bool]$Error=$false) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $icon = if ($Error) { [System.Windows.Forms.MessageBoxIcon]::Error } else { [System.Windows.Forms.MessageBoxIcon]::Information }
    [System.Windows.Forms.MessageBox]::Show($Text,"Ma Vie — mise à jour",[System.Windows.Forms.MessageBoxButtons]::OK,$icon) | Out-Null
  } catch { Write-Host $Text }
}

function Test-Administrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Convert-AppVersion([string]$Value) {
  $clean = ([string]$Value).Trim().TrimStart('v','V') -replace '-.*$',''
  try { return [Version]$clean } catch { throw "Version invalide : $Value" }
}

function Get-LocalVersion {
  $versionFile = Join-Path $AppDir "VERSION.txt"
  if (Test-Path $versionFile) {
    $text = Get-Content $versionFile -Raw
    if ($text -match 'Application Ma Vie\s+([0-9]+\.[0-9]+\.[0-9]+)') { return $Matches[1] }
  }
  $scriptFile = Join-Path $AppDir "script.js"
  if (Test-Path $scriptFile) {
    $text = Get-Content $scriptFile -Raw
    if ($text -match 'APP_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"') { return $Matches[1] }
  }
  throw "Version locale introuvable. Réinstallez Ma Vie depuis un paquet complet."
}

function Copy-Tree([string]$Source,[string]$Destination) {
  if (!(Test-Path $Source)) { return }
  New-Item -ItemType Directory -Path $Destination -Force | Out-Null
  & robocopy.exe $Source $Destination /MIR /R:2 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -gt 7) { throw "Copie de sécurité impossible : $Source -> $Destination (robocopy $LASTEXITCODE)" }
}

function Save-UpdateState([string]$Version,[string]$Result) {
  try {
    $state = if (Test-Path $StatePath) { Get-Content $StatePath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
    $state | Add-Member -NotePropertyName installedVersion -NotePropertyValue $Version -Force
    $state | Add-Member -NotePropertyName lastResult -NotePropertyValue $Result -Force
    $state | Add-Member -NotePropertyName lastUpdatedAt -NotePropertyValue ((Get-Date).ToUniversalTime().ToString("o")) -Force
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText($StatePath,($state | ConvertTo-Json -Depth 8),$utf8)
  } catch { Write-UpdateLog "État final non enregistré : $($_.Exception.Message)" }
}

function Request-CoherentBackup {
  $serverConfigPath = Join-Path $ServerDir "config.json"
  if (!(Test-Path $serverConfigPath)) { throw "Configuration du serveur absente ; mise à jour automatique refusée." }
  $serverConfig = Get-Content $serverConfigPath -Raw | ConvertFrom-Json
  $port = ($serverConfig.listen -split ':')[-1]
  $scheme = if (($serverConfig.PSObject.Properties.Name -contains "tlsEnabled") -and $serverConfig.tlsEnabled) { "https" } else { "http" }
  try {
    if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
      Start-Service -Name $ServiceName -ErrorAction SilentlyContinue
      Start-Sleep -Seconds 2
    }
    $body = @{profileId="profile-main";reason="avant mise à jour GitHub de VIE"} | ConvertTo-Json
    $result = Invoke-RestMethod -Method Post -Uri "${scheme}://127.0.0.1:$port/api/v1/backups" -Headers @{"X-VIE-Admin-Token"=$serverConfig.adminToken} -ContentType "application/json" -Body $body -TimeoutSec 120
    if (!$result.ok) { throw "Le serveur n’a pas confirmé la sauvegarde." }
    Write-UpdateLog "Sauvegarde cohérente créée : $($result.backup.filename)"
  } catch {
    throw "La sauvegarde cohérente obligatoire a échoué. Mise à jour annulée sans modifier l’installation : $($_.Exception.Message)"
  }
}

function New-RollbackSnapshot([string]$CurrentVersion) {
  $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
  $root = Join-Path $UpdateDir ("rollback-$CurrentVersion-$stamp")
  New-Item -ItemType Directory -Path $root -Force | Out-Null
  if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    Start-Sleep -Milliseconds 800
  }
  Copy-Tree $AppDir (Join-Path $root "app")
  Copy-Tree $ServerDir (Join-Path $root "server")
  $dbBackup = Join-Path $root "data"
  New-Item -ItemType Directory -Path $dbBackup -Force | Out-Null
  Get-ChildItem -Path $DataDir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "vie.db*" } | ForEach-Object { Copy-Item $_.FullName (Join-Path $dbBackup $_.Name) -Force }
  Set-Content -Path (Join-Path $root "ROLLBACK.txt") -Encoding UTF8 -Value "Ma Vie $CurrentVersion`r`nCréé le $((Get-Date).ToString('o'))`r`nLes pièces jointes restent dans C:\VIE\data\attachments."
  Write-UpdateLog "Point de retour créé : $root"
  return $root
}

function Restore-Rollback([string]$Root) {
  if (!(Test-Path $Root)) { throw "Point de retour introuvable : $Root" }
  try { Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue } catch {}
  Start-Sleep -Milliseconds 500
  Copy-Tree (Join-Path $Root "app") $AppDir
  Copy-Tree (Join-Path $Root "server") $ServerDir
  Get-ChildItem -Path (Join-Path $Root "data") -File -ErrorAction SilentlyContinue | ForEach-Object { Copy-Item $_.FullName (Join-Path $DataDir $_.Name) -Force }
  try { Start-Service -Name $ServiceName -ErrorAction SilentlyContinue } catch {}
  $manager=Join-Path $ServerDir "vie-manager.ps1"
  if(Test-Path $manager){Start-Process powershell.exe -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$manager`" -InstallRoot `"$InstallRoot`"" -WindowStyle Hidden}
  Write-UpdateLog "Retour arrière appliqué depuis $Root"
}

function Test-SafeZip([string]$Path) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $archive = [IO.Compression.ZipFile]::OpenRead($Path)
  try {
    if ($archive.Entries.Count -gt 2000) { throw "Archive refusée : trop de fichiers." }
    [Int64]$total = 0
    foreach ($entry in $archive.Entries) {
      $name = [string]$entry.FullName
      $segments = $name.Replace('\','/').Split('/')
      if ([IO.Path]::IsPathRooted($name) -or $name.Contains(':') -or $segments -contains '..') { throw "Chemin dangereux dans l’archive : $name" }
      $total += [Int64]$entry.Length
      if ($total -gt 536870912) { throw "Archive refusée : taille décompressée supérieure à 512 Mo." }
    }
  } finally { $archive.Dispose() }
}

if (!(Test-Administrator)) {
  $args = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  if ($ExpectedVersion) { $args += " -ExpectedVersion `"$ExpectedVersion`"" }
  $process = Start-Process powershell.exe -Verb RunAs -ArgumentList $args -PassThru -Wait
  exit $process.ExitCode
}

try {
  if ($Repository -ne "Cyrakovsky/ma-vie") { throw "Dépôt non autorisé : $Repository" }
  if (!(Test-Path $AppDir) -or !(Test-Path $ServerDir)) { throw "Ma Vie doit d’abord être installée dans $InstallRoot." }
  $config = if (Test-Path $ConfigPath) { Get-Content $ConfigPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{manifestAsset="ma-vie-update.json";packageAsset="ma-vie.zip";keepRollbackVersions=3} }
  $apiUrl = "https://api.github.com/repos/$Repository/releases/latest"
  $headers = @{"Accept"="application/vnd.github+json";"User-Agent"="Ma-Vie-Updater/$UpdaterVersion";"X-GitHub-Api-Version"="2022-11-28"}
  New-Item -ItemType Directory -Path $TempRoot,$UpdateDir,$LogDir -Force | Out-Null
  try {
    $currentUser=[Security.Principal.WindowsIdentity]::GetCurrent().Name
    & icacls.exe $UpdateDir /inheritance:r /grant:r "${currentUser}:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
  } catch { throw "Le dossier de retour arrière n’a pas pu être protégé : $($_.Exception.Message)" }
  Write-UpdateLog "Démarrage depuis GitHub $Repository."
  $release = Invoke-RestMethod -Uri $apiUrl -Headers $headers -TimeoutSec 30
  if ($release.draft -or $release.prerelease) { throw "Release non stable refusée." }
  $remoteVersion = ([string]$release.tag_name).TrimStart('v','V')
  if ($ExpectedVersion -and $remoteVersion -ne $ExpectedVersion) { throw "La version disponible a changé : attendue $ExpectedVersion, reçue $remoteVersion. Relancez la vérification." }
  $localVersion = Get-LocalVersion
  if ((Convert-AppVersion $remoteVersion) -le (Convert-AppVersion $localVersion)) { throw "Aucune mise à jour montante : version locale $localVersion, version distante $remoteVersion." }
  $manifestAsset = $release.assets | Where-Object { $_.name -eq [string]$config.manifestAsset } | Select-Object -First 1
  $packageAsset = $release.assets | Where-Object { $_.name -eq [string]$config.packageAsset } | Select-Object -First 1
  if (!$manifestAsset -or !$packageAsset) { throw "Release incomplète : manifeste ou ZIP absent." }
  if (([Uri]$manifestAsset.browser_download_url).Host -ne "github.com" -or ([Uri]$packageAsset.browser_download_url).Host -ne "github.com") { throw "Hôte de téléchargement non autorisé." }
  $manifestPath = Join-Path $TempRoot "ma-vie-update.json"
  $zipPath = Join-Path $TempRoot "ma-vie.zip"
  Invoke-WebRequest -UseBasicParsing -Uri ([string]$manifestAsset.browser_download_url) -Headers $headers -OutFile $manifestPath -TimeoutSec 60
  $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
  if ([int]$manifest.schemaVersion -ne 1 -or [string]$manifest.repository -ne $Repository) { throw "Manifeste de mise à jour non autorisé." }
  if ([string]$manifest.version -ne $remoteVersion) { throw "Version du manifeste différente du tag GitHub." }
  if ($manifest.minimumUpdaterVersion -and (Convert-AppVersion $UpdaterVersion) -lt (Convert-AppVersion ([string]$manifest.minimumUpdaterVersion))) { throw "Updater $($manifest.minimumUpdaterVersion) ou supérieur requis." }
  if ([string]$manifest.package.name -ne [string]$config.packageAsset) { throw "Nom de paquet inattendu." }
  $expectedHash = ([string]$manifest.package.sha256).ToLowerInvariant()
  if ($expectedHash -notmatch '^[0-9a-f]{64}$') { throw "SHA-256 du manifeste invalide." }
  Invoke-WebRequest -UseBasicParsing -Uri ([string]$packageAsset.browser_download_url) -Headers $headers -OutFile $zipPath -TimeoutSec 900
  if ([Int64]$manifest.package.size -gt 0 -and (Get-Item $zipPath).Length -ne [Int64]$manifest.package.size) { throw "Taille du ZIP différente du manifeste." }
  $actualHash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualHash -ne $expectedHash) { throw "Échec SHA-256 : le ZIP téléchargé ne correspond pas au manifeste." }
  if ($packageAsset.PSObject.Properties.Name -contains "digest" -and $packageAsset.digest) {
    $githubDigest = ([string]$packageAsset.digest).ToLowerInvariant().Replace("sha256:","")
    if ($githubDigest -match '^[0-9a-f]{64}$' -and $githubDigest -ne $actualHash) { throw "L’empreinte GitHub de l’asset ne correspond pas au ZIP." }
  }
  Test-SafeZip $zipPath
  $extractDir = Join-Path $TempRoot "package"
  Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
  $required = @("COMMENCER-ICI.cmd","index.html","script.js","assets\recurrence-engine.js","assets\react\vie-view-adapters.js","server\installer-vie.ps1","server\vie-server.exe","server\VERSION.txt")
  foreach ($relative in $required) { if (!(Test-Path (Join-Path $extractDir $relative))) { throw "Paquet incomplet : $relative absent." } }
  $newScript = Get-Content (Join-Path $extractDir "script.js") -Raw
  if ($newScript -notmatch 'APP_VERSION\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"' -or $Matches[1] -ne $remoteVersion) { throw "APP_VERSION du paquet incohérente." }
  $newVersionFile = Get-Content (Join-Path $extractDir "server\VERSION.txt") -Raw
  if ($newVersionFile -notmatch "Application Ma Vie\s+$([regex]::Escape($remoteVersion))") { throw "VERSION.txt du paquet incohérent." }
  Write-UpdateLog "ZIP $remoteVersion vérifié : SHA-256 $actualHash."

  Request-CoherentBackup
  $RollbackRoot = New-RollbackSnapshot $localVersion
  $InstallationStarted = $true
  $installer = Join-Path $extractDir "server\installer-vie.ps1"
  $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$installer`" -InstallRoot `"$InstallRoot`" -DepuisMiseAJourGitHub"
  $process = Start-Process powershell.exe -ArgumentList $arguments -PassThru -Wait
  if ($process.ExitCode -ne 0) { throw "L’installateur a retourné le code $($process.ExitCode)." }
  $installedVersion = Get-LocalVersion
  if ($installedVersion -ne $remoteVersion) { throw "Contrôle final impossible : $installedVersion installé au lieu de $remoteVersion." }
  Save-UpdateState $remoteVersion "UPDATED"
  Get-ChildItem $UpdateDir -Directory -Filter "rollback-*" | Sort-Object LastWriteTime -Descending | Select-Object -Skip ([Math]::Max(1,[int]$config.keepRollbackVersions)) | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  Write-UpdateLog "SUCCÈS : Ma Vie $remoteVersion installée. Point de retour : $RollbackRoot"
  Show-Message "Ma Vie a été mise à jour avec succès.`r`n`r`nVersion : $remoteVersion`r`nSauvegarde et point de retour créés.`r`n`r`nAdresse : https://localhost:8080/vie/"
  exit 0
} catch {
  $message = $_.Exception.Message
  Write-UpdateLog "ERREUR : $message`n$($_ | Out-String)"
  if ($InstallationStarted -and $RollbackRoot) {
    try {
      Restore-Rollback $RollbackRoot
      Save-UpdateState (Get-LocalVersion) "ROLLED_BACK"
      $message += "`r`n`r`nL’ancienne version a été restaurée automatiquement."
    } catch {
      $message += "`r`n`r`nLe retour arrière automatique a aussi échoué : $($_.Exception.Message)`r`nUtilisez le dossier $RollbackRoot."
    }
  }
  Show-Message "La mise à jour a été annulée.`r`n`r`n$message`r`n`r`nJournal : $LogPath" $true
  exit 1
} finally {
  try { Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue } catch {}
}
