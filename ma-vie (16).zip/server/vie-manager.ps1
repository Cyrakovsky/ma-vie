﻿param([string]$InstallRoot="C:\VIE")

$ErrorActionPreference="SilentlyContinue"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ConfigPath=Join-Path $InstallRoot "server\config.json"
if(!(Test-Path $ConfigPath)){
  [System.Windows.Forms.MessageBox]::Show("Configuration VIE introuvable : $ConfigPath","Ma Vie") | Out-Null
  exit
}
$config=Get-Content $ConfigPath -Raw | ConvertFrom-Json
$port=($config.listen -split ':')[-1]
$basePath="/"+$config.basePath.Trim('/')+"/"
$tlsActive=($config.PSObject.Properties.Name -contains "tlsEnabled") -and [bool]$config.tlsEnabled
$scheme=if($tlsActive){"https"}else{"http"}
$url="${scheme}://localhost:$port$basePath"
$api="${scheme}://127.0.0.1:$port/api/v1"
$headers=@{"X-VIE-Admin-Token"=$config.adminToken}
$updateConfigPath=Join-Path $InstallRoot "server\update-config.json"
$updateCheckerPath=Join-Path $InstallRoot "server\verifier-mise-a-jour.ps1"

$icon=New-Object System.Windows.Forms.NotifyIcon
$icon.Icon=[System.Drawing.SystemIcons]::Shield
$icon.Text="VIE — vérification du serveur"
$icon.Visible=$true
$menu=New-Object System.Windows.Forms.ContextMenuStrip

function Add-MenuItem([string]$label,[scriptblock]$action){
  $item=New-Object System.Windows.Forms.ToolStripMenuItem
  $item.Text=$label
  $item.add_Click($action)
  [void]$menu.Items.Add($item)
  return $item
}

function Show-Message([string]$text,[string]$title="Ma Vie"){
  $icon.BalloonTipTitle=$title
  $icon.BalloonTipText=$text
  $icon.BalloonTipIcon=[System.Windows.Forms.ToolTipIcon]::Info
  $icon.ShowBalloonTip(3500)
}

function Get-UpdateConfig {
  if (!(Test-Path $updateConfigPath)) { return $null }
  try { return Get-Content $updateConfigPath -Raw | ConvertFrom-Json } catch { return $null }
}

function Save-UpdateConfig($value) {
  $utf8=New-Object System.Text.UTF8Encoding($false)
  [IO.File]::WriteAllText($updateConfigPath,($value|ConvertTo-Json -Depth 8),$utf8)
}

function Refresh-UpdateMenu {
  $value=Get-UpdateConfig
  if ($null -eq $value) {
    $autoUpdateItem.Text="Vérification automatique : indisponible"
    $autoUpdateItem.Enabled=$false
  } else {
    $autoUpdateItem.Enabled=$true
    $autoUpdateItem.Text=if([bool]$value.automaticCheck){"Vérification automatique : activée"}else{"Vérification automatique : désactivée"}
  }
}

function Start-UpdateCheck([bool]$Manual=$false) {
  if (!(Test-Path $updateCheckerPath)) {
    if($Manual){Show-Message "Outil de mise à jour absent. Relancez INSTALLER-VIE.bat depuis le dernier paquet." "VIE — attention"}
    return
  }
  try {
    $running=Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" | Where-Object { $_.CommandLine -like "*verifier-mise-a-jour.ps1*" -and $_.CommandLine -like "*$InstallRoot*" }
    if($running){if($Manual){Show-Message "Une vérification est déjà en cours."};return}
  } catch {}
  $arguments="-NoProfile -ExecutionPolicy Bypass -File `"$updateCheckerPath`" -InstallRoot `"$InstallRoot`""
  if($Manual){$arguments+=" -Force -Interactive"}
  $windowStyle=if($Manual){"Normal"}else{"Hidden"}
  Start-Process powershell.exe -ArgumentList $arguments -WindowStyle $windowStyle
  if($Manual){Show-Message "Vérification GitHub lancée. Aucune installation ne se fera sans confirmation."}
}

function Refresh-Status {
  try {
    $health=Invoke-RestMethod -Uri "$api/health" -Headers $headers -TimeoutSec 3
    $last=if($health.lastBackup){([DateTime]$health.lastBackup).ToLocalTime().ToString("dd/MM HH:mm")}else{"aucune"}
    $transport=if($health.tlsEnabled){$health.tlsVersion}else{"HTTP"}
    $text="VIE actif · $transport · SQLite OK · sauvegarde $last"
    $icon.Text=$text.Substring(0,[Math]::Min(63,$text.Length))
    $statusItem.Text=if($health.tlsEnabled){"🟢 Serveur actif · HTTPS · base OK"}else{"🟠 Serveur actif · HTTPS à vérifier"}
    $backupItem.Text="Dernière sauvegarde : $last"
    $tlsItem.Text=if($health.certificateExpiresAt){"Certificat HTTPS : "+([DateTime]$health.certificateExpiresAt).ToLocalTime().ToString("MM/yyyy")}else{"Certificat HTTPS : à vérifier"}
  } catch {
    $icon.Text="VIE — serveur local indisponible"
    $statusItem.Text="🔴 Serveur indisponible"
    $backupItem.Text="Dernière sauvegarde : inconnue"
    $tlsItem.Text="Certificat HTTPS : à réparer"
  }
}

$openItem=Add-MenuItem "Ouvrir VIE" {Start-Process $url}
$statusItem=Add-MenuItem "État du serveur" {Refresh-Status;Show-Message $icon.Text}
$backupItem=Add-MenuItem "Dernière sauvegarde : vérification…" {Start-Process (Join-Path $InstallRoot "backups")}
$tlsItem=Add-MenuItem "Certificat HTTPS : vérification…" {
  $script=Join-Path $InstallRoot "server\reparer-https.ps1"
  Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$script`" -InstallRoot `"$InstallRoot`""
}
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$folderItem=Add-MenuItem "Ouvrir le dossier VIE" {Start-Process explorer.exe $InstallRoot}
$backupNow=Add-MenuItem "Créer une sauvegarde cohérente" {
  try{
    $body=@{profileId="profile-main";reason="depuis le gestionnaire Windows"}|ConvertTo-Json
    $result=Invoke-RestMethod -Method Post -Uri "$api/backups" -Headers $headers -ContentType "application/json" -Body $body -TimeoutSec 120
    Show-Message "Sauvegarde créée : $($result.backup.filename)"
    Refresh-Status
  }catch{Show-Message "Sauvegarde impossible : $($_.Exception.Message)" "VIE — attention"}
}
$restoreItem=Add-MenuItem "Restaurer une sauvegarde…" {
  $script=Join-Path $InstallRoot "server\restaurer-sauvegarde.ps1"
  Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$script`" -InstallRoot `"$InstallRoot`""
}
$verifyItem=Add-MenuItem "Vérifier les données" {
  try{
    $result=Invoke-RestMethod -Method Post -Uri "$api/verify" -Headers $headers -TimeoutSec 120
    if($result.ok){Show-Message "Base SQLite OK · $($result.filesValid)/$($result.filesChecked) fichier(s) valides"}
    else{Show-Message "Vérification à examiner : $($result.filesValid)/$($result.filesChecked) fichier(s) valides" "VIE — attention"}
  }catch{Show-Message "Vérification impossible" "VIE — attention"}
}
$diagnosticItem=Add-MenuItem "Diagnostiquer une page blanche…" {
  $script=Join-Path $InstallRoot "server\diagnostiquer-vie.ps1"
  if(Test-Path $script){Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$script`" -InstallRoot `"$InstallRoot`""}
  else{Show-Message "Outil de diagnostic absent. Relancez INSTALLER-VIE.bat depuis le dernier paquet." "VIE — attention"}
}
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$updateItem=Add-MenuItem "Vérifier les mises à jour GitHub…" {Start-UpdateCheck $true}
$autoUpdateItem=Add-MenuItem "Vérification automatique : vérification…" {
  $value=Get-UpdateConfig
  if($null -eq $value){Show-Message "Configuration de mise à jour absente." "VIE — attention";return}
  $value.automaticCheck=![bool]$value.automaticCheck
  Save-UpdateConfig $value
  Refresh-UpdateMenu
  $message=if($value.automaticCheck){"Vérification automatique quotidienne activée."}else{"Vérification automatique désactivée. La vérification manuelle reste disponible."}
  Show-Message $message
}
$restartItem=Add-MenuItem "Redémarrer le serveur" {
  try{Restart-Service -Name VIEServer -Force;Start-Sleep -Seconds 2;Refresh-Status;Show-Message "Serveur VIE redémarré"}
  catch{Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -Command `"Restart-Service -Name VIEServer -Force`""}
}
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$quitItem=Add-MenuItem "Quitter le gestionnaire" {$icon.Visible=$false;$timer.Stop();$updateTimer.Stop();$updateStartupTimer.Stop();[System.Windows.Forms.Application]::Exit()}

$icon.ContextMenuStrip=$menu
$icon.add_DoubleClick({Start-Process $url})
$timer=New-Object System.Windows.Forms.Timer
$timer.Interval=30000
$timer.add_Tick({Refresh-Status})
$timer.Start()
$updateTimer=New-Object System.Windows.Forms.Timer
$updateTimer.Interval=3600000
$updateTimer.add_Tick({Start-UpdateCheck $false})
$updateTimer.Start()
$updateStartupTimer=New-Object System.Windows.Forms.Timer
$updateStartupTimer.Interval=15000
$updateStartupTimer.add_Tick({$updateStartupTimer.Stop();Start-UpdateCheck $false})
$updateStartupTimer.Start()
Refresh-Status
Refresh-UpdateMenu
[System.Windows.Forms.Application]::Run()
$icon.Dispose()
