@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Ma Vie - aide, installation et diagnostic
cd /d "%~dp0"

:MENU
cls
echo ============================================================
echo   MA VIE - FENETRE D'AIDE QUI RESTE OUVERTE
echo ============================================================
echo.
echo Ne lancez pas vie-server.exe ou les fichiers .ps1 directement.
echo Choisissez une action ci-dessous.
echo.
echo   [1] Installer ou mettre a jour Ma Vie
echo   [2] Diagnostiquer la page blanche / le serveur
echo   [3] Demarrer le serveur manuellement et voir les erreurs
echo   [4] Ouvrir VIE dans le navigateur
echo   [5] Ouvrir le journal de l'installateur
echo   [6] Ouvrir les journaux C:\VIE\logs
echo   [7] Verifier les mises a jour GitHub
echo   [Q] Quitter
echo.
choice /C 1234567Q /N /M "Votre choix : "

if errorlevel 8 goto FIN
if errorlevel 7 goto UPDATE
if errorlevel 6 goto LOGS
if errorlevel 5 goto INSTALLLOG
if errorlevel 4 goto OPENVIE
if errorlevel 3 goto MANUAL
if errorlevel 2 goto DIAGNOSTIC
if errorlevel 1 goto INSTALL

goto MENU

:INSTALL
cls
echo Installation ou mise a jour de Ma Vie...
echo Les donnees C:\VIE\data et les sauvegardes seront conservees.
echo.
if exist "%~dp0INSTALLER-VIE.bat" (
  call "%~dp0INSTALLER-VIE.bat"
) else (
  echo ERREUR : INSTALLER-VIE.bat est absent de ce paquet.
)
echo.
pause
goto MENU

:DIAGNOSTIC
cls
echo Diagnostic de Ma Vie...
echo.
if exist "C:\VIE\server\DIAGNOSTIC-VIE.bat" goto DIAG_INSTALLED
if exist "%~dp0DIAGNOSTIC-VIE.bat" goto DIAG_PACKAGE
echo ERREUR : aucun outil de diagnostic n'est disponible.
echo Extrayez completement le dernier paquet Ma Vie.
goto DIAG_END

:DIAG_INSTALLED
call "C:\VIE\server\DIAGNOSTIC-VIE.bat"
goto DIAG_END

:DIAG_PACKAGE
call "%~dp0DIAGNOSTIC-VIE.bat"

:DIAG_END
echo.
pause
goto MENU

:MANUAL
cls
echo Demarrage manuel du serveur VIE.
echo Cette console affichera l'erreur exacte et restera ouverte.
echo Utilisez Ctrl+C pour arreter le serveur et revenir au menu.
echo.
if not exist "C:\VIE\server\vie-server.exe" (
  echo ERREUR : C:\VIE\server\vie-server.exe est introuvable.
  pause
  goto MENU
)
if not exist "C:\VIE\server\config.json" (
  echo ERREUR : C:\VIE\server\config.json est introuvable.
  pause
  goto MENU
)
sc query VIEServer | find "RUNNING" >nul
if not errorlevel 1 (
  echo Le service VIEServer est deja demarre.
  echo Utilisez l'option 4 pour ouvrir VIE ou l'option 2 pour diagnostiquer.
  pause
  goto MENU
)
cd /d "C:\VIE\server"
"C:\VIE\server\vie-server.exe" serve --config "C:\VIE\server\config.json"
echo.
echo Le serveur s'est arrete avec le code %ERRORLEVEL%.
pause
cd /d "%~dp0"
goto MENU

:OPENVIE
start "" "https://localhost:8080/vie/?aide=1"
goto MENU

:INSTALLLOG
if exist "%TEMP%\Ma-Vie-installation.log" (
  start "" notepad.exe "%TEMP%\Ma-Vie-installation.log"
) else (
  echo Le journal %TEMP%\Ma-Vie-installation.log n'existe pas encore.
  pause
)
goto MENU

:LOGS
if exist "C:\VIE\logs" (
  start "" explorer.exe "C:\VIE\logs"
) else (
  echo Le dossier C:\VIE\logs n'existe pas encore.
  pause
)
goto MENU

:UPDATE
cls
echo Verification des mises a jour GitHub...
echo Aucune installation ne sera lancee sans votre confirmation.
echo.
if exist "%~dp0METTRE-A-JOUR-VIE.bat" (
  call "%~dp0METTRE-A-JOUR-VIE.bat"
) else if exist "C:\VIE\server\METTRE-A-JOUR-VIE.bat" (
  call "C:\VIE\server\METTRE-A-JOUR-VIE.bat"
) else (
  echo ERREUR : l'outil de mise a jour est absent.
  echo Reinstallez Ma Vie depuis un paquet complet.
  pause
)
goto MENU

:FIN
echo.
echo Fermeture demandee par l'utilisateur.
timeout /t 2 /nobreak >nul
endlocal
exit /b 0
