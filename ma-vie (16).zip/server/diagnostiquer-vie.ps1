﻿param([string]$InstallRoot="C:\VIE",[switch]$NePasOuvrir)

$ErrorActionPreference="Continue"
$ServerDir=Join-Path $InstallRoot "server"
$ConfigPath=Join-Path $ServerDir "config.json"
$LogDir=Join-Path $InstallRoot "logs"
New-Item -ItemType Directory -Path $LogDir -Force|Out-Null
$timestamp=Get-Date -Format "yyyyMMdd-HHmmss"
$ReportPath=Join-Path $LogDir "diagnostic-client-$timestamp.txt"
$checks=New-Object System.Collections.Generic.List[object]

function Add-Check([string]$Name,[bool]$OK,[string]$Detail){
  $checks.Add([pscustomobject]@{Name=$Name;OK=$OK;Detail=$Detail})
}

Add-Check "Dossier d’installation" (Test-Path $InstallRoot) $InstallRoot
Add-Check "Configuration" (Test-Path $ConfigPath) $ConfigPath

$config=$null
if(Test-Path $ConfigPath){
  try{$config=Get-Content $ConfigPath -Raw|ConvertFrom-Json;Add-Check "JSON de configuration" $true "Lisible"}
  catch{Add-Check "JSON de configuration" $false $_.Exception.Message}
}

$service=Get-Service -Name VIEServer -ErrorAction SilentlyContinue
$serviceDetail=if($service){[string]$service.Status}else{"Absent"}
Add-Check "Service Windows VIEServer" ($null-ne $service) $serviceDetail
if($service){Add-Check "Service démarré" ($service.Status -eq "Running") ([string]$service.Status)}

$AppDir=Join-Path $InstallRoot "app"
if($config -and $config.appDir){
  $AppDir=if([IO.Path]::IsPathRooted([string]$config.appDir)){[IO.Path]::GetFullPath([string]$config.appDir)}else{[IO.Path]::GetFullPath((Join-Path $ServerDir ([string]$config.appDir)))}
}
$required=@("index.html","styles.css","views.js","script.js","server-adapter.js","assets\recurrence-engine.js","assets\react\vie-view-adapters.js","assets\react\vie-react-bridge.js","assets\react\vie-react.css")
foreach($relative in $required){
  $path=Join-Path $AppDir $relative
  $exists=Test-Path $path
  $detail=if($exists){"$path · $((Get-Item $path).Length) octets"}else{"MANQUANT : $path"}
  Add-Check "Fichier $relative" $exists $detail
}

$indexPath=Join-Path $AppDir "index.html"
if(Test-Path $indexPath){
  $index=Get-Content $indexPath -Raw
  $engineReferenceDetail=if($index -match "assets/recurrence-engine\.js"){"Référence correcte"}else{"index.html pointe vers un ancien emplacement"}
  Add-Check "Référence moteur de récurrence" ($index -match "assets/recurrence-engine\.js") $engineReferenceDetail
}

$url="https://localhost:8080/vie/"
$api="https://127.0.0.1:8080/api/v1"
$headers=@{}
if($config){
  $port=([string]$config.listen -split ':')[-1]
  $basePath="/"+([string]$config.basePath).Trim('/')+"/"
  $scheme=if($config.tlsEnabled){"https"}else{"http"}
  $url="${scheme}://localhost:$port$basePath"
  $api="${scheme}://127.0.0.1:$port/api/v1"
  $headers=@{"X-VIE-Admin-Token"=[string]$config.adminToken}
}

if($config){
  try{$health=Invoke-RestMethod -Uri "$api/health" -Headers $headers -TimeoutSec 5;Add-Check "API /health" ([bool]$health.ok) ("Version "+$health.version+" · TLS "+$health.tlsVersion)}
  catch{Add-Check "API /health" $false $_.Exception.Message}
}

$cache=[DateTimeOffset]::Now.ToUnixTimeSeconds()
foreach($relative in @("index.html","assets/recurrence-engine.js","views.js","script.js","assets/react/vie-view-adapters.js","assets/react/vie-react-bridge.js")){
  try{
    $response=Invoke-WebRequest -UseBasicParsing -Uri "${url}${relative}?diagnostic=$cache" -TimeoutSec 8
    $ok=$response.StatusCode -eq 200 -and $response.RawContentLength -gt 0
    Add-Check "HTTPS $relative" $ok ("HTTP "+$response.StatusCode+" · "+$response.RawContentLength+" octets")
  }catch{Add-Check "HTTPS $relative" $false $_.Exception.Message}
}

$failed=@($checks|Where-Object{-not $_.OK})
$lines=@(
  "DIAGNOSTIC CLIENT MA VIE",
  "Date : $((Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))",
  "Installation : $InstallRoot",
  "Adresse : $url",
  "",
  "CONTRÔLES"
)
$lines+= $checks|ForEach-Object{"[$(if($_.OK){'OK'}else{'ERREUR'})] $($_.Name) — $($_.Detail)"}
$lines+=""
$lines+="ERREURS : $($failed.Count)"
if($failed.Count){
  $lines+=""
  $lines+="ACTIONS CONSEILLÉES"
  $lines+="1. Extraire complètement le dernier ma-vie.zip."
  $lines+="2. Relancer server\INSTALLER-VIE.bat en acceptant l’autorisation administrateur."
  $lines+="3. Exécuter reparer-https.ps1 si les contrôles HTTPS échouent."
  $lines+="4. Actualiser le navigateur avec Ctrl+F5."
}
$lines|Set-Content -Path $ReportPath -Encoding UTF8

try{
  Add-Type -AssemblyName System.Windows.Forms
  if($failed.Count){
    [System.Windows.Forms.MessageBox]::Show("Le diagnostic a détecté $($failed.Count) erreur(s).`r`n`r`nRapport : $ReportPath`r`n`r`nRelancez INSTALLER-VIE.bat depuis le dernier paquet.","Ma Vie — diagnostic",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)|Out-Null
  }else{
    [System.Windows.Forms.MessageBox]::Show("Tous les fichiers et le serveur VIE sont accessibles.`r`n`r`nLe navigateur va être rouvert sans ancien cache.","Ma Vie — diagnostic",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)|Out-Null
  }
}catch{}

Write-Host ($lines -join [Environment]::NewLine)
Write-Host ""
Write-Host "Rapport : $ReportPath"
if($failed.Count){Start-Process notepad.exe -ArgumentList "`"$ReportPath`""}
elseif(!$NePasOuvrir){Start-Process "${url}?diagnostic=$cache"}
exit $failed.Count
