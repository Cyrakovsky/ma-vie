﻿param(
  [string]$InstallRoot = "C:\VIE",
  [switch]$SansService,
  [switch]$DepuisMiseAJourGitHub
)

$ErrorActionPreference = "Stop"
$ServiceName = "VIEServer"
$BundleRoot = Split-Path -Parent $PSScriptRoot
$SourceExe = Join-Path $PSScriptRoot "vie-server.exe"
$InstallLog = Join-Path $env:TEMP "Ma-Vie-installation.log"
$InstallStartedAt = Get-Date
try { Set-Content -Path $InstallLog -Encoding UTF8 -Value "[$($InstallStartedAt.ToString('s'))] Démarrage installation/mise à jour Ma Vie depuis $BundleRoot" } catch {}

function Write-InstallLog([string]$Message) {
  try { Add-Content -Path $InstallLog -Encoding UTF8 -Value "[$((Get-Date).ToString('s'))] $Message" } catch {}
}

trap {
  $message = $_.Exception.Message
  Write-InstallLog "ERREUR : $message`n$($_ | Out-String)"
  Write-Host ""
  Write-Host "ÉCHEC DE L’INSTALLATION : $message" -ForegroundColor Red
  Write-Host "Journal : $InstallLog" -ForegroundColor Yellow
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("La mise à jour de Ma Vie a échoué.`r`n`r`n$message`r`n`r`nJournal : $InstallLog","Ma Vie — erreur",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
  } catch {}
  exit 1
}

function Test-Administrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function New-Shortcut([string]$Path,[string]$Target,[string]$Arguments,[string]$WorkingDirectory,[int]$WindowStyle=1) {
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut($Path)
  $shortcut.TargetPath = $Target
  $shortcut.Arguments = $Arguments
  $shortcut.WorkingDirectory = $WorkingDirectory
  $shortcut.WindowStyle = $WindowStyle
  $shortcut.Save()
}

function Resolve-ConfigPath([string]$Base,[string]$Value) {
  if ([IO.Path]::IsPathRooted($Value)) { return [IO.Path]::GetFullPath($Value) }
  return [IO.Path]::GetFullPath((Join-Path $Base $Value))
}

function Add-ConfigProperty($Object,[string]$Name,$Value) {
  if (!($Object.PSObject.Properties.Name -contains $Name)) {
    $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
    return $true
  }
  return $false
}

if (!(Test-Path $SourceExe)) {
  throw "vie-server.exe est introuvable dans $PSScriptRoot"
}
$BundleRequirements = @(
  "index.html","styles.css","views.js","script.js","server-adapter.js",
  "assets\recurrence-engine.js","assets\react\vie-react-bridge.js","assets\react\vie-view-adapters.js","assets\react\vie-react.css"
)
foreach ($relativePath in $BundleRequirements) {
  $requiredPath = Join-Path $BundleRoot $relativePath
  if (!(Test-Path $requiredPath)) { throw "Paquet Ma Vie incomplet : $relativePath est introuvable. Extrayez complètement ma-vie.zip avant la mise à jour." }
}
Write-InstallLog "Paquet source complet vérifié."

if (!(Test-Administrator) -and !$SansService) {
  Write-Host "VIE demande une autorisation administrateur pour installer le service et l’autorité HTTPS locale." -ForegroundColor Yellow
  $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  if ($SansService) { $arguments += " -SansService" }
  if ($DepuisMiseAJourGitHub) { $arguments += " -DepuisMiseAJourGitHub" }
  $elevated=Start-Process powershell.exe -Verb RunAs -ArgumentList $arguments -PassThru -Wait
  exit $elevated.ExitCode
}

$AppDir = Join-Path $InstallRoot "app"
$DataDir = Join-Path $InstallRoot "data"
$AttachmentDir = Join-Path $DataDir "attachments"
$BackupDir = Join-Path $InstallRoot "backups"
$LogDir = Join-Path $InstallRoot "logs"
$ServerDir = Join-Path $InstallRoot "server"
$TLSDir = Join-Path $ServerDir "tls"

$IsUpdate = Test-Path (Join-Path $ServerDir "config.json")
$OperationLabel = if ($IsUpdate) { "Mise à jour sécurisée" } else { "Installation sécurisée" }
Write-Host "$OperationLabel de Ma Vie dans $InstallRoot" -ForegroundColor Cyan
Write-InstallLog "$OperationLabel dans $InstallRoot."
foreach ($directory in @($InstallRoot,$AppDir,$DataDir,$AttachmentDir,$BackupDir,$LogDir,$ServerDir,$TLSDir)) {
  New-Item -ItemType Directory -Path $directory -Force | Out-Null
}

# Si une version existe, demander d’abord au serveur actif de produire une sauvegarde cohérente.
$ExistingConfigPath = Join-Path $ServerDir "config.json"
if (Test-Path $ExistingConfigPath) {
  try {
    $existing = Get-Content $ExistingConfigPath -Raw | ConvertFrom-Json
    $port = ($existing.listen -split ':')[-1]
    $scheme = if (($existing.PSObject.Properties.Name -contains "tlsEnabled") -and $existing.tlsEnabled) { "https" } else { "http" }
    $headers = @{"X-VIE-Admin-Token"=$existing.adminToken}
    $body = @{profileId="profile-main";reason="avant mise à jour de VIE"} | ConvertTo-Json
    Invoke-RestMethod -Method Post -Uri "${scheme}://127.0.0.1:$port/api/v1/backups" -Headers $headers -ContentType "application/json" -Body $body -TimeoutSec 120 | Out-Null
    Write-Host "Sauvegarde cohérente créée avant la mise à jour." -ForegroundColor Green
  } catch {
    Write-Warning "Le serveur actif n’a pas pu créer sa sauvegarde. L’installation n’efface toutefois jamais data ni backups."
  }
}

# Fermer l’ancien gestionnaire de zone de notification afin d’éviter les icônes fantômes.
try {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" | Where-Object {
    $_.CommandLine -like "*vie-manager.ps1*" -and $_.CommandLine -like "*$InstallRoot*"
  } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Write-InstallLog "Ancien gestionnaire VIE fermé."
} catch { Write-InstallLog "Gestionnaire précédent non détecté ou déjà fermé." }

if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
  Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 800
}

$AppFiles = @("index.html","styles.css","views.js","script.js","server-adapter.js")
foreach ($file in $AppFiles) {
  $source = Join-Path $BundleRoot $file
  if (!(Test-Path $source)) { throw "Fichier applicatif manquant : $source" }
  Copy-Item $source (Join-Path $AppDir $file) -Force
}
$AppAssets=Join-Path $AppDir "assets"
New-Item -ItemType Directory -Path $AppAssets -Force|Out-Null
Copy-Item (Join-Path $BundleRoot "assets\*") $AppAssets -Recurse -Force
foreach ($relativePath in $BundleRequirements) {
  $installedPath = Join-Path $AppDir $relativePath
  if (!(Test-Path $installedPath)) { throw "Copie applicative incomplète : $relativePath n’a pas été installé dans $AppDir" }
}
$installedIndex = Get-Content (Join-Path $AppDir "index.html") -Raw
if ($installedIndex -notmatch "assets/recurrence-engine\.js") { throw "index.html ne référence pas le moteur de récurrence livré dans assets." }
if (Test-Path (Join-Path $PSScriptRoot "VERSION.txt")) { Copy-Item (Join-Path $PSScriptRoot "VERSION.txt") (Join-Path $AppDir "VERSION.txt") -Force }
Write-InstallLog "Application et dépendances JavaScript copiées et vérifiées."
Copy-Item $SourceExe (Join-Path $ServerDir "vie-server.exe") -Force
foreach ($runtimeScript in @("vie-manager.ps1","demarrer-vie.bat","AIDE-VIE-NE-SE-FERME-PAS.cmd","DIAGNOSTIC-VIE.bat","diagnostiquer-vie.ps1","installer-service.ps1","desinstaller-service.ps1","restaurer-sauvegarde.ps1","reparer-https.ps1","verifier-mise-a-jour.ps1","mettre-a-jour-vie.ps1","METTRE-A-JOUR-VIE.bat","VERSION.txt")) {
  $runtimeSource = Join-Path $PSScriptRoot $runtimeScript
  if (!(Test-Path $runtimeSource)) { throw "Fichier serveur obligatoire absent : $runtimeScript" }
  Copy-Item $runtimeSource (Join-Path $ServerDir $runtimeScript) -Force
}
$SourceUpdateConfig = Join-Path $PSScriptRoot "update-config.json"
$InstalledUpdateConfig = Join-Path $ServerDir "update-config.json"
if (!(Test-Path $SourceUpdateConfig)) { throw "Configuration GitHub absente : update-config.json" }
$defaultsUpdate = Get-Content $SourceUpdateConfig -Raw | ConvertFrom-Json
if (Test-Path $InstalledUpdateConfig) {
  $currentUpdate = Get-Content $InstalledUpdateConfig -Raw | ConvertFrom-Json
  $automaticCheck = if ($currentUpdate.PSObject.Properties.Name -contains "automaticCheck") { [bool]$currentUpdate.automaticCheck } else { [bool]$defaultsUpdate.automaticCheck }
  $checkIntervalHours = if ($currentUpdate.PSObject.Properties.Name -contains "checkIntervalHours") { [Math]::Max(1,[int]$currentUpdate.checkIntervalHours) } else { [int]$defaultsUpdate.checkIntervalHours }
  $defaultsUpdate.automaticCheck = $automaticCheck
  $defaultsUpdate.checkIntervalHours = $checkIntervalHours
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText($InstalledUpdateConfig,($defaultsUpdate | ConvertTo-Json -Depth 8),$utf8NoBom)
Write-InstallLog "Updater GitHub installé pour Cyrakovsky/ma-vie ; préférence de vérification automatique conservée."

$ConfigPath = Join-Path $ServerDir "config.json"
if (!(Test-Path $ConfigPath)) {
  $bytes = New-Object byte[] 32
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $token = -join ($bytes | ForEach-Object { $_.ToString("x2") })
  $config = [ordered]@{
    listen = "127.0.0.1:8080"
    basePath = "/vie/"
    appDir = "../app"
    dataDir = "../data"
    backupDir = "../backups"
    logDir = "../logs"
    openBrowser = $false
    autoBackup = $true
    backupTime = "06:30"
    retentionDays = 180
    maxBackups = 30
    maxRequestMB = 128
    adminToken = $token
    tlsEnabled = $true
    tlsCertFile = "./tls/server-cert.pem"
    tlsKeyFile = "./tls/server-key.pem"
    tlsCAFile = "./tls/vie-local-ca.cer"
  }
  $configJson = $config | ConvertTo-Json
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [IO.File]::WriteAllText($ConfigPath,$configJson,$utf8NoBom)
} else {
  $config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
  $changed = $false
  $changed = (Add-ConfigProperty $config "appDir" "../app") -or $changed
  if ([string]$config.appDir -ne "../app") { $config.appDir = "../app"; $changed = $true; Write-InstallLog "appDir normalisé vers C:\VIE\app." }
  $changed = (Add-ConfigProperty $config "basePath" "/vie/") -or $changed
  $changed = (Add-ConfigProperty $config "tlsEnabled" $true) -or $changed
  if (!$config.tlsEnabled) { $config.tlsEnabled = $true; $changed = $true }
  $changed = (Add-ConfigProperty $config "tlsCertFile" "./tls/server-cert.pem") -or $changed
  $changed = (Add-ConfigProperty $config "tlsKeyFile" "./tls/server-key.pem") -or $changed
  $changed = (Add-ConfigProperty $config "tlsCAFile" "./tls/vie-local-ca.cer") -or $changed
  if ($changed) {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText($ConfigPath,($config | ConvertTo-Json -Depth 8),$utf8NoBom)
    Write-Host "Ancienne configuration migrée vers HTTPS local." -ForegroundColor Cyan
  }
}
$config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$TLSActive = [bool]$config.tlsEnabled
$Scheme = if ($TLSActive) { "https" } else { "http" }
$Port = ($config.listen -split ':')[-1]
$BasePath = "/" + $config.basePath.Trim('/') + "/"
$PublicURL = "${Scheme}://localhost:$Port$BasePath"
$APIURL = "${Scheme}://127.0.0.1:$Port/api/v1"
$InstalledExe = Join-Path $ServerDir "vie-server.exe"

if ($TLSActive) {
  Write-Host "Préparation du certificat HTTPS local VIE…" -ForegroundColor Cyan
  & $InstalledExe init-tls --config $ConfigPath
  if ($LASTEXITCODE -ne 0) { throw "Le certificat HTTPS local n’a pas pu être généré." }
  $CAFile = Resolve-ConfigPath $ServerDir ([string]$config.tlsCAFile)
  if (!(Test-Path $CAFile)) { throw "Autorité locale VIE introuvable : $CAFile" }
  $certificate = New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $CAFile
  $storePath = if (Test-Administrator) { "Cert:\LocalMachine\Root" } else { "Cert:\CurrentUser\Root" }
  if (!(Get-ChildItem $storePath | Where-Object {$_.Thumbprint -eq $certificate.Thumbprint})) {
    Write-Host "Installation explicite de l’autorité VIE dans le magasin de confiance Windows ($storePath)." -ForegroundColor Yellow
    Import-Certificate -FilePath $CAFile -CertStoreLocation $storePath | Out-Null
  }
  Write-Host "Autorité HTTPS approuvée · empreinte $($certificate.Thumbprint)" -ForegroundColor Green
}

# Réduire l’accès aux données, sauvegardes, configuration et clé privée TLS.
try {
  $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name
  & icacls.exe $DataDir /inheritance:r /grant:r "${currentUser}:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
  & icacls.exe $BackupDir /inheritance:r /grant:r "${currentUser}:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
  & icacls.exe $ServerDir /inheritance:r /grant:r "${currentUser}:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
} catch { Write-Warning "Les droits NTFS devront être vérifiés manuellement." }

if (!$SansService) {
  if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    & $InstalledExe uninstall-service --config $ConfigPath | Out-Null
    Start-Sleep -Milliseconds 500
  }
  & $InstalledExe install-service --config $ConfigPath
  if ($LASTEXITCODE -ne 0) { throw "Le service Windows VIE n’a pas pu être installé." }
  & sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/15000/""/0 | Out-Null
  & sc.exe failureflag $ServiceName 1 | Out-Null
} else {
  $startup = [Environment]::GetFolderPath("Startup")
  New-Shortcut (Join-Path $startup "VIE Server.lnk") $InstalledExe "serve --config `"$ConfigPath`"" $ServerDir 7
  Start-Process $InstalledExe -ArgumentList "serve --config `"$ConfigPath`"" -WorkingDirectory $ServerDir -WindowStyle Hidden
}

$startupFolder = [Environment]::GetFolderPath("Startup")
$managerArgs = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $ServerDir 'vie-manager.ps1')`" -InstallRoot `"$InstallRoot`""
New-Shortcut (Join-Path $startupFolder "VIE Gestionnaire.lnk") "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" $managerArgs $ServerDir 7

$desktop = [Environment]::GetFolderPath("Desktop")
New-Shortcut (Join-Path $desktop "Ma Vie.lnk") "$env:SystemRoot\System32\cmd.exe" "/c start `"`" $PublicURL" $InstallRoot 7

Start-Sleep -Seconds 2
$healthOK = $false
for ($attempt=0; $attempt -lt 15; $attempt++) {
  try {
    $health = Invoke-RestMethod -Uri "$APIURL/health" -Headers @{"X-VIE-Admin-Token"=$config.adminToken} -TimeoutSec 3
    if ($health.ok -and (!$TLSActive -or $health.tlsEnabled)) { $healthOK = $true; break }
  } catch { Start-Sleep -Milliseconds 500 }
}
if (!$healthOK) { throw "Le service VIE ne répond pas correctement après installation. Lancez DIAGNOSTIC-VIE.bat et consultez $InstallLog." }
Write-InstallLog "Contrôle API réussi."

$CacheToken = [DateTimeOffset]::Now.ToUnixTimeSeconds()
$StaticChecks = @("index.html","assets/recurrence-engine.js","views.js","script.js","assets/react/vie-view-adapters.js","assets/react/vie-react-bridge.js")
foreach ($relativeURL in $StaticChecks) {
  try {
    $response = Invoke-WebRequest -UseBasicParsing -Uri "${PublicURL}${relativeURL}?v=$CacheToken" -TimeoutSec 10
    if ($response.StatusCode -ne 200 -or $response.RawContentLength -le 0) { throw "réponse vide ou statut $($response.StatusCode)" }
  } catch { throw "Ressource applicative inaccessible : $relativeURL — $($_.Exception.Message)" }
}
Write-InstallLog "Toutes les ressources de démarrage sont accessibles en HTTPS."

Start-Process powershell.exe -ArgumentList $managerArgs -WindowStyle Hidden
$LaunchURL = "${PublicURL}?mise-a-jour=$CacheToken"
Start-Process $LaunchURL

$TransportLabel=if($TLSActive){"HTTPS/TLS local"}else{"HTTP local explicitement configuré"}
Write-Host ""
Write-Host "Ma Vie est installée." -ForegroundColor Green
Write-Host "Adresse : $PublicURL"
Write-Host "Transport : $TransportLabel"
Write-Host "Base    : $DataDir\vie.db"
Write-Host "Le dossier data et les sauvegardes existants ont été conservés."
Write-Host "Diagnostic : $ServerDir\DIAGNOSTIC-VIE.bat"
Write-Host "Journal    : $InstallLog"
Write-InstallLog "SUCCÈS — $OperationLabel terminée. URL : $PublicURL. Données et sauvegardes conservées."
if (!$DepuisMiseAJourGitHub) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $successText = if ($IsUpdate) { "Ma Vie a été mise à jour avec succès." } else { "Ma Vie a été installée avec succès." }
    [System.Windows.Forms.MessageBox]::Show("$successText`r`n`r`nAdresse : $PublicURL`r`nLes données et sauvegardes existantes ont été conservées.`r`n`r`nSi une ancienne page blanche est encore ouverte, utilisez Ctrl+F5.","Ma Vie",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
  } catch {}
}
