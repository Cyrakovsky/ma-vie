# VIE Server — HTTPS local, SQLite et continuité

VIE Server est le mode principal recommandé de **Ma Vie — Assistant personnel VIE**. Il ajoute HTTPS/TLS, SQLite, les pièces jointes chiffrées, les sauvegardes cohérentes et le démarrage automatique Windows. Le mode `file://` reste disponible comme secours autonome.

## Adresse principale

```text
https://localhost:8080/vie/
```

`localhost` désigne uniquement cet ordinateur. VIE Server refuse toute adresse d’écoute autre que `localhost`, `127.0.0.1` ou une autre adresse de boucle locale. Il refuse notamment `0.0.0.0`.

Une ancienne adresse `http://localhost:8080/vie/` reçoit une redirection HTTP 308 vers HTTPS sur le même port. Après une connexion HTTPS réussie, HSTS demande aussi au navigateur de conserver l’usage du transport sécurisé.

## Installation Windows transparente

1. Décompresser entièrement `ma-vie.zip`.
2. Ouvrir le dossier `server`.
3. Double-cliquer sur `INSTALLER-VIE.bat`.
4. Accepter l’autorisation administrateur annoncée par l’installateur.
5. VIE génère le certificat, installe son autorité publique dans le magasin de confiance Windows, protège la clé privée, installe le service et ouvre `https://localhost:8080/vie/`.

Pour éviter toute fenêtre qui s’ouvre puis se ferme, la méthode la plus simple est de double-cliquer à la racine du paquet sur :

```text
COMMENCER-ICI.cmd
```

Puis choisir **1 — Installer ou mettre à jour Ma Vie**. Le menu reste ouvert et permet aussi de lancer le diagnostic ou le serveur au premier plan.

Aucun OpenSSL, aucune commande de certificat et aucune manipulation régulière du navigateur ne sont demandés à l’utilisateur.

L’installation crée :

```text
C:\VIE\
├── app\
│   ├── index.html
│   ├── styles.css
│   ├── views.js
│   ├── script.js
│   ├── server-adapter.js
│   └── assets\
│       ├── recurrence-engine.js
│       └── react\
├── data\
│   ├── vie.db
│   └── attachments\
├── backups\
├── logs\
└── server\
    ├── vie-server.exe
    ├── config.json
    ├── tls\
    │   ├── server-cert.pem
    │   ├── server-key.pem
    │   └── vie-local-ca.cer
    ├── vie-manager.ps1
    ├── AIDE-VIE-NE-SE-FERME-PAS.cmd
    ├── DIAGNOSTIC-VIE.bat
    ├── diagnostiquer-vie.ps1
    ├── reparer-https.ps1
    └── restaurer-sauvegarde.ps1
```

Les dossiers `data` et `backups` existants ne sont jamais effacés pendant une mise à jour. L’installateur demande d’abord au serveur actif une sauvegarde cohérente, puis migre une ancienne configuration HTTP vers HTTPS sans modifier les données métier.

## Mettre à jour une installation existante

`INSTALLER-VIE.bat` sert à la fois à la première installation et aux mises à jour :

1. télécharger le nouveau paquet ;
2. **extraire complètement** `ma-vie.zip` dans un dossier normal — ne pas exécuter l’installateur depuis l’aperçu du ZIP ;
3. lancer le nouveau `server\INSTALLER-VIE.bat` ;
4. accepter la demande administrateur ;
5. attendre le message explicite de réussite.

L’installateur arrête le service et l’ancien gestionnaire, conserve les données, copie tous les fichiers applicatifs, vérifie notamment `assets\recurrence-engine.js`, réinstalle le service, contrôle l’API et télécharge chaque ressource de démarrage en HTTPS avant d’ouvrir le navigateur. Le journal est écrit dans :

```text
%TEMP%\Ma-Vie-installation.log
```

## Si le navigateur affiche une page blanche

La cause la plus fréquente est un paquet incomplet ou une ancienne installation dont `index.html` référence un script non copié. La version corrigée affiche désormais une page de réparation au lieu de disparaître silencieusement.

Procédure :

1. fermer les anciens onglets VIE ;
2. relancer `server\INSTALLER-VIE.bat` depuis le dernier paquet entièrement extrait ;
3. dans le navigateur, utiliser `Ctrl+F5` ;
4. si nécessaire, exécuter :

```text
C:\VIE\server\DIAGNOSTIC-VIE.bat
```

Le diagnostic vérifie le service, la configuration, le certificat, les fichiers JavaScript et leur disponibilité HTTPS. Il écrit un rapport dans `C:\VIE\logs` et l’ouvre automatiquement si une erreur est détectée. Le gestionnaire de la zone de notification propose aussi **Diagnostiquer une page blanche…**.

## Modèle du certificat local

VIE crée :

- une autorité locale **VIE Local Root CA** ;
- un certificat serveur valable pour `localhost`, `127.0.0.1` et `::1` ;
- une clé ECDSA P-256 pour le serveur.

La clé privée de l’autorité n’est jamais conservée après la signature. Seule la clé privée du certificat serveur reste dans `C:\VIE\server\tls`, protégé par les droits NTFS du propriétaire, de `LocalSystem` et des administrateurs.

Commandes disponibles :

```text
vie-server.exe init-tls  --config C:\VIE\server\config.json
vie-server.exe renew-tls --config C:\VIE\server\config.json
```

- `init-tls` réutilise le certificat s’il est encore valide ;
- `renew-tls` effectue une rotation explicite ;
- `reparer-https.ps1` vérifie ou réinstalle automatiquement la confiance Windows.

La désinstallation du seul service conserve volontairement le certificat avec l’installation. Pour le retirer explicitement :

```powershell
.\desinstaller-service.ps1 -RetirerCertificatHTTPS
```

## Transport et sessions

La chaîne locale comprend :

```text
Navigateur
   ↓ TLS 1.2 minimum, TLS 1.3 privilégié
Cookie __Host-… Secure + HttpOnly + SameSite=Strict
Jeton CSRF distinct + contrôle Origin/Sec-Fetch-Site
   ↓
127.0.0.1:8080
   ↓
VIE Server
```

Le jeton de session du serveur est régénéré à chaque démarrage : les anciens cookies cessent alors d’être valides. Les scripts Windows utilisent un jeton administratif aléatoire conservé dans `config.json`, dont les droits NTFS sont réduits.

La session de transport ne remplace pas la session chiffrée de l’application. VIE conserve séparément :

- le verrouillage manuel ;
- le verrouillage après inactivité ;
- la limitation des tentatives de connexion ;
- la dérivation PBKDF2 ;
- l’effacement de la clé de déchiffrement à la déconnexion ;
- la réauthentification des opérations sensibles ;
- le journal des événements de sécurité.

## Démarrage automatique

L’installateur enregistre **VIEServer** comme service Windows natif :

- démarrage automatique avec Windows ;
- aucune console à laisser ouverte ;
- redémarrage automatique après une panne ;
- écoute limitée à la boucle locale ;
- disponibilité avant l’ouverture du navigateur.

Le gestionnaire de la zone de notification offre :

- Ouvrir VIE en HTTPS ;
- afficher l’état HTTPS, SQLite et du certificat ;
- réparer le certificat HTTPS ;
- créer une sauvegarde cohérente ;
- restaurer une sauvegarde ;
- diagnostiquer une page blanche et les ressources du navigateur ;
- vérifier la base et les fichiers ;
- redémarrer le serveur ;
- ouvrir le dossier VIE.

## SQLite et chiffrement applicatif

La base se trouve dans :

```text
C:\VIE\data\vie.db
```

Le navigateur ne lit et n’écrit jamais directement ce fichier :

1. l’espace est chiffré en AES-GCM dans le navigateur ;
2. l’enveloppe chiffrée est transmise par HTTPS à la boucle locale ;
3. VIE Server vérifie le format, la taille, la session et le jeton CSRF ;
4. SQLite enregistre l’enveloppe et son empreinte ;
5. les pièces jointes sont également chiffrées avant leur arrivée dans `attachments`.

Le serveur ne reçoit ni le mot de passe principal ni les données métier en clair. Les objectifs, finances, relations et journaux ne sont pas éclatés dans des tables lisibles.

SQLite contient notamment :

- `profiles` : configuration publique et registre minimal des profils ;
- `state_envelopes` : espaces chiffrés et révisions ;
- `files` : métadonnées et empreintes des fichiers chiffrés ;
- `backups` : registre des sauvegardes cohérentes ;
- `audit_log` : actions techniques du serveur ;
- `schema_migrations` : version du schéma.

## Validation des fichiers et chemins

- taille maximale configurable et contrôlée avec `MaxBytesReader` ;
- enveloppe `VIE-SECURE` et algorithme AES-GCM obligatoires ;
- identifiants limités à un alphabet sûr ;
- noms physiques dérivés par hachage ;
- chemins vérifiés dans les racines `data` ou `backups` ;
- aucune extension fournie par le navigateur n’est utilisée comme chemin système ;
- suppression logique vers une corbeille temporaire ;
- empreinte SHA-256 vérifiée à la lecture et lors des diagnostics.

## Conflits et opérations sensibles

Chaque écriture possède un numéro de révision et une date. Si SQLite contient une version plus récente :

- le serveur répond avec un conflit ;
- aucune version n’est écrasée ;
- l’interface demande quelle version conserver ;
- une sauvegarde est créée avant le choix.

Une suppression de profil ou de fichier exige une confirmation explicite. Les profils essentiels ne peuvent pas être supprimés par la route générique.

## Sauvegardes cohérentes

Le bouton **Créer une sauvegarde SQLite** :

1. termine l’écriture de l’enveloppe chiffrée ;
2. recopie les fichiers locaux manquants ;
3. crée un instantané SQLite avec `VACUUM INTO` ;
4. ajoute les pièces jointes chiffrées ;
5. calcule une empreinte SHA-256 ;
6. écrit une archive `.vie-local` dans `C:\VIE\backups`.

La sauvegarde quotidienne est prévue à `06:30` par défaut. Ne copiez pas simplement `vie.db` pendant que le service fonctionne : utilisez VIE, le gestionnaire Windows ou arrêtez d’abord le service.

## Portabilité vers un autre PC

### Archive utilisateur recommandée

Dans VIE :

```text
Espace VIE → Exportations → Créer une archive chiffrée .vie
```

### Dossier serveur complet

1. créer une sauvegarde cohérente ;
2. arrêter le service VIE ;
3. copier `C:\VIE` vers le nouvel ordinateur ;
4. relancer `INSTALLER-VIE.bat` sur le nouvel ordinateur afin d’installer le service et sa propre confiance HTTPS ;
5. ouvrir VIE en HTTPS.

## Restauration d’urgence

Le gestionnaire lance `restaurer-sauvegarde.ps1`. Le script :

- demande une élévation administrateur ;
- arrête le service ;
- vérifie le manifeste ;
- conserve une copie des données actuelles ;
- restaure SQLite et les pièces jointes ;
- redémarre le service et rouvre HTTPS.

## API locale

```text
GET    /api/v1/health
GET    /api/v1/bootstrap
PUT    /api/v1/state/{profil}
DELETE /api/v1/state/{profil}
GET    /api/v1/files/{profil}/{type}/{id}
PUT    /api/v1/files/{profil}/{type}/{id}
DELETE /api/v1/files/{profil}/{type}/{id}
POST   /api/v1/backups
GET    /api/v1/backups
POST   /api/v1/verify
```

Les routes privées exigent soit le jeton administratif local, soit toute la combinaison suivante :

- connexion depuis la boucle locale ;
- cookie de session sécurisé ;
- cookie et en-tête CSRF concordants ;
- en-tête interne VIE ;
- origine locale autorisée.

`config.json`, `vie.db`, les sauvegardes, les certificats et les pièces jointes ne sont jamais servis comme fichiers web.

## Compilation reproductible

```bash
cd server/source
go mod download
go test ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o ../vie-server.exe .
```

Le pilote SQLite est écrit en Go pur. Aucun XAMPP, PHP, MySQL, OpenSSL ou DLL SQLite séparée n’est nécessaire au fonctionnement installé.

L’exécutable fourni n’est pas signé commercialement ; SmartScreen peut demander une confirmation initiale. Les sources et versions de dépendances sont incluses pour vérification indépendante.

## Limites explicites

HTTPS protège le transport local et authentifie le serveur auprès du navigateur. Il ne protège pas contre un administrateur Windows malveillant, un système déjà compromis, un enregistreur de frappe ou la perte physique d’un disque non chiffré. Le chiffrement VIE, les sauvegardes et la protection du système d’exploitation restent nécessaires.

> **Local d’abord, accès minimal et zéro surprise.**

## Mise à jour depuis GitHub

Dépôt stable autorisé :

```text
Cyrakovsky/ma-vie
```

Fichiers installés dans `C:\VIE\server` :

```text
update-config.json
verifier-mise-a-jour.ps1
mettre-a-jour-vie.ps1
METTRE-A-JOUR-VIE.bat
```

`vie-manager.ps1` lance une vérification discrète après l’ouverture de session puis toutes les heures ; `verifier-mise-a-jour.ps1` n’interroge réellement GitHub qu’une fois toutes les 24 heures. L’utilisateur peut désactiver ce comportement dans le menu de l’icône VIE.

Une mise à jour n’est jamais installée silencieusement. La confirmation Windows **Oui / Non** précède le téléchargement et l’élévation UAC.

La chaîne de contrôle vérifie : dépôt et API codés en dur, Release stable, tag, manifeste, version, nom d’asset, taille, SHA-256, digest GitHub éventuel, chemins de l’archive et fichiers obligatoires. Aucun jeton GitHub n’est intégré.

Avant remplacement, une sauvegarde cohérente via l’API locale est obligatoire. Un point de retour protégé contient `app`, `server` et une copie fermée de `vie.db`. En cas d’échec, l’updater restaure ces éléments puis redémarre le service. Les pièces jointes et sauvegardes restent hors du remplacement.

Journal :

```text
C:\VIE\logs\mise-a-jour.log
```

### Compatibilité Windows PowerShell 5.1 — 26.0.1

Tous les scripts PowerShell du paquet utilisent l’encodage UTF-8 avec BOM. Une ancienne copie affichant `â€”` ou `Ã ` doit être remplacée en relançant l’option `[1]` depuis le paquet 26.0.1.

### Chemins comme `ma-vie (15)` — 26.0.2

Le lanceur Batch de l’installateur utilise des labels et des branchements sans blocs sensibles aux parenthèses présentes dans le chemin. Il peut être lancé directement depuis un dossier de téléchargement renommé par Windows.
