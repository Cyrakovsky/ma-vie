﻿param([string]$InstallRoot="C:\VIE")
$ErrorActionPreference="Stop"
$exe=Join-Path $InstallRoot "server\vie-server.exe"
$configPath=Join-Path $InstallRoot "server\config.json"
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  exit
}
if(!(Test-Path $exe)){throw "Serveur VIE introuvable : $exe"}
if(!(Test-Path $configPath)){throw "Configuration VIE introuvable : $configPath"}
$config=Get-Content $configPath -Raw|ConvertFrom-Json
if(($config.PSObject.Properties.Name -contains "tlsEnabled") -and $config.tlsEnabled){
  & $exe init-tls --config $configPath
  if($LASTEXITCODE -ne 0){throw "Certificat HTTPS VIE non prêt."}
  $caPath=if([IO.Path]::IsPathRooted([string]$config.tlsCAFile)){[string]$config.tlsCAFile}else{[IO.Path]::GetFullPath((Join-Path (Join-Path $InstallRoot "server") ([string]$config.tlsCAFile)))}
  $cert=New-Object -TypeName System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList $caPath
  if(!(Get-ChildItem Cert:\LocalMachine\Root|Where-Object{$_.Thumbprint -eq $cert.Thumbprint})){
    Write-Host "Installation explicite de l’autorité HTTPS locale VIE." -ForegroundColor Yellow
    Import-Certificate -FilePath $caPath -CertStoreLocation Cert:\LocalMachine\Root|Out-Null
  }
}
& $exe install-service --config $configPath
if($LASTEXITCODE -ne 0){throw "Installation du service VIE impossible."}
& sc.exe failure VIEServer reset= 86400 actions= restart/5000/restart/15000/""/0 | Out-Null
Write-Host "Service HTTPS VIE installé et démarré." -ForegroundColor Green
