﻿param([string]$InstallRoot="C:\VIE",[string]$BackupFile="")
$ErrorActionPreference="Stop"
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $args="-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -InstallRoot `"$InstallRoot`""
  if($BackupFile){$args+=" -BackupFile `"$BackupFile`""}
  Start-Process powershell.exe -Verb RunAs -ArgumentList $args
  exit
}
if(!$BackupFile){
  Add-Type -AssemblyName System.Windows.Forms
  $dialog=New-Object System.Windows.Forms.OpenFileDialog
  $dialog.InitialDirectory=Join-Path $InstallRoot "backups"
  $dialog.Filter="Sauvegarde VIE (*.vie-local)|*.vie-local|Tous les fichiers (*.*)|*.*"
  if($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit}
  $BackupFile=$dialog.FileName
}
if(!(Test-Path $BackupFile)){throw "Sauvegarde introuvable : $BackupFile"}
$DataDir=Join-Path $InstallRoot "data"
$SafetyDir=Join-Path $InstallRoot ("backups\avant-restauration-"+(Get-Date -Format "yyyyMMdd-HHmmss"))
$TempDir=Join-Path $env:TEMP ("vie-restore-"+[guid]::NewGuid().ToString("N"))
$TempZip=Join-Path $TempDir "backup.zip"
New-Item -ItemType Directory -Path $TempDir -Force|Out-Null
try{
  Copy-Item $BackupFile $TempZip
  Expand-Archive $TempZip (Join-Path $TempDir "archive") -Force
  $manifestPath=Join-Path $TempDir "archive\manifest.json"
  $databasePath=Join-Path $TempDir "archive\database\vie.db"
  if(!(Test-Path $manifestPath) -or !(Test-Path $databasePath)){throw "Archive VIE locale incomplète"}
  $manifest=Get-Content $manifestPath -Raw|ConvertFrom-Json
  if($manifest.format -ne "VIE-LOCAL-BACKUP"){throw "Format de sauvegarde non reconnu"}
  Stop-Service VIEServer -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 800
  New-Item -ItemType Directory -Path $SafetyDir -Force|Out-Null
  if(Test-Path $DataDir){Copy-Item $DataDir (Join-Path $SafetyDir "data") -Recurse -Force}
  New-Item -ItemType Directory -Path $DataDir -Force|Out-Null
  Remove-Item (Join-Path $DataDir "vie.db-wal") -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $DataDir "vie.db-shm") -Force -ErrorAction SilentlyContinue
  Copy-Item $databasePath (Join-Path $DataDir "vie.db") -Force
  $restoredAttachments=Join-Path $TempDir "archive\attachments"
  $currentAttachments=Join-Path $DataDir "attachments"
  if(Test-Path $currentAttachments){Remove-Item $currentAttachments -Recurse -Force}
  if(Test-Path $restoredAttachments){Copy-Item $restoredAttachments $currentAttachments -Recurse -Force}
  else{New-Item -ItemType Directory -Path $currentAttachments -Force|Out-Null}
  Start-Service VIEServer
  Start-Sleep -Seconds 2
  Write-Host "Sauvegarde restaurée. Copie de sécurité précédente : $SafetyDir" -ForegroundColor Green
  $configPath=Join-Path $InstallRoot "server\config.json"
  $config=Get-Content $configPath -Raw|ConvertFrom-Json
  $port=($config.listen -split ':')[-1]
  $scheme=if(($config.PSObject.Properties.Name -contains "tlsEnabled") -and $config.tlsEnabled){"https"}else{"http"}
  $url="${scheme}://localhost:$port/"+$config.basePath.Trim('/')+"/"
  Start-Process $url
}catch{
  Write-Error $_
  Write-Host "La copie de sécurité précédente est conservée dans : $SafetyDir" -ForegroundColor Yellow
  throw
}finally{Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue}
