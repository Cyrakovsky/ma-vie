@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title Ma Vie - installation ou mise a jour locale HTTPS
set "LOG=%TEMP%\Ma-Vie-installation.log"

echo ============================================================
echo   Ma Vie - installation ou mise a jour locale HTTPS
echo ============================================================
echo.
echo Cette operation conserve C:\VIE\data et C:\VIE\backups.
echo Une demande d'autorisation administrateur peut apparaitre.
echo Journal : %LOG%
echo.

if exist "%~dp0installer-vie.ps1" goto INSTALLER_PRESENT
echo ERREUR : installer-vie.ps1 est introuvable dans :
echo %~dp0
echo Extrayez completement ma-vie.zip avant de lancer ce fichier.
echo.
pause
exit /b 1

:INSTALLER_PRESENT
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer-vie.ps1"
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" goto INSTALLATION_OK

echo.
echo ECHEC de l'installation ou de la mise a jour. Code : %RC%
echo Journal temporaire : %LOG%
if exist "%LOG%" goto AFFICHER_JOURNAL
echo Aucun journal temporaire n'a ete cree.
goto ECHEC_FIN

:AFFICHER_JOURNAL
echo.
type "%LOG%"

:ECHEC_FIN
echo.
pause
exit /b %RC%

:INSTALLATION_OK
echo.
echo Ma Vie a ete installee ou mise a jour avec succes.
echo Si le navigateur conservait une page blanche, utilisez Ctrl+F5.
echo Adresse : https://localhost:8080/vie/
echo Journal : %LOG%
echo.
pause
exit /b 0
