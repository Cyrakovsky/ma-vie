"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const script = fs.readFileSync(path.join(root,"script.js"),"utf8");
const views = fs.readFileSync(path.join(root,"views.js"),"utf8");
const styles = fs.readFileSync(path.join(root,"styles.css"),"utf8");
const adapters = fs.readFileSync(path.join(root,"assets/react/vie-view-adapters.js"),"utf8");

assert.match(script,/target\.lifeVisionBaselines=/,"Les baselines doivent utiliser un store spécialisé");
assert.doesNotMatch(script,/EntityType[^\n]*(?:LifeVisionBaseline|VisionBaseline|Boussole)/i,"Aucune nouvelle primitive Core générique");
assert.match(script,/La somme des poids doit être exactement 100 %/);
assert.match(script,/Créer sans écraser l’ancienne/);
assert.match(script,/supersedesId:active\?\.id/);
assert.match(script,/state\.lifeVisionBaselines\.push\(baseline\)/);
assert.doesNotMatch(script,/edit-life-vision-baseline|delete-life-vision-baseline/,"Une baseline publiée ne doit être ni éditée ni supprimée depuis l’interface courante");
assert.match(script,/Qu’as-tu fait de ce qui t’a été donné \?/);
assert.match(script,/Revue conservée comme observation déclarée/);
assert.match(script,/reflect-on-life-review/);
assert.match(views,/BOUSSOLE DE VIE · BASELINE/);
assert.match(views,/aucun score de réussite/i);
assert.match(views,/Moins documenté que déclaré/);
assert.match(views,/VIE constate une évolution entre deux déclarations/);
assert.match(script,/ne constitue jamais un échec/);
assert.match(views,/Une question, pas une notification permanente/);
assert.match(views,/Cette question apparaît ici lors d’une revue choisie/);
assert.match(views,/Déclaré, documenté et accompli/);
assert.match(adapters,/contract:"vie\.life-compass\.v1"/);
assert.match(adapters,/baselineIsImmutable:true/);
assert.match(adapters,/compassIsSuccessScore:false/);
assert.match(adapters,/gapIsMoralJudgment:false/);
assert.match(adapters,/missingEvidenceIsFailure:false/);
assert.match(styles,/VIE 19\.0 — Boussole de vie et baselines immuables/);

console.log(JSON.stringify({
  ok:true,
  specializedStore:true,
  immutableBaselines:true,
  comparisonDescriptive:true,
  successScore:false,
  moralJudgment:false,
  periodicReview:true
},null,2));
