"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const state = {
  recurrenceSettings: { zone: "Africa/Libreville" },
  consumptionSettings: { foodCategoryId: "cat-food", horizonDays: 120 },
  consumptionCategoryStore: [
    { id: "cat-food", name: "Alimentation", parentId: "", icon: "box", builtIn: true, active: true },
    { id: "cat-food-grocery", name: "Épicerie", parentId: "cat-food", icon: "box", builtIn: true, active: true }
  ],
  frequencyRules: [{ id: "frequency-consumption-rice", revision: 1, status: "ACTIVE", schedule: { type: "ROLLING_INTERVAL", every: 7, unit: "DAY" }, metadata: { learningEnabled: false } }],
  consumptionStore: [{ id: "rice", name: "Riz", categoryId: "cat-food", subcategoryId: "cat-food-grocery", defaultPrice: 3500, defaultQuantity: 1, unit: "sac", frequencyRuleId: "frequency-consumption-rice", characteristics: { model: "5 kg", criteria: [] }, active: true }],
  consumptionPurchases: [{ id: "purchase-rice", articleId: "rice", itemName: "Riz", purchasedAt: "2026-08-08", price: 3500, quantity: 1, unitPrice: 3500 }],
  purchaseCart: [{ id: "line-rice", articleId: "rice", quantity: 2, unitPrice: 3400 }],
  consumptionBudgets: [{ id: "budget-food", categoryId: "cat-food", month: "2026-08", amount: 50000 }]
};

const view = window.VieViewAdapters.purchaseWorkspace(state, { referenceDate: "2026-08-11", month: "2026-08", categoryId: "cat-food" });

assert.equal(view.contract, "vie.purchase-workspace.v1");
assert.equal(view.catalog.length, 1);
assert.equal(view.cart.length, 1);
assert.equal(view.cart[0].quantity, 2);
assert.equal(view.cart[0].total, 6800);
assert.equal(view.budget.target, 50000);
assert.equal(view.budget.actual, 3500);
assert.equal(view.budget.forecast, 10500);
assert.equal(view.budget.projection, 14000);
assert.equal(view.budget.remaining, 36000);
assert.equal(view.principles.cartIsPurchase, false);
assert.equal(view.principles.oneArticleOneCartLine, true);
assert.equal(view.principles.oneCheckoutAtMostOneTransaction, true);
assert.equal(Object.isFrozen(view), true);
assert.equal(Object.isFrozen(view.cart[0]), true);

console.log(JSON.stringify({
  ok: true,
  contract: view.contract,
  cartTotal: view.cart[0].total,
  actual: view.budget.actual,
  forecast: view.budget.forecast,
  projection: view.budget.projection,
  frozen: Object.isFrozen(view)
}, null, 2));
