"use strict";
const assert=require("node:assert/strict");
global.window={};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const categories=[
  {id:"cat-food",name:"Alimentation",parentId:"",icon:"box",active:true},
  {id:"cat-food-starches",name:"Féculents",parentId:"cat-food",icon:"box",active:true},
  {id:"cat-food-dairy",name:"Produits laitiers",parentId:"cat-food",icon:"heart",active:true},
  {id:"cat-hygiene",name:"Hygiène",parentId:"",icon:"sparkles",active:true},
  {id:"cat-hygiene-hair",name:"Cheveux",parentId:"cat-hygiene",icon:"sparkles",active:true}
];
const articles=[
  {id:"rice",name:"Riz",categoryId:"cat-food",subcategoryId:"cat-food-starches",defaultPrice:8500,defaultQuantity:1,unit:"sac",characteristics:{packaging:"Sac",size:"5 kg"},frequencyRuleId:"freq-rice",active:true},
  {id:"milk",name:"Lait",categoryId:"cat-food",subcategoryId:"cat-food-dairy",defaultPrice:2000,defaultQuantity:1,unit:"brique",characteristics:{packaging:"Brique",size:"1 L"},frequencyRuleId:"freq-milk",active:true},
  {id:"shampoo",name:"Shampooing",categoryId:"cat-hygiene",subcategoryId:"cat-hygiene-hair",defaultPrice:4500,defaultQuantity:1,unit:"flacon",characteristics:{packaging:"Flacon",size:"500 ml"},frequencyRuleId:"freq-shampoo",active:true}
];
const state={
  ui:{financeAllocationMonth:"2026-08"},financeSettings:{currency:"FCFA"},consumptionSettings:{horizonDays:365},
  consumptionCategoryStore:categories,consumptionStore:articles,
  frequencyRules:articles.map(item=>({id:item.frequencyRuleId,revision:1,status:"ACTIVE",schedule:{type:"ROLLING_INTERVAL",every:30,unit:"DAY"},metadata:{learningEnabled:false}})),
  purchaseCart:[
    {id:"cart-rice",articleId:"rice",quantity:2,unitPrice:8500,format:"Sac 5 kg",plannedMonth:"2026-08",plannedDate:"2026-08-15",budgetAllocationId:"food-allocation"},
    {id:"cart-milk",articleId:"milk",quantity:4,unitPrice:2000,format:"Brique 1 L",plannedMonth:"2026-08",plannedDate:"2026-08-15",budgetAllocationId:"food-allocation"}
  ],
  forecastExpenses:[{id:"vegetables",name:"Fruits & légumes",category:"Fruits & Légumes",expenseCategoryId:"expense-food-produce",amount:15000,date:"2026-08-15",status:"planned",budgetAllocationId:"food-allocation"}],
  recurringExpenses:[],transactions:[],acquisitionPlans:[],trainingStore:[],
  consumptionPurchases:[{id:"actual-shampoo",articleId:"shampoo",itemId:"shampoo",itemName:"Shampooing",purchasedAt:"2026-08-17",price:4200,quantity:1,unitPrice:4200,source:"financial-calendar",merchant:"Boutique",transactionId:"",financialPlanLinkId:"plan-link-shampoo"}],
  financialPlanHistory:[{id:"plan-link-shampoo",revision:1,planSourceType:"purchaseCart",planSourceId:"cart-shampoo-original",planSnapshot:{sourceType:"purchaseCart",sourceId:"cart-shampoo-original",entityId:"shampoo",kind:"PLANNED",title:"Shampooing",articleId:"shampoo",plannedDate:"2026-08-17",date:"2026-08-17",amount:4500,quantity:1,unitPrice:4500,format:"Flacon 500 ml",categoryId:"cat-hygiene",subcategoryId:"cat-hygiene-hair",category:"Hygiène",subcategory:"Cheveux",categoryPath:["Hygiène","Cheveux"],domain:"wellbeing",budgetAllocationId:"appearance-allocation",frequencyDays:30,reason:"Plan initial"},actualSourceType:"consumptionPurchase",actualSourceId:"actual-shampoo",actualTransactionId:"",status:"REALIZED",createdAt:"2026-08-17T10:00:00Z"}],
  expenseCategoryStore:[
    {id:"expense-food",name:"Alimentation",parentId:"",icon:"box",allocationDomain:"food"},
    {id:"expense-food-produce",name:"Fruits & Légumes",parentId:"expense-food",icon:"box",allocationDomain:""}
  ],
  budgetStore:[{id:"budget-aug",period:"2026-08",amount:130000,currency:"FCFA",status:"ACTIVE"}],
  budgetAllocationStore:[
    {id:"food-allocation",budgetId:"budget-aug",domain:"food",label:"Alimentation",amount:100000,period:"2026-08",status:"ACTIVE",forecastMode:"DUE_PURCHASES"},
    {id:"appearance-allocation",budgetId:"budget-aug",domain:"appearance",label:"Apparence",amount:30000,period:"2026-08",status:"ACTIVE",forecastMode:"DUE_PURCHASES"}
  ]
};

const view=window.VieViewAdapters.financialCalendar(state,{referenceDate:"2026-08-12",month:"2026-08"});
assert.equal(view.contract,"vie.financial-calendar.v1");
assert.equal(view.calendar.length,42);
const august15=view.calendar.find(day=>day.date==="2026-08-15");
assert.equal(august15.plans.length,3,"Une journée doit accepter plusieurs dépenses détaillées");
assert.equal(august15.totals.planned,40000);
assert.equal(august15.totals.budgetImpact,40000);
assert.equal(august15.allocations.find(item=>item.label==="Alimentation").plannedBaseline,40000);
assert.equal(august15.allocations.find(item=>item.label==="Alimentation").budgetImpact,40000);
assert.equal(august15.allocations.find(item=>item.label==="Alimentation").amount,100000);
const rice=view.plans.find(item=>item.title==="Riz");
assert.equal(rice.quantity,2);assert.equal(rice.unitPrice,8500);assert.equal(rice.amount,17000);
assert.deepEqual(rice.categoryPath,["Alimentation","Féculents"]);
assert.equal(rice.allocation.label,"Alimentation");assert.equal(rice.canRealize,true);assert.equal(rice.editable,true);
const shampoo=view.plans.find(item=>item.title==="Shampooing");
assert.equal(shampoo.status,"REALIZED");assert.equal(shampoo.amount,4500);assert.equal(shampoo.actual.amount,4200);assert.equal(shampoo.variance.amount,-300);
assert.equal(shampoo.actual.date,"2026-08-17");assert.equal(shampoo.nextPurchaseDate,"2026-09-16");
assert.equal(view.budget.plannedBaseline,44500);assert.equal(view.budget.openPlanned,40000);assert.equal(view.budget.actual,4200);assert.equal(view.budget.variance,-300);assert.equal(view.budget.budgetImpact,44200);assert.equal(view.budget.availableAfterCalendar,85800);
assert.equal(view.allocations.find(item=>item.label==="Alimentation").budgetImpact,40000);
assert.equal(view.allocations.find(item=>item.label==="Apparence").budgetImpact,4200);
assert.equal(view.principles.plannedIsActual,false);assert.equal(view.principles.planSnapshotImmutable,true);assert.equal(view.principles.actualEditDoesNotMutatePlan,true);assert.equal(view.principles.budgetImpactReplacesRealizedPlanWithActual,true);assert.equal(view.principles.multipleExpensesPerDay,true);assert.equal(view.principles.noDoubleCounting,true);
assert.equal(Object.isFrozen(view),true);assert.equal(Object.isFrozen(shampoo.actual),true);
console.log(JSON.stringify({ok:true,contract:view.contract,day:{date:august15.date,entries:august15.plans.length,total:august15.totals.planned},comparison:{planned:shampoo.amount,actual:shampoo.actual.amount,variance:shampoo.variance.amount},budget:view.budget,frozen:true},null,2));
