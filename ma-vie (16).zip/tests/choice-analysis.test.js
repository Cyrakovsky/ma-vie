"use strict";
const assert=require("node:assert/strict");
global.window={};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const state={
  ui:{selectedChoiceAnalysisId:"choice-training",financeAllocationMonth:"2026-08"},financeSettings:{currency:"FCFA"},financeAccounts:[],
  choiceAnalysisStore:[{id:"choice-training",title:"Faire la formation ?",question:"Faire la formation maintenant ?",category:"Formation",status:"EXPLORING",linkedGoalId:"goal-job",budgetAllocationId:"allocation-training",createdAt:"2026-08-12T08:00:00Z",options:[
    {id:"yes",name:"Formation A",summary:"Suivre la formation complète",impacts:[
      {id:"yes-money",dimension:"MONEY",label:"Coût de la formation",direction:"DECREASE",value:300000,unit:"FCFA",epistemicStatus:"FACT",sourceRef:{type:"budgetAllocation",id:"allocation-training"},explanation:"Tarif enregistré"},
      {id:"yes-time",dimension:"TIME",label:"Temps de formation",direction:"DECREASE",value:80,unit:"h",epistemicStatus:"ESTIMATED",sourceRef:{type:"training",id:"training-a"},explanation:"Durée annoncée"},
      {id:"yes-skill",dimension:"SKILL",label:"Compétence métier",direction:"INCREASE",value:2,unit:"niveau",epistemicStatus:"ESTIMATED",sourceRef:{type:"skill",id:"skill-a"},explanation:"Évolution à évaluer après preuves"},
      {id:"yes-opportunity",dimension:"OPPORTUNITY",label:"Opportunité professionnelle",direction:"INCREASE",value:0,unit:"",epistemicStatus:"ASSUMED",sourceRef:{type:"USER",id:""},explanation:"Hypothèse personnelle"},
      {id:"yes-unknown",dimension:"OTHER",label:"Effet sur la fatigue",direction:"UNKNOWN",value:0,unit:"",epistemicStatus:"UNKNOWN",sourceRef:{type:"UNKNOWN",id:""},explanation:"Conséquence inconnue"},
      {id:"invalid-fact",dimension:"OTHER",label:"Emploi garanti",direction:"INCREASE",value:1,unit:"",epistemicStatus:"FACT",sourceRef:{type:"USER",id:""},explanation:"Ne peut pas être un fait sans source"}
    ]},
    {id:"no",name:"Ne pas la faire",summary:"Conserver les ressources",impacts:[
      {id:"no-money",dimension:"MONEY",label:"Budget non mobilisé",direction:"NEUTRAL",value:0,unit:"FCFA",epistemicStatus:"FACT",sourceRef:{type:"budget",id:"budget-aug"},explanation:"Aucune sortie simulée"},
      {id:"no-time",dimension:"TIME",label:"Temps non mobilisé",direction:"INCREASE",value:80,unit:"h",epistemicStatus:"ESTIMATED",sourceRef:{type:"capacity",id:"profile"},explanation:"Temps restant à arbitrer"},
      {id:"no-skill",dimension:"SKILL",label:"Compétence métier",direction:"NEUTRAL",value:0,unit:"niveau",epistemicStatus:"FACT",sourceRef:{type:"skill",id:"skill-a"},explanation:"Aucune progression créée"}
    ]}
  ]}],
  budgetStore:[{id:"budget-aug",period:"2026-08",periodType:"MONTH",amount:1000000,currency:"FCFA",status:"ACTIVE"}],
  budgetAllocationStore:[{id:"allocation-training",budgetId:"budget-aug",domain:"education",label:"Formation",amount:400000,period:"2026-08",status:"ACTIVE",forecastMode:"DUE_PURCHASES",categoryMatchers:[]}],
  capacityProfile:{availableFinance:500000,weeklyHours:20,energyAvailable:70,attentionAvailable:60},
  goals:[{id:"goal-job",name:"Évoluer professionnellement",progress:20,actions:[]}],skillStore:[{id:"skill-a",name:"Analyse de données",score:25}],trainingStore:[{id:"training-a",title:"Formation A",status:"planned",duration:{hours:80},cost:{amount:300000,currency:"FCFA"}}],lifeDecisions:[],
  transactions:[],consumptionPurchases:[],purchaseCart:[],forecastExpenses:[],recurringExpenses:[],acquisitionPlans:[],consumptionStore:[],consumptionSettings:{},consumptionCategoryStore:[],expenseCategoryStore:[]
};
const before=structuredClone(state),view=window.VieViewAdapters.choiceAnalysis(state,{referenceDate:"2026-08-12",month:"2026-08"});
assert.equal(view.contract,"vie.choice-analysis.v1");assert.equal(view.conceptVersion,"0.1");assert.equal(view.selected.options.length,2);assert.equal(view.comparison.some(row=>row.dimension==="MONEY"),true);assert.equal(view.comparison.some(row=>row.dimension==="TIME"),true);assert.equal(view.comparison.some(row=>row.dimension==="SKILL"),true);
const money=view.selected.options[0].impacts.find(item=>item.id==="yes-money");assert.equal(money.epistemicStatus,"FACT");assert.equal(money.signedValue,-300000);assert.equal(money.chain.find(item=>item.id==="allocation").label,"Budget Formation");assert.equal(money.chain.find(item=>item.id==="monthly-budget").value,"1 000 000 FCFA");assert.equal(money.chain.find(item=>item.id==="remaining-after").value,"700 000 FCFA");assert.equal(money.chain.find(item=>item.id==="other-expenses").value,"Réduite de 300 000 FCFA");
const opportunity=view.selected.options[0].impacts.find(item=>item.id==="yes-opportunity");assert.equal(opportunity.epistemicStatus,"ASSUMED");assert.equal(opportunity.source.supportsFact,false);
const unknown=view.selected.options[0].impacts.find(item=>item.id==="yes-unknown");assert.equal(unknown.displayValue,"Inconnu");
const invalid=view.selected.options[0].impacts.find(item=>item.id==="invalid-fact");assert.equal(invalid.declaredEpistemicStatus,"FACT");assert.equal(invalid.epistemicStatus,"UNKNOWN","Un FACT non sourcé ne doit jamais rester affiché comme fait");assert.equal(view.integrity.warnings.some(item=>item.includes("FACT exige une source")),true);
assert.equal(view.epistemicSummary.FACT,3);assert.equal(view.epistemicSummary.ESTIMATED,3);assert.equal(view.epistemicSummary.ASSUMED,1);assert.equal(view.epistemicSummary.UNKNOWN,2);
assert.equal(view.principles.choiceAnalysisIsPredictionEngine,false);assert.equal(view.principles.choiceAnalysisIsScenarioEngine,false);assert.equal(view.principles.choiceAnalysisIsDecisionSupport,true);assert.equal(view.principles.probabilityInvented,false);assert.equal(view.principles.optionRecommended,false);assert.equal(view.principles.optionScored,false);assert.equal(view.principles.simulationMutatesReality,false);assert.equal(view.principles.explorationCreatesDecision,false);assert.equal(view.principles.decisionRequiresExplicitChoice,true);assert.equal(view.principles.assumptionIsFact,false);assert.equal(state.lifeDecisions.length,0);assert.deepEqual(state,before,"Construire la simulation ne doit muter aucun store réel");assert.equal(/probabilit/i.test(JSON.stringify(view.selected)),false);assert.equal("score" in view.selected.options[0],false);assert.equal(Object.isFrozen(view),true);assert.equal(Object.isFrozen(money.chain),true);
const decidedState=structuredClone(state);decidedState.choiceAnalysisStore[0].decisionId="decision-1";decidedState.choiceAnalysisStore[0].status="DECIDED";decidedState.lifeDecisions=[{id:"decision-1",title:"Faire la formation ?",chosenOption:"Formation A",planCreatedAt:""}];const decidedView=window.VieViewAdapters.choiceAnalysis(decidedState,{referenceDate:"2026-08-12",month:"2026-08"});assert.equal(Object.isFrozen(decidedView.decision),true);assert.equal(Object.isFrozen(decidedState.lifeDecisions[0]),false,"Le contrat ne doit jamais geler le store source");decidedState.lifeDecisions[0].planCreatedAt="2026-08-12";assert.equal(decidedState.lifeDecisions[0].planCreatedAt,"2026-08-12");
console.log(JSON.stringify({ok:true,contract:view.contract,options:view.selected.options.length,epistemic:view.epistemicSummary,budgetChain:money.chain.map(item=>item.label),invalidFactDowngraded:true,stateUntouched:true,sourceStoreMutable:true,noScore:true,noProbability:true,frozen:true},null,2));
