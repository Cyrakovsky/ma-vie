"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const state = {
  profile: { principles: ["Le partage donne du sens à certains accomplissements."] },
  reflectiveMemorySettings: { minimumRecurring: 2 },
  thoughtStore: [
    {
      id: "thought-share",
      content: "Tous les trésors du monde ne sont rien si personne n'est là pour les partager.",
      date: "2026-08-10",
      context: "Réflexion sur le bonheur",
      themes: ["Bonheur", "Relation", "Partage"],
      sourceLabel: "Pensée personnelle",
      sourceUrl: "",
      epistemicStatus: "DECLARED"
    },
    {
      id: "thought-goal",
      content: "Un résultat a davantage de sens lorsqu'il peut être partagé.",
      date: "2026-08-11",
      context: "Objectif de vie",
      themes: ["Accomplissement", "Partage"],
      epistemicStatus: "DECLARED"
    }
  ],
  reflectionStore: [
    {
      id: "reflection-happiness",
      title: "Bonheur, relation et détachement",
      content: "Le désir peut conduire à l'action, mais le partage participe au sens que je lui donne.",
      date: "2026-08-11",
      context: "Bonheur",
      concepts: ["Désir", "Action", "Relation", "Partage", "Détachement"],
      principleCandidate: "Examiner avec qui je souhaite partager une réussite.",
      epistemicStatus: "DECLARED"
    }
  ],
  goals: [{ id: "goal-home", name: "Construire une maison familiale" }],
  lifeDecisions: [{ id: "decision-location", title: "Choisir le lieu de vie" }],
  propertyProjects: [],
  lessons: [{ id: "lesson-family", title: "Une réussite vécue seul ne m'a pas satisfait" }],
  journal: [],
  dataRelations: [
    { id: "rel-thought-goal", sourceType: "thought", sourceId: "thought-share", sourceLabel: "Tous les trésors…", targetType: "goal", targetId: "goal-home", targetLabel: "Construire une maison familiale", relation: "éclaire", managedBy: "reflective-memory-form" },
    { id: "rel-reflection-thought", sourceType: "reflection", sourceId: "reflection-happiness", sourceLabel: "Bonheur, relation et détachement", targetType: "thought", targetId: "thought-share", targetLabel: "Tous les trésors…", relation: "développe", managedBy: "reflective-memory-form" },
    { id: "rel-thought-observation", sourceType: "thought", sourceId: "thought-share", sourceLabel: "Tous les trésors…", targetType: "lesson", targetId: "lesson-family", targetLabel: "Une réussite vécue seul…", relation: "est rapprochée de", managedBy: "reflective-memory-form" },
    { id: "rel-reflection-decision", sourceType: "reflection", sourceId: "reflection-happiness", sourceLabel: "Bonheur, relation et détachement", targetType: "decision", targetId: "decision-location", targetLabel: "Choisir le lieu de vie", relation: "éclaire", managedBy: "reflective-memory-form" },
    { id: "rel-principle", sourceType: "reflection", sourceId: "reflection-happiness", sourceLabel: "Bonheur, relation et détachement", targetType: "profilePrinciple", targetId: "principle-partage", targetLabel: "Le partage donne du sens à certains accomplissements.", relation: "a été adopté explicitement comme", managedBy: "reflective-principle-adoption" }
  ]
};

const memory = window.VieViewAdapters.reflectiveMemory(state, { referenceDate: "2026-08-11" });

assert.equal(memory.contract, "vie.reflective-memory.v1");
assert.equal(memory.thoughts.length, 2);
assert.equal(memory.reflections.length, 1);
assert.equal(memory.thoughts.every(item => item.epistemicStatus === "DECLARED"), true);
assert.equal(memory.reflections.every(item => item.epistemicStatus === "DECLARED"), true);
const sharing = memory.themes.find(item => item.key === "partage");
assert.ok(sharing);
assert.equal(sharing.count, 3);
assert.equal(sharing.epistemicStatus, "DERIVED");
assert.equal(sharing.recurring, true);
assert.match(sharing.statement, /apparaît dans 3 élément/);
assert.equal(memory.advice.length, 2, "Les liens explicites vers un objectif et une décision doivent produire deux conseils contextuels");
assert.equal(memory.advice.every(item => item.epistemicStatus === "ADVICE"), true);
assert.equal(memory.advice.every(item => item.provenance.length > 0), true);
assert.equal(memory.advice.every(item => item.rule === "explicit-reflective-links"), true);
assert.equal(memory.advice.some(item => item.provenance.some(source => source.epistemicStatus === "DERIVED")), true, "La chaîne causale doit distinguer le comptage dérivé des déclarations");
assert.equal(memory.advice.some(item => item.context.type === "goal"), true);
assert.equal(memory.principles[0].epistemicStatus, "DECLARED");
assert.equal(memory.principles[0].provenance[0].id, "reflection-happiness");
assert.equal(memory.associations.objectives, 1);
assert.equal(memory.associations.decisions, 1);
assert.equal(memory.integrity.ok, true);
assert.equal(memory.principlesOfOperation.thoughtIsTruth, false);
assert.equal(memory.principlesOfOperation.reflectionIsPrinciple, false);
assert.equal(memory.principlesOfOperation.derivedIsPsychologicalDiagnosis, false);
assert.equal(memory.principlesOfOperation.adviceRequiresProvenance, true);
assert.equal(memory.principlesOfOperation.contentCopiedAcrossModules, false);
assert.equal(Object.isFrozen(memory), true);
assert.equal(Object.isFrozen(memory.advice[0].provenance), true);

const broken = window.VieViewAdapters.reflectiveMemory({ ...state, thoughtStore: state.thoughtStore.slice(1) }, { referenceDate: "2026-08-11" });
assert.equal(broken.integrity.ok, true, "Une source mise en corbeille reste restaurable et ne doit pas bloquer toute la mémoire");
assert.equal(broken.integrity.warnings.some(item => item.includes("Source réflexive absente")), true);

console.log(JSON.stringify({
  ok: true,
  contract: memory.contract,
  declared: memory.thoughts.length + memory.reflections.length,
  recurringTheme: { label: sharing.label, count: sharing.count },
  traceableAdvice: memory.advice.length,
  psychologicalDiagnosis: false,
  frozen: Object.isFrozen(memory)
}, null, 2));
