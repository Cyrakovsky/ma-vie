"use strict";

const assert=require("node:assert/strict");
global.window={};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const state={
  ui:{financeAllocationMonth:"2026-08"},financeSettings:{currency:"FCFA"},
  budgetStore:[{id:"budget-2026-08",period:"2026-08",periodType:"MONTH",amount:100000,currency:"FCFA",status:"ACTIVE"}],
  budgetAllocationStore:[
    {id:"allocation-appearance",budgetId:"budget-2026-08",domain:"appearance",label:"Apparence",amount:35000,period:"2026-08",status:"ACTIVE",forecastMode:"DUE_PURCHASES"},
    {id:"allocation-food",budgetId:"budget-2026-08",domain:"food",label:"Alimentation",amount:50000,period:"2026-08",status:"ACTIVE",forecastMode:"DUE_PURCHASES"}
  ],
  transactions:[
    {id:"tx-appearance",type:"expense",amount:12500,label:"Soins et coiffure",category:"Apparence",date:"2026-08-03"},
    {id:"tx-food",type:"expense",amount:10000,label:"Courses",category:"Alimentation",date:"2026-08-04"},
    {id:"income",type:"income",amount:300000,label:"Revenu",category:"Salaire",date:"2026-08-01"}
  ],
  financeAccounts:[{id:"account",balance:450000}],
  acquisitionPlans:[{id:"acquisition-shoes",name:"Chaussures",family:"Chaussures",category:"Apparence",quantity:1,unitBudget:5000,plannedMonth:"2026-08",status:"confirmed"}],
  forecastExpenses:[{id:"forecast-clothes",name:"Vêtement prévu",category:"Apparence",amount:8000,date:"2026-08-20",status:"planned"}],
  recurringExpenses:[],trainingStore:[],consumptionBudgets:[],
  consumptionCategoryStore:[{id:"cat-hygiene",name:"Hygiène & soins",parentId:"",icon:"heart",active:true}],
  consumptionStore:[{id:"brush",name:"Brosse à dents",categoryId:"cat-hygiene",subcategoryId:"",defaultPrice:1500,defaultQuantity:1,unit:"unité",frequencyRuleId:"frequency-consumption-brush",active:true,characteristics:{criteria:[]}}],
  consumptionPurchases:[{id:"purchase-brush",articleId:"brush",itemId:"brush",itemName:"Brosse à dents",purchasedAt:"2026-07-01",price:1500,quantity:1,unitPrice:1500,transactionId:""}],
  frequencyRules:[{id:"frequency-consumption-brush",revision:1,status:"ACTIVE",schedule:{type:"ROLLING_INTERVAL",every:90,unit:"DAY"},metadata:{learningEnabled:false}}]
};
const result=window.VieViewAdapters.budgetAllocation(state,{referenceDate:"2026-08-11",month:"2026-08"});
assert.equal(result.contract,"vie.budget-allocation.v1");
assert.equal(result.global.amount,100000);
assert.equal(result.global.allocated,85000);
assert.equal(result.global.unallocated,15000);
assert.equal(result.resources.income,300000);
assert.equal(result.resources.expenses,22500);
const appearance=result.allocations.find(item=>item.domain==="appearance");
assert.equal(appearance.actual,12500);
assert.equal(appearance.committed,5000);
assert.equal(appearance.plannedOneOff,8000);
assert.equal(appearance.plannedRecurringDue,0);
assert.equal(appearance.forecastApplied,8000,"Le mode échéances ne doit pas appliquer l’équivalent mensuel");
assert.equal(appearance.availableActual,22500);
assert.equal(appearance.availableAfterCommitted,17500);
assert.equal(appearance.availableAfterForecast,9500);
assert.equal(appearance.recurringMonthlyEquivalent,507,"Le coût d’achat de 1 500 FCFA sur 90 jours doit rester séparé de son équivalent mensuel");
assert.equal(appearance.lines.equivalents[0].amount,1500,"Le coût d’achat doit être conservé");
assert.equal(appearance.lines.equivalents[0].monthlyEquivalent,507);
assert.equal(appearance.percentages.actual,35.7);
assert.equal(appearance.percentages.committed,14.3);
assert.equal(appearance.percentages.planned,22.9);
assert.equal(appearance.percentages.available,27.1);
assert.equal(result.principles.purchaseCostSeparatedFromMonthlyEquivalent,true);
assert.equal(result.principles.forecastIsExpense,false);
assert.equal(result.principles.commitmentIsExpense,false);
assert.equal(result.principles.noDoubleCounting,true);
assert.equal(result.integrity.ok,true);
assert.equal(Object.isFrozen(result),true);
assert.equal(Object.isFrozen(appearance.lines),true);

const smoothed=structuredClone(state);smoothed.budgetAllocationStore[0].forecastMode="MONTHLY_EQUIVALENT";
const smoothResult=window.VieViewAdapters.budgetAllocation(smoothed,{referenceDate:"2026-08-11",month:"2026-08"});
const smoothAppearance=smoothResult.allocations.find(item=>item.domain==="appearance");
assert.equal(smoothAppearance.forecastApplied,8507);
assert.equal(smoothAppearance.availableAfterForecast,8993);
assert.equal(smoothAppearance.plannedDue,8000,"Le coût réellement prévu reste consultable séparément");

const withCart=structuredClone(state);withCart.purchaseCart=[{id:"cart-brush",articleId:"brush",quantity:2,unitPrice:1500,format:"Adulte",plannedMonth:"2026-08"}];const cartResult=window.VieViewAdapters.budgetAllocation(withCart,{referenceDate:"2026-08-11",month:"2026-08"}),cartAppearance=cartResult.allocations.find(item=>item.domain==="appearance");
assert.equal(cartAppearance.plannedOneOff,11000,"Le panier doit alimenter le prévu avec les dépenses ponctuelles");
assert.equal(cartAppearance.recurringMonthlyEquivalent,0,"La sélection explicite du panier doit remplacer la projection récurrente du même article pour éviter un doublon");
assert.equal(cartAppearance.lines.plannedOneOff.some(item=>item.kind==="PLANNED_CART"&&item.amount===3000),true);
assert.equal(cartResult.principles.cartIsPurchase,false,"Le panier planifie le budget sans devenir un achat");

const grouped=structuredClone(state);grouped.transactions=[{id:"tx-grouped",type:"expense",amount:11700,label:"Panier mixte",category:"Autre",date:"2026-08-10",items:[{name:"Riz",articleId:"rice",category:"Alimentation",budgetAllocationId:"allocation-food",quantity:1,unitPrice:8500},{name:"Brosse",articleId:"brush",category:"Apparence",budgetAllocationId:"allocation-appearance",quantity:1,unitPrice:3200}]}];grouped.consumptionStore.push({id:"rice",name:"Riz",categoryId:"cat-food",defaultPrice:8500,defaultQuantity:1,frequencyRuleId:"frequency-rice",active:true,characteristics:{criteria:[]}});grouped.consumptionCategoryStore.push({id:"cat-food",name:"Alimentation",parentId:"",icon:"box",active:true});grouped.frequencyRules.push({id:"frequency-rice",revision:1,status:"ACTIVE",schedule:{type:"ROLLING_INTERVAL",every:30,unit:"DAY"},metadata:{learningEnabled:false}});grouped.consumptionPurchases=[{id:"purchase-rice-linked",articleId:"rice",itemId:"rice",itemName:"Riz",purchasedAt:"2026-08-10",price:8500,quantity:1,transactionId:"tx-grouped"},{id:"purchase-brush-linked",articleId:"brush",itemId:"brush",itemName:"Brosse",purchasedAt:"2026-08-10",price:3200,quantity:1,transactionId:"tx-grouped"}];grouped.forecastExpenses=[];grouped.acquisitionPlans=[];const groupedResult=window.VieViewAdapters.budgetAllocation(grouped,{referenceDate:"2026-08-11",month:"2026-08"});assert.equal(groupedResult.global.actual,11700,"Une transaction groupée ne doit être comptée qu’une fois");assert.equal(groupedResult.allocations.find(item=>item.domain==="food").actual,8500);assert.equal(groupedResult.allocations.find(item=>item.domain==="appearance").actual,3200);assert.equal(groupedResult.allocations.reduce((sum,item)=>sum+item.actual,0),11700);

console.log(JSON.stringify({ok:true,contract:result.contract,appearance:{allocated:appearance.amount,actual:appearance.actual,committed:appearance.committed,planned:appearance.forecastApplied,available:appearance.availableAfterForecast,purchaseCost:appearance.lines.equivalents[0].amount,monthlyEquivalent:appearance.recurringMonthlyEquivalent},global:result.global,noDoubleCounting:true,frozen:true},null,2));
