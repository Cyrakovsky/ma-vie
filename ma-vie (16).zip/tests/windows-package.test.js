"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const installer = fs.readFileSync(path.join(root, "server", "installer-vie.ps1"), "utf8");
const serverSource = fs.readFileSync(path.join(root, "server", "source", "main.go"), "utf8");
const runtimeReferences = [...index.matchAll(/<(?:script[^>]+src|link[^>]+href)="([^"?#]+)(?:\?[^"#]*)?"/g)].map(match => match[1]);

for (const relative of runtimeReferences) {
  assert.equal(/^https?:/.test(relative), false, `Ressource externe interdite : ${relative}`);
  assert.equal(fs.existsSync(path.join(root, relative)), true, `Ressource référencée mais absente : ${relative}`);
}

assert.equal(runtimeReferences.includes("assets/recurrence-engine.js"), true, "Le moteur doit être servi depuis assets/");
assert.equal(runtimeReferences.includes("recurrence-engine.js"), false, "L’ancien chemin racine provoquait une page blanche après installation");
assert.equal(fs.readFileSync(path.join(root, "recurrence-engine.js"), "utf8"), fs.readFileSync(path.join(root, "assets", "recurrence-engine.js"), "utf8"), "La source et la ressource installable du moteur doivent être identiques");

const copiedRootFiles = new Set(["index.html", "styles.css", "views.js", "script.js", "server-adapter.js"]);
for (const relative of runtimeReferences) {
  const copiedByInstaller = copiedRootFiles.has(relative) || relative.startsWith("assets/");
  assert.equal(copiedByInstaller, true, `Le programme d’installation ne copierait pas : ${relative}`);
}

assert.match(installer, /assets\\recurrence-engine\.js/);
assert.match(installer, /Toutes les ressources de démarrage sont accessibles/);
assert.match(installer, /DIAGNOSTIC-VIE\.bat/);
assert.match(installer, /Ma-Vie-installation\.log/);
assert.match(serverSource, /strings\.HasPrefix\(rel, "assets\/"\)/, "VIE Server doit autoriser les ressources sous assets/");

for (const required of ["AIDE-VIE-NE-SE-FERME-PAS.cmd", "DIAGNOSTIC-VIE.bat", "diagnostiquer-vie.ps1", "INSTALLER-VIE.bat", "installer-vie.ps1", "METTRE-A-JOUR-VIE.bat", "verifier-mise-a-jour.ps1", "mettre-a-jour-vie.ps1", "update-config.json"]) {
  assert.equal(fs.existsSync(path.join(root, "server", required)), true, `Outil Windows absent : ${required}`);
}
assert.equal(fs.existsSync(path.join(root, "COMMENCER-ICI.cmd")), true, "Le point d’entrée Windows COMMENCER-ICI.cmd doit être visible à la racine");
assert.match(installer, /AIDE-VIE-NE-SE-FERME-PAS\.cmd/);
const helpMenu=fs.readFileSync(path.join(root,"server","AIDE-VIE-NE-SE-FERME-PAS.cmd"),"utf8");
const installerBat=fs.readFileSync(path.join(root,"server","INSTALLER-VIE.bat"),"utf8");
const startHere=fs.readFileSync(path.join(root,"COMMENCER-ICI.cmd"),"utf8");
assert.match(helpMenu,/choice \/C 1234567Q/);
assert.match(helpMenu,/Verifier les mises a jour GitHub/);
assert.match(installer,/verifier-mise-a-jour\.ps1/);
assert.match(installer,/mettre-a-jour-vie\.ps1/);
assert.match(installer,/update-config\.json/);
assert.match(installerBat,/if exist "%~dp0installer-vie\.ps1" goto INSTALLER_PRESENT/);
assert.doesNotMatch(installerBat,/set "SCRIPT=/,"Le chemin de l’installateur ne doit plus être développé dans un bloc sensible aux parenthèses");
assert.match(installerBat,/:AFFICHER_JOURNAL/);
assert.match(helpMenu,/call "%~dp0INSTALLER-VIE\.bat"/);
assert.match(startHere,/AIDE-VIE-NE-SE-FERME-PAS\.cmd/);

console.log(JSON.stringify({
  ok: true,
  runtimeReferences,
  recurrencePath: "assets/recurrence-engine.js",
  installerCopiesAllReferences: true,
  diagnosticIncluded: true
}, null, 2));
