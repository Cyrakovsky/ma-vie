"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const state = {
  consumptionCategoryStore: [
    { id: "cat-hygiene", name: "Hygiène & soins", parentId: "", icon: "heart", builtIn: true, active: true },
    { id: "cat-dental", name: "Hygiène dentaire", parentId: "cat-hygiene", icon: "smile", builtIn: true, active: true }
  ],
  frequencyRules: [{
    id: "frequency-consumption-brush",
    revision: 1,
    status: "ACTIVE",
    effectiveFrom: "2026-08-11",
    schedule: { type: "ROLLING_INTERVAL", every: 90, unit: "DAY" },
    anchorPolicy: "LAST_DOMAIN_EVENT",
    metadata: { origin: "USER_DEFINED", learningEnabled: true }
  }],
  consumptionStore: [{
    id: "brush",
    name: "Brosse à dents",
    categoryId: "cat-hygiene",
    subcategoryId: "cat-dental",
    imageBlobId: "blob-brush",
    visualPreview: "data:image/jpeg;base64,preview",
    defaultPrice: 1500,
    defaultQuantity: 1,
    unit: "unité",
    characteristics: { model: "Souple medium", color: "Bleu", size: "Adulte", material: "", criteria: [] },
    frequencyRuleId: "frequency-consumption-brush",
    active: true
  }],
  consumptionPurchases: [{
    id: "purchase-1",
    articleId: "brush",
    itemName: "Brosse à dents",
    purchasedAt: "2026-08-11",
    price: 1500,
    quantity: 1,
    unitPrice: 1500,
    source: "ticket"
  }]
};

const view = window.VieViewAdapters.consumptionOverview(state, { referenceDate: "2026-08-11", horizonDays: 120 });
const article = view.items[0];

assert.equal(view.contract, "vie.consumption-overview.v2");
assert.equal(article.classification.category, "Hygiène & soins");
assert.equal(article.classification.subcategory, "Hygiène dentaire");
assert.equal(article.frequencyRuleId, "frequency-consumption-brush");
assert.equal(article.frequency.value, 90);
assert.equal(article.nextExpectedDate, "2026-11-09");
assert.equal(article.defaultPrice, 1500);
assert.equal(article.visual.imageBlobId, "blob-brush");
assert.equal(view.purchases[0].articleId, "brush");
assert.equal(view.purchases[0].unitPrice, 1500);
assert.equal(Object.prototype.hasOwnProperty.call(state.consumptionStore[0], "frequencyRule"), false, "La règle ne doit pas être imbriquée dans Article");
assert.equal(Object.isFrozen(view), true);
assert.equal(Object.isFrozen(article), true);
assert.equal(view.principles.articlePurchaseFrequencySeparated, true);
assert.equal(view.principles.forecastIsPurchase, false);
assert.equal(view.principles.imageLocalOnly, true);

console.log(JSON.stringify({
  ok: true,
  contract: view.contract,
  articleId: article.id,
  frequencyRuleId: article.frequencyRuleId,
  nextExpectedDate: article.nextExpectedDate,
  category: article.classification.category,
  frozen: Object.isFrozen(article)
}, null, 2));
