"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");

const engine = window.VieRecurrenceEngine;

const weeklyRule = {
  id: "frequency-sport",
  revision: 1,
  status: "ACTIVE",
  effectiveFrom: "2026-08-01",
  timezone: { mode: "PROFILE", zone: "Africa/Libreville" },
  anchorPolicy: "FIXED_CALENDAR",
  commitment: "REQUIRED",
  schedule: {
    type: "CALENDAR_SLOTS",
    period: "ISO_WEEK",
    slots: [
      { id: "monday", weekday: 1, time: "18:00", moment: "EVENING" },
      { id: "wednesday", weekday: 3, time: "18:00", moment: "EVENING" }
    ]
  }
};
const weeklyBinding = {
  id: "binding-sport",
  ruleId: weeklyRule.id,
  active: true,
  sourceRef: { domain: "HABIT", store: "HabitStore", entityId: "sport" },
  occurrenceTemplate: { durationMinutes: 45, estimatedMoney: 0, currency: "FCFA" }
};
const input = { rules: [weeklyRule], bindings: [weeklyBinding], executions: [] };
const ruleBefore = JSON.stringify(weeklyRule);
const august = engine.generate(input, { from: "2026-08-01", to: "2026-08-31", referenceDate: "2026-08-10" });
const augustAgain = engine.generate(input, { from: "2026-08-01", to: "2026-08-31", referenceDate: "2026-08-10" });

assert.equal(august.length, 9, "Lundi + mercredi doit produire neuf dates réelles en août 2026");
assert.deepEqual(augustAgain, august, "Le moteur doit être déterministe");
assert.equal(new Set(august.map(item => item.key)).size, august.length, "Les clés doivent être uniques");
assert.equal(august.filter(item => item.status === "MISSED").length, 2, "MISSED doit être dérivé du calendrier");
assert.equal(august.every(item => item.commitment === "REQUIRED"), true, "La contrainte doit être propagée à chaque occurrence");
assert.equal(engine.commitments.includes("REQUIRED"), true);

const firstMonday = august.find(item => item.date === "2026-08-03");
const execution = { id: "execution-1", bindingId: weeklyBinding.id, occurrenceKey: firstMonday.key, outcome: "DONE", occurredAt: "2026-08-03T18:42:00" };
const withExecution = engine.generate({ ...input, executions: [execution] }, { from: "2026-08-01", to: "2026-08-31", referenceDate: "2026-08-10" });
assert.equal(withExecution.find(item => item.key === firstMonday.key).status, "DONE");
assert.equal(JSON.stringify(weeklyRule), ruleBefore, "Une exécution ne doit jamais modifier la règle");

const purchaseRule = {
  id: "frequency-brush",
  revision: 1,
  status: "ACTIVE",
  effectiveFrom: "2026-08-20",
  timezone: { mode: "PROFILE", zone: "Africa/Libreville" },
  anchorPolicy: "LAST_DOMAIN_EVENT",
  schedule: { type: "ROLLING_INTERVAL", every: 90, unit: "DAY" }
};
const purchaseBinding = {
  id: "binding-brush",
  ruleId: purchaseRule.id,
  active: true,
  anchorDate: "2026-08-20",
  sourceRef: { domain: "CONSUMPTION", store: "ConsumptionStore", entityId: "brush" },
  occurrenceTemplate: { estimatedMoney: 1500, currency: "FCFA" }
};
const firstForecast = engine.generate({ rules: [purchaseRule], bindings: [purchaseBinding] }, { from: "2026-08-20", to: "2027-03-01", referenceDate: "2026-08-20" });
const shiftedForecast = engine.generate({ rules: [purchaseRule], bindings: [{ ...purchaseBinding, anchorDate: "2026-11-20" }] }, { from: "2026-11-20", to: "2027-04-01", referenceDate: "2026-11-20" });
assert.equal(firstForecast[0].date, "2026-11-18");
assert.equal(firstForecast[0].commitment, "OPTIONAL", "Une prévision d’achat ne doit jamais devenir obligatoire par défaut");
assert.equal(engine.summarize(firstForecast).reduce((sum, item) => sum + item.required.total, 0), 0);
assert.equal(engine.summarize(firstForecast).reduce((sum, item) => sum + item.optional.total, 0), firstForecast.length);
assert.equal(shiftedForecast[0].date, "2027-02-18");

const maintenanceRule = { ...purchaseRule, id: "frequency-maintenance", effectiveFrom: "2026-08-01", anchorPolicy: "LAST_COMPLETION", schedule: { type: "ROLLING_INTERVAL", every: 10, unit: "DAY" } };
const maintenanceBinding = { ...purchaseBinding, id: "binding-maintenance", ruleId: maintenanceRule.id, anchorDate: "2026-08-01", sourceRef: { domain: "MAINTENANCE", store: "MaintenanceStore", entityId: "filter" } };
const due = engine.generate({ rules: [maintenanceRule], bindings: [maintenanceBinding] }, { from: "2026-08-10", to: "2026-08-20", referenceDate: "2026-08-10" })[0];
const completed = { id: "execution-maintenance", bindingId: maintenanceBinding.id, occurrenceKey: due.key, outcome: "DONE", occurredAt: "2026-08-10T09:00:00" };
const afterCompletion = engine.generate({ rules: [maintenanceRule], bindings: [{ ...maintenanceBinding, anchorDate: "2026-08-10" }], executions: [completed] }, { from: "2026-08-10", to: "2026-08-20", referenceDate: "2026-08-10" });
assert.equal(afterCompletion[0].status, "DONE", "L’occurrence exécutée doit rester visible après changement d’ancrage");
assert.equal(afterCompletion[1].date, "2026-08-20", "La prochaine occurrence doit partir de la dernière exécution");

const integrity = engine.validate(input, { from: "2026-08-01", to: "2026-08-31", referenceDate: "2026-08-10" });
assert.equal(integrity.ok, true);
const summaries = engine.summarize(withExecution);
assert.equal(summaries.some(item => item.progressMeta.automatic === true), true);
assert.equal(summaries.reduce((sum, item) => sum + item.required.total, 0), withExecution.length, "Le suivi REQUIRED doit compter toutes les occurrences obligatoires");
assert.equal(summaries.reduce((sum, item) => sum + item.required.done, 0), 1, "La réalisation obligatoire doit être comptée sans modifier la règle");
assert.equal(summaries.every(item => Object.isFrozen(item.required)), true, "Les sous-résumés doivent être immuables");
const invalidCommitment = engine.validate({ rules: [{ ...weeklyRule, commitment: "HIGH" }], bindings: [weeklyBinding] });
assert.equal(invalidCommitment.ok, false, "Une priorité générique ne doit pas remplacer REQUIRED ou OPTIONAL");
assert.match(invalidCommitment.errors.join(" "), /Engagement invalide/);

console.log(JSON.stringify({
  ok: true,
  engineVersion: engine.version,
  augustOccurrences: august.length,
  deterministic: true,
  nextPurchase: firstForecast[0].date,
  shiftedPurchase: shiftedForecast[0].date,
  integrity: integrity.ok
}, null, 2));
