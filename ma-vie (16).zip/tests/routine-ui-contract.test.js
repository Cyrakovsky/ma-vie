"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const script = fs.readFileSync(path.join(root, "script.js"), "utf8");
const views = fs.readFileSync(path.join(root, "views.js"), "utf8");
const styles = fs.readFileSync(path.join(root, "styles.css"), "utf8");
const engine = fs.readFileSync(path.join(root, "recurrence-engine.js"), "utf8");

assert.match(script, /commitment:\s*habit\.commitment/, "HabitStore doit alimenter la FrequencyRule existante");
assert.match(script, /recurrenceRuleSignature=rule=>JSON\.stringify\(\{schedule:rule\.schedule,anchorPolicy:rule\.anchorPolicy,timezone:rule\.timezone,commitment:/, "L’engagement doit faire partie de la révision de règle");
assert.match(script, /frequencyRuleHistory\.unshift\([^\n]*SUPERSEDED/, "Une modification sémantique doit archiver l’ancienne révision");
assert.match(script, /\[\["REQUIRED","Obligatoire — contrainte à protéger"\],\["OPTIONAL","Optionnel — activité souhaitée"\]\]/, "Le formulaire doit proposer une sémantique explicite");
assert.match(script, /add-required-routine/, "Une contrainte doit pouvoir être créée depuis l’interface");
assert.match(script, /category:"Entretien personnel"/, "La création guidée doit rester dans HabitStore");
assert.match(script, /commitment:"OPTIONAL"[^\n]*sourceRef:\{domain:"CONSUMPTION"|sourceRef:\{domain:"CONSUMPTION"[^\n]*commitment:"OPTIONAL"/, "Une prévision d’achat doit rester optionnelle");
assert.doesNotMatch(script, /requiredRoutineStore|mandatoryRoutineStore/, "Aucun nouveau store métier ne doit être créé");
assert.match(views, /label:"Obligatoire"/, "Aujourd’hui doit distinguer les contraintes obligatoires");
assert.match(views, /Suivi par routine/, "Le suivi hebdomadaire par routine doit être visible");
assert.match(views, /Contraintes obligatoires de la semaine/, "Le centre des fréquences doit exposer les contraintes protégées");
assert.match(views, /Seule votre validation crée DONE ; MISSED reste dérivé/, "L’interface doit expliquer la sémantique sans automatiser la réussite");
assert.match(styles, /VIE 18\.8 — contraintes personnelles REQUIRED \/ OPTIONAL/);
assert.match(styles, /\.recurrence-weekly-tracking/);
assert.match(engine, /commitment:\s*normalizeCommitment\(rule\.commitment\)/);

console.log(JSON.stringify({
  ok: true,
  primitiveAdded: false,
  habitStoreReused: true,
  todayGroupsVisible: true,
  weeklyTrackingVisible: true
}, null, 2));
