"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const script = fs.readFileSync(path.join(root, "script.js"), "utf8");
const views = fs.readFileSync(path.join(root, "views.js"), "utf8");
const styles = fs.readFileSync(path.join(root, "styles.css"), "utf8");
const adapters = fs.readFileSync(path.join(root, "assets", "react", "vie-view-adapters.js"), "utf8");

assert.match(script, /target\.thoughtStore=/, "Les pensées doivent utiliser un store spécialisé");
assert.match(script, /target\.reflectionStore=/, "Les réflexions doivent utiliser un store spécialisé");
assert.match(script, /delete target\.reflections/, "L’ancien tableau ne doit pas être dupliqué après migration");
assert.doesNotMatch(script, /EntityType[^\n]*(?:Thought|Reflection|Pensée|Réflexion)/i, "Aucune primitive Core générique ne doit être ajoutée");
assert.match(script, /epistemicStatus:"DECLARED"/, "Une pensée saisie doit rester une déclaration");
assert.match(script, /managedBy:"reflective-memory-form"/, "Les liens doivent être des relations explicites et traçables");
assert.match(script, /reflective-principle-adoption/, "Un principe doit exiger une adoption explicite");
assert.match(script, /Pourquoi VIE me dit cela \?/, "L’explication causale doit être accessible");
assert.match(views, /Pensée ≠ réflexion ≠ principe ≠ conseil/);
assert.match(views, /Carte des idées récurrentes/);
assert.match(views, /RAPPORT DE RÉFLEXION/);
assert.match(views, /Pourquoi me dis-tu ça \?/);
assert.match(views, /VIE n’ajoute aucune citation à votre place/);
assert.doesNotMatch(views, /Une vie non examinée ne vaut pas la peine d’être vécue/, "Aucune citation externe ne doit être présentée comme enregistrée");
assert.match(adapters, /contract:"vie\.reflective-memory\.v1"/);
assert.match(adapters, /thoughtIsTruth:false/);
assert.match(adapters, /derivedIsPsychologicalDiagnosis:false/);
assert.match(adapters, /adviceRequiresProvenance:true/);
assert.match(styles, /VIE 18\.9 — mémoire réflexive, provenance et conseils/);

console.log(JSON.stringify({
  ok: true,
  specializedStores: true,
  newCorePrimitive: false,
  declaredDerivedAdviceSeparated: true,
  traceableAdvice: true,
  psychologicalDiagnosis: false
}, null, 2));
