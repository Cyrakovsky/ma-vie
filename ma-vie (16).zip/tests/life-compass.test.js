"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const dimension = (label, weight, scopes, parentId = "") => ({
  id: `dimension-${label.toLowerCase()}`,
  key: label.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(),
  label,
  weight,
  parentId,
  scopes
});
const dimensions1 = [
  dimension("Devenir", 25, ["apprentissage", "competences", "lectures", "objectifs"]),
  dimension("Aimer", 20, ["relations", "famille"]),
  dimension("Construire", 25, ["projets", "travail", "objectifs"]),
  dimension("Partager", 15, ["relations", "contributions", "connaissances"]),
  dimension("Transmettre", 15, ["transmission", "connaissances", "famille"], "partager")
];
const dimensions2 = dimensions1.map(item => ({ ...item, weight: ({ Devenir:20, Aimer:25, Construire:20, Partager:20, Transmettre:15 })[item.label] }));
const state = {
  ui: {},
  lifeCompassSettings: { periodDays: 90 },
  lifeVisionBaselines: [
    { id:"baseline-1", revision:1, name:"Baseline 01", date:"2026-09-01", successDefinition:"Devenir, aimer, construire, partager et transmettre.", reviewQuestion:"Qu’as-tu fait de ce qui t’a été donné ?", dimensions:dimensions1, createdAt:"2026-09-01T08:00:00Z" },
    { id:"baseline-2", revision:2, name:"Baseline 02", date:"2027-01-01", successDefinition:"Construire une vie qui garde une place réelle aux relations et à la transmission.", reviewQuestion:"Qu’as-tu fait de ce qui t’a été donné ?", dimensions:dimensions2, supersedesId:"baseline-1", createdAt:"2027-01-01T08:00:00Z" }
  ],
  timeLogs: [
    { id:"time-study", date:"2027-01-03", category:"Étude", hours:10, note:"Formation" },
    { id:"time-family", date:"2027-01-04", category:"Famille", hours:10, note:"Temps familial" },
    { id:"time-project", date:"2027-01-05", category:"Projets", hours:20, note:"Projet maison" },
    { id:"time-share", date:"2027-01-06", category:"Contributions", hours:10, note:"Partage de connaissances" }
  ],
  learningSessionHistory: [], trainingStore: [], skillStore: [], personalLibrary: [],
  goals: [{ id:"goal-house", name:"Maison familiale", status:"progress", journal:[{id:"goal-event",date:"2027-01-05",text:"Plan validé",type:"update"}] }],
  goalArchive: [], propertyProjects: [], businessTasks: [], relationEvents: [], familyMoments: [],
  knowledgeNodes: [{id:"knowledge-1",title:"Guide partagé",updatedAt:"2027-01-06"}],
  legacyLibrary: [{id:"legacy-1",title:"Leçon à transmettre",date:"2027-01-07",status:"ready"}],
  thoughtStore: [], reflectionStore: [{id:"reflection-1",title:"Réflexion de période",date:"2027-01-08"}],
  lifeDecisions: [], physicalActivities: [],
  periodicReviews: [{ id:"review-1",lifeReview:true,period:"Janvier 2027",date:"2027-01-09",reviewQuestion:"Qu’as-tu fait de ce qui t’a été donné ?",response:"J’ai consacré du temps à apprendre et à construire.",baselineId:"baseline-2",given:{time:"90 jours",opportunities:"Un projet",skills:"Planification",encounters:"Famille",resources:"Temps",difficulties:"Fatigue"} }]
};

const compass = window.VieViewAdapters.lifeCompass(state, { referenceDate:"2027-01-10" });
assert.equal(compass.contract, "vie.life-compass.v1");
assert.equal(compass.baseline.id, "baseline-2");
assert.equal(compass.activeBaselineId, "baseline-2");
assert.equal(compass.isHistorical, false);
assert.equal(compass.baselines.length, 2);
assert.equal(compass.baselines[0].epistemicStatus, "DECLARED");
assert.equal(compass.baseline.dimensions.reduce((sum,item)=>sum+item.weight,0), 100);
assert.ok(compass.dimensions.every(item => Number.isFinite(item.observedShare)));
assert.ok(compass.dimensions.every(item => !Object.hasOwn(item, "successScore")));
assert.equal(compass.coverage.basis, "RECORDED_TIME");
assert.match(compass.coverage.statement, /absence de trace ne prouve pas/);
assert.equal(compass.comparison.changes.length, 4);
assert.equal(compass.comparison.epistemicStatus, "DERIVED");
assert.match(compass.comparison.statement, /conception déclarée/);
assert.equal(compass.lifeReviews.length, 1);
assert.equal(compass.lifeReviews[0].epistemicStatus, "DECLARED");
assert.equal(compass.integrity.ok, true);
assert.equal(compass.principles.compassIsSuccessScore, false);
assert.equal(compass.principles.gapIsMoralJudgment, false);
assert.equal(compass.principles.missingEvidenceIsFailure, false);
assert.equal(compass.principles.baselineIsImmutable, true);
assert.equal(Object.isFrozen(compass), true);
assert.equal(Object.isFrozen(compass.dimensions[0].evidence), true);

const historical = window.VieViewAdapters.lifeCompass({ ...state, ui:{selectedVisionBaselineId:"baseline-1"} }, { referenceDate:"2027-01-10" });
assert.equal(historical.baseline.id, "baseline-1");
assert.equal(historical.isHistorical, true);
assert.equal(historical.comparison, null);

const invalid = structuredClone(state);
invalid.lifeVisionBaselines[1].dimensions[0].weight = 21;
invalid.lifeVisionBaselines[1].dimensions[4].parentId = "transmettre";
const invalidCompass = window.VieViewAdapters.lifeCompass(invalid, { referenceDate:"2027-01-10" });
assert.equal(invalidCompass.integrity.ok, false);
assert.equal(invalidCompass.integrity.errors.some(item=>item.includes("101 %")), true);
assert.equal(invalidCompass.integrity.errors.some(item=>item.includes("Cycle hiérarchique")), true);

console.log(JSON.stringify({
  ok:true,
  contract:compass.contract,
  baselines:compass.baselines.length,
  comparisonChanges:compass.comparison.changes.length,
  dimensions:compass.dimensions.map(item=>({label:item.label,declared:item.weight,observed:item.observedShare,basis:item.basis})),
  successScore:false,
  moralJudgment:false,
  frozen:true
}, null, 2));
