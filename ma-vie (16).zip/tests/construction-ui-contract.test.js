"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const script = fs.readFileSync(path.join(root, "script.js"), "utf8");
const styles = fs.readFileSync(path.join(root, "styles.css"), "utf8");
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");

assert.match(script, /event\.shiftKey\?event\.deltaY:0/, "La molette verticale simple ne doit plus déplacer les onglets");
assert.match(script, /subnavResizeTimer=setTimeout/, "Le redimensionnement doit être temporisé");
assert.match(script, /scrollFrame=requestAnimationFrame/, "Les mises à jour pendant le scroll doivent être limitées à une par frame");
assert.match(styles, /scroll-snap-type:none!important/, "Le scroll snapping provoquant des retours visuels doit être désactivé");
assert.match(styles, /subnav-scroll-shell:not\(\.has-overflow\).*visibility:hidden/, "Les flèches doivent rester dans la grille sans changement de largeur");
assert.match(styles, /construction-department \.construction-tab-content svg[^}]*fill:none!important[^}]*stroke:currentColor!important/, "Les icônes Construction doivent rester des tracés SVG");
assert.match(index, /id="vie-illus-immobilier"[\s\S]*?<rect x="31" y="49"/, "L’illustration immobilière redessinée doit utiliser des formes fermées");

console.log(JSON.stringify({
  ok: true,
  verticalWheelMovesTabs: false,
  resizeDebounced: true,
  scrollSnapDisabled: true,
  constructionIconsNormalized: true
}, null, 2));
