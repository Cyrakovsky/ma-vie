"use strict";

const assert = require("node:assert/strict");
global.window = {};
require("../recurrence-engine.js");
require("../assets/react/vie-view-adapters.js");

const engine = window.VieRecurrenceEngine;
const routine = (id, name, weekday, time) => ({
  habit: {
    id,
    name,
    category: "Entretien personnel",
    commitment: "REQUIRED",
    why: "Contrainte personnelle permanente"
  },
  rule: {
    id: `frequency-habit-${id}`,
    revision: 1,
    status: "ACTIVE",
    effectiveFrom: "2026-08-01",
    timezone: { mode: "PROFILE", zone: "Africa/Libreville" },
    schedule: {
      type: "CALENDAR_SLOTS",
      period: "ISO_WEEK",
      slots: [{ id: `day-${weekday}`, weekday, time, moment: "DAY" }]
    },
    anchorPolicy: "FIXED_CALENDAR",
    commitment: "REQUIRED"
  },
  binding: {
    id: `binding-habit-${id}`,
    ruleId: `frequency-habit-${id}`,
    active: true,
    sourceRef: { domain: "HABIT", store: "HabitStore", entityId: id },
    occurrenceTemplate: { durationMinutes: 30, estimatedMoney: 0, currency: "FCFA" }
  }
});

const routines = [
  routine("coiffure", "Se coiffer", 1, "18:00"),
  routine("linge", "Laver le linge", 2, "17:00"),
  routine("chambre", "Nettoyer la chambre", 6, "10:00")
];
const doneKey = engine.occurrenceKey({
  ruleId: routines[1].rule.id,
  revision: 1,
  date: "2026-08-11",
  slotId: "day-2"
});
const state = {
  recurrenceSettings: { zone: "Africa/Libreville" },
  habits: routines.map(item => item.habit),
  frequencyRules: routines.map(item => item.rule),
  recurrenceBindings: routines.map(item => item.binding),
  recurrenceExecutions: [{
    id: "execution-linge",
    bindingId: routines[1].binding.id,
    occurrenceKey: doneKey,
    outcome: "DONE",
    occurredAt: "2026-08-11T17:30:00"
  }]
};

const legacy = window.VieViewAdapters.recurrencePlan(state, {
  from: "2026-08-10",
  to: "2026-08-16",
  referenceDate: "2026-08-11"
});
const plan = window.VieViewAdapters.recurrencePlanV2(state, {
  from: "2026-08-10",
  to: "2026-08-16",
  referenceDate: "2026-08-11"
});

assert.equal(legacy.contract, "vie.recurrence-plan.v1", "Le contrat v1 doit rester figé");
assert.equal("commitment" in legacy.occurrences[0], false, "Le contrat v1 ne doit pas être modifié silencieusement");
assert.equal(plan.contract, "vie.recurrence-plan.v2");
assert.equal(plan.occurrences.length, 3);
assert.equal(plan.occurrences.every(item => item.commitment === "REQUIRED"), true);
assert.equal(plan.occurrences.find(item => item.source.title === "Se coiffer").status, "MISSED", "MISSED doit rester dérivé");
assert.equal(plan.occurrences.find(item => item.source.title === "Laver le linge").status, "DONE");
assert.equal(plan.occurrences.find(item => item.source.title === "Nettoyer la chambre").status, "PLANNED");
assert.equal(plan.summaries[0].required.total, 3);
assert.equal(plan.summaries[0].required.done, 1);
assert.equal(plan.summaries[0].required.missed, 1);
assert.equal(plan.summaries[0].required.planned, 1);
assert.equal(plan.rules.every(item => item.commitment === "REQUIRED"), true);
assert.equal(plan.resources.required.timeMinutes, 90, "Le temps des contraintes doit être disponible pour l’arbitrage futur");
assert.equal(plan.resources.required.money, 0);
assert.equal(plan.resources.optional.timeMinutes, 0);
assert.equal(plan.principles.requiredCreatesExecution, false);
assert.equal(plan.principles.requiredCreatesPurchase, false);
assert.equal(plan.principles.requiredProtectedBeforeOptional, true);
assert.equal(Object.isFrozen(plan), true);
assert.equal(Object.isFrozen(plan.summaries[0].required), true);

console.log(JSON.stringify({
  ok: true,
  contract: plan.contract,
  required: plan.summaries[0].required,
  missedIsDerived: true,
  automaticExecution: false
}, null, 2));
